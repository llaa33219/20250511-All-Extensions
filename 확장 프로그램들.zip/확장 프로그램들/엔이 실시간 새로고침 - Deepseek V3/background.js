chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "NEW_POST") {
      // 새로운 게시물 알림
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon48.png",
        title: "새로운 게시물",
        message: `새로운 게시물: ${message.content.substring(0, 50)}...` // 내용의 일부만 표시
      });
    }
  });