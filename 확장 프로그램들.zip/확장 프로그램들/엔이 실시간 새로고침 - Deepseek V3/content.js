// 게시물 목록을 감시할 대상 선택
const postList = document.querySelector('.css-1urx3um'); // 게시물 목록의 클래스명 (실제 페이지에서 확인 필요)

if (postList) {
  // MutationObserver 설정
  const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
      if (mutation.type === 'childList') {
        // 새로운 게시물이 추가된 경우
        const newPosts = mutation.addedNodes;
        if (newPosts.length > 0) {
          // 새로운 게시물을 처리
          newPosts.forEach(post => {
            // 새로운 게시물에 스타일 적용 (예: 강조 표시)
            post.style.backgroundColor = '#f0f8ff'; // 연한 파란색 배경
            post.style.transition = 'background-color 1s';

            // 사용자에게 알림
            chrome.runtime.sendMessage({ type: "NEW_POST", content: post.innerText });
          });
        }
      }
    }
  });

  // 감시 옵션 설정 (자식 요소의 추가/삭제 감지)
  const config = { childList: true };

  // 게시물 목록 감시 시작
  observer.observe(postList, config);
} else {
  console.error('게시물 목록을 찾을 수 없습니다.');
}