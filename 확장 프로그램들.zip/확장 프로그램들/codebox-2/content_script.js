// content_script.js

// 전역에서 Pyodide 객체를 다루기 위해 캐싱
let pyodide = null;
let isPyodideLoading = false;

/**
 * Pyodide 스크립트 로드 및 초기화
 */
async function loadPyodideAndPackages() {
  if (pyodide || isPyodideLoading) {
    // 이미 로딩중이거나 로드가 된 경우 재호출 방지
    return;
  }
  isPyodideLoading = true;

  // Pyodide 스크립트 동적 추가
  const script = document.createElement('script');
  // 링크는 원본 그대로 사용 (Pyodide CDN)
  script.src = "https://cdn.jsdelivr.net/pyodide/v0.23.3/full/pyodide.js";
  script.async = false;
  document.head.appendChild(script);

  // 로드가 완료되면 pyodide를 초기화
  await new Promise((resolve) => {
    script.onload = resolve;
  });

  // 전역 함수 loadPyodide() 실행
  pyodide = await window.loadPyodide({
    indexURL: "https://cdn.jsdelivr.net/pyodide/v0.23.3/full/"
  });
  console.log("Pyodide loaded successfully.");
}

/**
 * 코드 블록에서 'Run' 버튼을 클릭했을 때 실행되는 함수
 * @param {string} code - 실행할 Python 코드
 */
async function runPythonCode(code) {
  try {
    await loadPyodideAndPackages();
    const result = pyodide.runPython(code);
    console.log("[Pyodide Execution Result]", result);
  } catch (err) {
    console.error("[Pyodide Execution Error]", err);
  }
}

/**
 * 각 코드 블록에 'Run' 버튼을 삽입
 * (복사 버튼은 그대로 유지, 왼쪽에 'Run' 버튼만 추가)
 */
function injectRunButtons() {
  // 복사 버튼을 찾기 위해 아래 CSS 셀렉터 사용
  // (사용자 예시에서 복사 버튼 영역: 'div[class*="flex items-center rounded bg-token-sidebar-surface-primary"] button[aria-label="Copy"]')
  // 필요 시 변경 가능
  const copyButtons = document.querySelectorAll('div[class*="flex items-center"] button[aria-label="Copy"]');
  
  copyButtons.forEach((copyBtn) => {
    // 이미 Run 버튼이 추가되었는지 체크 (중복 삽입 방지)
    if (copyBtn.parentElement.querySelector(".run-code-button")) {
      return; // 중복으로 달지 않음
    }

    // Run 버튼 생성
    const runBtn = document.createElement('button');
    runBtn.classList.add("flex", "gap-1", "items-center", "select-none", "px-4", "py-1", "run-code-button");
    runBtn.textContent = "Run";
    runBtn.style.marginRight = "8px"; // 복사 버튼 왼쪽 간격

    // Run 버튼 클릭 시 코드 실행
    runBtn.addEventListener('click', () => {
      // 해당 코드 블록 찾아서 내용 추출
      // (사용자 예시의 코드 블록 구조에 맞춰 인접한 code 태그를 탐색)
      // copyBtn -> 부모(parentElement) -> 부모... etc. 
      // 여유있게 가장 가까운 code 태그를 찾는다.
      
      let codeElement = null;
      // 최대한 가까운 조상 중에서 code 태그 찾기
      let parent = copyBtn.closest('.contain-inline-size');
      if (parent) {
        codeElement = parent.querySelector('code');
      }
      
      if (codeElement) {
        const pythonCode = codeElement.innerText;
        runPythonCode(pythonCode);
      } else {
        console.error("코드 블록을 찾을 수 없습니다.");
      }
    });

    // copyBtn의 부모 노드에 runBtn을 'copyBtn'의 왼쪽에 추가
    copyBtn.parentElement.insertBefore(runBtn, copyBtn);
  });
}

// DOM 변경이 있을 때마다 다시 주입(동적인 페이지에도 대응)
// 간단히 MutationObserver 사용
function observeAndInjectButtons() {
  const observer = new MutationObserver(() => {
    injectRunButtons();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  // 첫 실행 시점에도 수행
  injectRunButtons();
}

// 초기 구동
observeAndInjectButtons();
