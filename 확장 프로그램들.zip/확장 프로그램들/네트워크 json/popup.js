// popup.js

document.addEventListener("DOMContentLoaded", () => {
    chrome.storage.local.get("jsonData", (result) => {
      const pre = document.getElementById("jsonData");
      if (result.jsonData) {
        pre.textContent = JSON.stringify(result.jsonData, null, 2);
      } else {
        pre.textContent = "JSON 데이터가 없습니다.";
      }
    });
  });
  