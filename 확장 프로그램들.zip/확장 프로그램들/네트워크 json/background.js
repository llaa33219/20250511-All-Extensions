// background.js

// 특정 URL 패턴을 감시 (필요에 따라 수정)
const targetUrlPattern = "*://www.example.com/api/*";

// 네트워크 요청이 완료될 때 호출되는 함수
chrome.webRequest.onCompleted.addListener(
  function(details) {
    // 응답 헤더에서 콘텐츠 타입이 JSON인지 확인
    const contentType = details.responseHeaders.find(
      header => header.name.toLowerCase() === "content-type"
    );
    
    if (contentType && contentType.value.includes("application/json")) {
      // 요청의 URL을 통해 JSON 데이터 가져오기
      fetch(details.url)
        .then(response => response.json())
        .then(data => {
          console.log("추출된 JSON 데이터:", data);
          // 필요에 따라 데이터를 저장하거나 처리
          chrome.storage.local.set({ jsonData: data }, () => {
            console.log("JSON 데이터가 저장되었습니다.");
          });
        })
        .catch(error => {
          console.error("JSON 데이터 가져오기 실패:", error);
        });
    }
  },
  { urls: [targetUrlPattern] },
  ["responseHeaders"]
);

