document.getElementById('refreshBtn').addEventListener('click', function() {
    chrome.runtime.reload();
});
