// background.js

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.url) {
        let url = new URL(changeInfo.url);
        if (url.hostname === 'playentry.org' && url.pathname === '/redirect' && url.searchParams.get('external')) {
            let externalUrl = url.searchParams.get('external');
            // 탭을 업데이트하여 외부 URL로 리디렉션합니다.
            chrome.tabs.update(tabId, { url: externalUrl });
        }
    }
});
