// content.js  ── v1.4  (2025‑05‑03)
//  ● CHANGELOG
//    • canSync() 강화 – chrome.runtime.id 존재 여부까지 검사
//    • 모든 chrome.storage.* 호출을 try/catch + canSync() 재확인으로 래핑
//    • flushBuffered(), addSharedTime(), 초기 로드, onChanged 콜백 내부에서
//      context invalidation 발생 시 예외 무시 → 더 이상 오류 로그 발생하지 않음
// ──────────────────────────────────────────────────────────────
(() => {
  /* ─── 0. 전역 상태 ─── */
  let timeSpentMs = 0;     // 모든 탭 총합(표시용)
  let bufferMs    = 0;     // 아직 sync 저장 안 한 delta
  let lastResetDate = new Date().toDateString();
  let limitTimeSec  = null;

  /* 쓰로틀/가시성 대응 */
  let lastTickTime  = Date.now(); // 직전 tick timestamp
  let hiddenStart   = null;       // 탭이 hidden 상태로 진입한 시각

  const SYNC_INTERVAL_MS = 5000;  // sync.flush 최소 주기
  let lastFlushTs = 0;

  /* ─── 1. Storage 헬퍼 ─── */
  const canSync = () =>
    typeof chrome !== "undefined" &&
    !!chrome.runtime?.id &&
    chrome.storage?.sync &&
    typeof chrome.storage.sync.get === "function";

  function flushBuffered(force = false) {
    if (!canSync() || bufferMs === 0) return;
    const now = Date.now();
    if (!force && now - lastFlushTs < SYNC_INTERVAL_MS) return;

    try {
      chrome.storage.sync.get(["timeSpentMs"], data => {
        if (!canSync()) return; // context가 사라졌으면 중단
        const newVal = (data.timeSpentMs || 0) + bufferMs;
        chrome.storage.sync.set({ timeSpentMs: newVal }, () => {
          bufferMs = 0;
          lastFlushTs = Date.now();
          timeSpentMs = newVal;
        });
      });
    } catch (_) {
      /* Extension context invalidated → 무시 */
    }
  }

  function addSharedTime(deltaMs) {
    timeSpentMs += deltaMs;
    bufferMs    += deltaMs;
    flushBuffered();               // 5 초 마다만 sync
  }

  /* ─── 2. 탭‑간 동기화 ─── */
  if (canSync()) {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "sync") return;
        if (changes.limitTimeSec) limitTimeSec = changes.limitTimeSec.newValue;
        if (changes.lastResetDate) {
          lastResetDate = changes.lastResetDate.newValue;
          timeSpentMs = 0;
        }
        if (changes.timeSpentMs) timeSpentMs = changes.timeSpentMs.newValue;
      });
    } catch (_) {}
  }

  /* ─── 3. 초기 값 로드 ─── */
  if (canSync()) {
    try {
      chrome.storage.sync.get(
        ["timeSpentMs", "lastResetDate", "limitTimeSec"],
        data => {
          if (!canSync()) return;
          const today = new Date().toDateString();
          if (data.lastResetDate !== today) {
            chrome.storage.sync.set({ timeSpentMs: 0, lastResetDate: today });
            timeSpentMs = 0;
          } else {
            timeSpentMs = data.timeSpentMs || 0;
          }
          lastResetDate = data.lastResetDate || today;
          limitTimeSec  = data.limitTimeSec ?? 60;
        }
      );
    } catch (_) {}
  }

  /* ─── 4. URL 변화 감지 (History API 패치) ─── */
  let currentHref = location.href;
  const fireUrlChange = () => window.dispatchEvent(new Event("urlchange"));
  ["pushState", "replaceState"].forEach(fn => {
    const raw = history[fn];
    history[fn] = function () {
      raw.apply(this, arguments);
      fireUrlChange();
    };
  });
  window.addEventListener("popstate", fireUrlChange);
  window.addEventListener("urlchange", () => {
    if (currentHref !== location.href) {
      currentHref = location.href;
      updateOverlays(true); // 흔적 초기화
    }
  });

  /* ─── 5. Page Visibility ─── */
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      hiddenStart = Date.now();
    } else if (hiddenStart !== null) {
      const delta = Date.now() - hiddenStart;
      hiddenStart = null;
      if (isEntryStory()) addSharedTime(delta);
      lastTickTime = Date.now();
    }
  });

  /* ─── 6. 메인 루프 (0.5 초) ─── */
  const TICK_MS = 500;
  const tickId = setInterval(() => {
    const now = Date.now();
    const delta = now - lastTickTime;
    lastTickTime = now;

    document
      .querySelector('textarea#Write[name="Write"]')
      ?.setAttribute("placeholder", "정말로 글을 쓰실 생각인가요?");

    const today = new Date().toDateString();
    if (lastResetDate !== today && canSync()) {
      lastResetDate = today;
      timeSpentMs = bufferMs = 0;
      try {
        chrome.storage.sync.set({ timeSpentMs: 0, lastResetDate: today });
      } catch (_) {}
    }

    if (isEntryStory()) addSharedTime(delta);

    updateOverlays();
  }, TICK_MS);

  /* ─── 7. 오버레이 & 블러 ─── */
  function isEntryStory() {
    return location.href.startsWith(
      "https://playentry.org/community/entrystory"
    );
  }

  function updateOverlays(forceClear = false) {
    const totalSec = Math.floor(timeSpentMs / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;

    if (forceClear) {
      document.querySelectorAll(".entry-blocker-overlay").forEach(e => e.remove());
      document.querySelectorAll("[data-entry-blurred]").forEach(el => {
        el.removeAttribute("data-entry-blurred");
        for (const ch of el.children) {
          ch.style.filter = "";
          ch.style.pointerEvents = "";
        }
      });
    }

    if (isEntryStory()) {
      document.querySelectorAll(
        "div.css-v98ur4.eq36rvw4, div.css-1eth5pr.e1yi8oq65"
      ).forEach(el => {
        el.innerHTML =
          `<span style="font-size:1.8em;">당신은 오늘 </span>` +
          `<span style="color:#16d8a3;font-size:2.3em;font-weight:600;">${min}분 ${sec.toString().padStart(2, "0")}초</span>` +
          `<span style="font-size:1.8em;"> 동안 엔트리 이야기에 들어가 있었습니다.</span><br>` +
          `<strong style="font-size:2.5em;">중독입니까?</strong>`;
      });
    }

    if (limitTimeSec == null || totalSec < limitTimeSec) return;

    document.querySelectorAll(
      "div.css-1uvivr9.e1h77j9v11, div.css-ahy3yn.euhmxlr3"
    ).forEach(el => {
      if (!el.hasAttribute("data-entry-blurred")) {
        for (const ch of el.children) {
          ch.style.filter = "blur(5px)";
          ch.style.pointerEvents = "none";
        }
        el.setAttribute("data-entry-blurred", "true");
      }

      el.querySelector(".entry-blocker-overlay")?.remove();

      const ov = document.createElement("div");
      ov.className = "entry-blocker-overlay";
      ov.textContent = "제한 시간을 초과하였습니다.";
      Object.assign(ov.style, {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        fontSize: "1.5em",
        zIndex: "9999",
        pointerEvents: "none"
      });
      el.style.position = "relative";
      el.appendChild(ov);
    });
  }

  /* ─── 8. 탭 종료 전 마지막 flush ─── */
  window.addEventListener("beforeunload", () => {
    const delta = Date.now() - lastTickTime;
    if (isEntryStory()) addSharedTime(delta);
    flushBuffered(true);
  });
})();
