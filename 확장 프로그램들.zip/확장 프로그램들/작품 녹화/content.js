// 전역 변수
let recordingInterval = null;
let isRecording = false;
let mediaRecorder = null;
let recordedChunks = [];
let observer = null;
let debounceTimer = null;
let lastBodyClass = '';
let buttonAdded = false;

// DOM 변경 감지 시작
function startObserver() {
  // 초기 body 클래스 저장
  lastBodyClass = document.body.className;
  
  // 디바운스 함수 - 짧은 시간 내 여러 번 호출되는 것 방지
  function debounce(func, delay) {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }
    debounceTimer = setTimeout(func, delay);
  }
  
  // MutationObserver 설정
  observer = new MutationObserver((mutations) => {
    let needsUpdate = false;
    let bodyClassChanged = false;
    
    // 중요한 변경사항이 있는지 확인
    for (const mutation of mutations) {
      // body 클래스 변경 확인
      if (mutation.type === 'attributes' && 
          mutation.target.tagName === 'BODY' && 
          mutation.attributeName === 'class') {
          
        // 이전 클래스와 현재 클래스 비교
        const currentBodyClass = document.body.className;
        if (currentBodyClass !== lastBodyClass) {
          lastBodyClass = currentBodyClass;
          bodyClassChanged = true;
          needsUpdate = true;
          break;
        }
      }
      
      // 캔버스 또는 버튼 관련 요소 변경 확인
      if (!needsUpdate && (
          mutation.target.id === 'entryCanvas' || 
          mutation.target.classList?.contains('canvasButton') ||
          mutation.target.classList?.contains('entryEngineButtonMinimize'))) {
        needsUpdate = true;
      }
      
      // 버튼 추가/제거 요소 확인
      if (!needsUpdate && mutation.type === 'childList') {
        // 녹화 버튼이 제거되었는지 확인
        const removedButtons = Array.from(mutation.removedNodes).some(node => 
          node.classList?.contains('entry-record-button')
        );
        
        if (removedButtons) {
          buttonAdded = false;
          needsUpdate = true;
        }
      }
    }
    
    // 필요한 경우에만 DOM 업데이트
    if (needsUpdate) {
      debounce(() => {
        if (bodyClassChanged) {
          // body 클래스 변경 시 모든 버튼 제거 후 다시 추가
          removeRecordButtons();
          buttonAdded = false;
          setTimeout(() => {
            checkAndAddRecordButton();
          }, 100);
        } else if (!buttonAdded) {
          // 버튼이 없을 때만 추가
          checkAndAddRecordButton();
        }
      }, 200); // 짧은 시간 동안 변경사항 모아서 처리
    }
  });

  // 전체 문서 변경 감시 (좀 더 선택적으로)
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'id']
  });
  
  // iframe 감시
  observeIframes();
}

// iframe 감시
function observeIframes() {
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach(iframe => {
    try {
      // iframe이 로드될 때 감시
      iframe.addEventListener('load', () => {
        try {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
          observer.observe(iframeDoc.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class', 'id']
          });
          
          // iframe 내부에 캔버스가 있는지 확인 (바로 추가하지 않음)
          setTimeout(() => {
            if (!buttonAdded) {
              checkAndAddRecordButton();
            }
          }, 300);
        } catch (e) {
          // iframe 접근 오류 - 크로스 오리진일 수 있음
        }
      });
      
      // 이미 로드된 iframe 처리
      if (iframe.contentDocument) {
        const iframeDoc = iframe.contentDocument;
        observer.observe(iframeDoc.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['class', 'id']
        });
      }
    } catch (e) {
      // iframe 감시 오류 - 무시
    }
  });
}

// 문서 또는 iframe에서 요소 찾기
function findElementsInDocOrFrames(selector) {
  let elements = Array.from(document.querySelectorAll(selector));
  
  // iframe에서도 검색
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach(iframe => {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      const iframeElements = Array.from(iframeDoc.querySelectorAll(selector));
      elements = elements.concat(iframeElements);
    } catch (e) {
      // 크로스 오리진 iframe은 접근 불가능할 수 있음
    }
  });
  
  return elements;
}

// 조건 확인 및 녹화 버튼 추가
function checkAndAddRecordButton() {
  // 이미 버튼이 추가되었는지 확인
  if (buttonAdded) {
    const existingButtons = document.querySelectorAll('.entry-record-button');
    if (existingButtons.length > 0) {
      return; // 이미 버튼이 있으면 다시 추가하지 않음
    }
  }
  
  // 캔버스 요소 찾기
  const canvasElements = findElementsInDocOrFrames('canvas#entryCanvas');
  if (canvasElements.length === 0) {
    return; // 캔버스 없음
  }

  // body에 modal_open 클래스가 있는지 확인
  let isModalOpen = false;
  if (document.body.classList.contains('modal_open')) {
    isModalOpen = true;
  } else {
    // iframe인 경우 부모의 modal_open 확인
    try {
      if (window !== window.top) {
        isModalOpen = window.top.document.body.classList.contains('modal_open');
      }
    } catch (e) {
      // 크로스 오리진 iframe, 부모 접근 불가
    }
  }

  let buttonAdded = false;
  
  if (isModalOpen) {
    // 모달 내 최소화 버튼 찾기
    const minimizeButtons = findElementsInDocOrFrames('button.entryEngineButtonMinimize');
    
    // 첫 번째 최소화 버튼에만 녹화 버튼 추가
    if (minimizeButtons.length > 0) {
      addRecordButton(minimizeButtons[0], 'after', canvasElements[0]);
      buttonAdded = true;
    }
  } else {
    // 캔버스 버튼 요소 찾기
    const canvasButtons = findElementsInDocOrFrames('div.canvasButton');
    
    // 첫 번째 캔버스 버튼에만 녹화 버튼 추가
    if (canvasButtons.length > 0) {
      addRecordButton(canvasButtons[0], 'after', canvasElements[0]);
      buttonAdded = true;
    }
  }
  
  // 전역 상태 업데이트
  window.buttonAdded = buttonAdded;
}

// 녹화 버튼 생성 및 추가
function addRecordButton(targetElement, position, canvasElement) {
  // 중복 버튼 확인 - 이미 있으면 추가하지 않음
  const existingButtons = document.querySelectorAll('.entry-record-button');
  if (existingButtons.length > 0) {
    return;
  }
  
  // 부모 노드가 없는 경우 처리
  if (!targetElement || !targetElement.parentNode) {
    return;
  }
  
  // 녹화 버튼 생성
  const recordButton = document.createElement('button');
  recordButton.classList.add('entry-record-button');
  recordButton.id = 'entry-record-button';
  recordButton.style.width = '40px';
  recordButton.style.height = '40px';
  recordButton.style.borderRadius = '50%';
  recordButton.style.backgroundColor = 'white';
  recordButton.style.border = '2px solid #ddd';
  recordButton.style.margin = '0 5px';
  recordButton.style.cursor = 'pointer';
  recordButton.style.display = 'flex';
  recordButton.style.justifyContent = 'center';
  recordButton.style.alignItems = 'center';
  recordButton.style.position = 'relative';
  recordButton.style.zIndex = '10000';
  
  // 녹화 아이콘 생성 (처음에는 녹화, 중지 아님)
  const recordIcon = document.createElement('div');
  recordIcon.style.width = '16px';
  recordIcon.style.height = '16px';
  recordIcon.style.borderRadius = '50%';
  recordIcon.style.backgroundColor = 'red';
  
  recordButton.appendChild(recordIcon);
  
  // 툴팁 추가
  recordButton.title = '캔버스 녹화하기';
  
  // 클릭 이벤트 추가
  recordButton.addEventListener('click', () => {
    toggleRecording(canvasElement, recordButton);
  });
  
  // 타겟 요소 뒤에 버튼 추가
  try {
    if (position === 'after') {
      targetElement.parentNode.insertBefore(recordButton, targetElement.nextSibling);
    } else {
      targetElement.parentNode.insertBefore(recordButton, targetElement);
    }
    
    // 버튼 추가 성공 표시
    buttonAdded = true;
  } catch (e) {
    // 버튼 추가 실패
    buttonAdded = false;
  }
}

// 모든 녹화 버튼 제거
function removeRecordButtons() {
  // 상태 초기화
  buttonAdded = false;
  
  // 문서에서 버튼 제거
  const buttons = document.querySelectorAll('.entry-record-button');
  buttons.forEach(button => {
    button.remove();
  });
  
  // iframe에서도 버튼 제거
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach(iframe => {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      const iframeButtons = iframeDoc.querySelectorAll('.entry-record-button');
      iframeButtons.forEach(button => {
        button.remove();
      });
    } catch (e) {
      // 크로스 오리진 iframe일 수 있음
    }
  });
}

// 녹화 상태 전환
function toggleRecording(canvasElement, button) {
  // 실행 버튼 존재 여부 확인하여 녹화 또는 일시중지 결정
  const runButtonExists = checkIfRunButtonExists();
  
  if (!isRecording && runButtonExists) {
    startRecording(canvasElement, button);
  } else if (isRecording && !runButtonExists) {
    pauseRecording(canvasElement, button);
  } else if (isRecording) {
    stopRecording(canvasElement, button);
  }
}

// 실행 버튼 존재 여부 확인
function checkIfRunButtonExists() {
  const curtain = findElementsInDocOrFrames('div.entryRunButtonBigMinimizeCurtain');
  const runButton = findElementsInDocOrFrames('div.entryRunButtonBigMinimize.run');
  
  return curtain.length > 0 || runButton.length > 0;
}

// 캔버스 녹화 시작
function startRecording(canvasElement, button) {
  if (isRecording) return;
  
  isRecording = true;
  recordedChunks = [];
  
  // 버튼을 중지 아이콘으로 업데이트
  const iconElement = button.firstChild;
  iconElement.style.width = '14px';
  iconElement.style.height = '14px';
  iconElement.style.borderRadius = '2px';
  iconElement.style.backgroundColor = 'red';
  
  // 녹화 중임을 표시하는 빨간 테두리 추가
  canvasElement.style.border = '3px solid red';
  
  // 캔버스 녹화 설정
  const stream = canvasElement.captureStream(30); // 30 FPS
  
  // MediaRecorder 생성
  mediaRecorder = new MediaRecorder(stream, {
    mimeType: 'video/webm;codecs=vp9'
  });
  
  // 녹화된 데이터 처리
  mediaRecorder.ondataavailable = (event) => {
    if (event.data.size > 0) {
      recordedChunks.push(event.data);
    }
  };
  
  // 녹화 중지 처리
  mediaRecorder.onstop = () => {
    // 녹화된 청크에서 blob 생성
    const blob = new Blob(recordedChunks, {
      type: 'video/webm'
    });
    
    // 다운로드 링크 생성
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = 'entry-recording.webm';
    document.body.appendChild(a);
    a.click();
    
    // 정리
    setTimeout(() => {
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }, 100);
  };
  
  // 녹화 시작
  mediaRecorder.start(1000); // 1초마다 데이터 수집
  
  // 실행 버튼이 여전히 존재하는지 확인하는 간격 설정
  recordingInterval = setInterval(() => {
    if (!checkIfRunButtonExists()) {
      pauseRecording(canvasElement, button);
    }
  }, 500);
}

// 녹화 일시 중지
function pauseRecording(canvasElement, button) {
  if (!isRecording) return;
  
  // 레코더를 중지하지 않고 일시 중지
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.pause();
  }
  
  // 버튼을 녹화 아이콘으로 업데이트
  const iconElement = button.firstChild;
  iconElement.style.width = '16px';
  iconElement.style.height = '16px';
  iconElement.style.borderRadius = '50%';
  
  // 빨간 테두리 제거
  canvasElement.style.border = '';
  
  clearInterval(recordingInterval);
}

// 녹화 완전 중지
function stopRecording(canvasElement, button) {
  if (!isRecording) return;
  
  isRecording = false;
  
  // 미디어 레코더 중지
  if (mediaRecorder) {
    if (mediaRecorder.state === 'recording' || mediaRecorder.state === 'paused') {
      mediaRecorder.stop();
    }
  }
  
  // 버튼을 녹화 아이콘으로 업데이트
  const iconElement = button.firstChild;
  iconElement.style.width = '16px';
  iconElement.style.height = '16px';
  iconElement.style.borderRadius = '50%';
  
  // 빨간 테두리 제거
  canvasElement.style.border = '';
  
  clearInterval(recordingInterval);
}

// 새 iframe 추가 감지
function observeNewIframes() {
  const iframeObserver = new MutationObserver((mutations) => {
    let newIframesAdded = false;
    
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(node => {
          if (node.tagName === 'IFRAME') {
            console.log('New iframe detected');
            newIframesAdded = true;
          }
        });
      }
    }
    
    if (newIframesAdded) {
      console.log('New iframes added, updating observers');
      // 버튼 제거 후 다시 추가
      removeRecordButtons();
      // 지연 후 프레임 감지 및 버튼 추가
      setTimeout(() => {
        observeIframes();
        checkAndAddRecordButton();
      }, 100);
    }
  });
  
  iframeObserver.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
}

// 초기화
function initialize() {
  // 전역 변수 초기화
  recordingInterval = null;
  isRecording = false;
  mediaRecorder = null;
  recordedChunks = [];
  observer = null;
  debounceTimer = null;
  lastBodyClass = '';
  buttonAdded = false;
  
  // 처음 실행 시 약간 지연 후 시작 (페이지 완전히 로드 후)
  setTimeout(() => {
    startObserver();
    observeNewIframes();
    checkAndAddRecordButton();
  }, 500);
  
  // 페이지 가시성 변경 시 버튼 상태 확인
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      // 페이지 포커스 돌아올 때 버튼 확인
      setTimeout(() => {
        if (!buttonAdded) {
          checkAndAddRecordButton();
        }
      }, 300);
    }
  });
}

// 문서 로드 완료 시 초기화 실행
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize);
} else {
  initialize();
}