chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'textUpdated') {
      // Handle the updated text, e.g., show a notification
      console.log('Updated text:', message.text);
      // Optionally, show a notification
      chrome.notifications.create({
        type: 'basic',
        title: 'Text Updated',
        message: message.text,
        iconUrl: 'icon48.png'
      });
    }
  });