// Replace 'your-selector' with the actual selector of the text element
const target = document.querySelector('your-selector');

if (target) {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' || mutation.type === 'characterData') {
        const updatedText = target.textContent;
        chrome.runtime.sendMessage({
          type: 'textUpdated',
          text: updatedText
        });
      }
    });
  });

  observer.observe(target, { childList: true, subtree: true, characterData: true });
} else {
  console.error('Target element not found.');
}