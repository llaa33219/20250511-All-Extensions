document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ type: 'requestText' }, (response) => {
      if (response && response.text) {
        document.getElementById('textContent').innerText = response.text;
      }
    });
  });