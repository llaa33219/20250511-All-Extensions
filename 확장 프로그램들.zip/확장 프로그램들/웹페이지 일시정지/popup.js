document.addEventListener("DOMContentLoaded", () => {
    const shortcutInput = document.getElementById("shortcut");
    const speedInput = document.getElementById("speed");
    const saveBtn = document.getElementById("saveBtn");
    const pauseBtn = document.getElementById("pauseBtn");
    const resumeBtn = document.getElementById("resumeBtn");
    const blockNetworkBtn = document.getElementById("blockNetworkBtn");
    const unblockNetworkBtn = document.getElementById("unblockNetworkBtn");
  
    chrome.storage.local.get(["shortcutKey", "playbackSpeed"], (res) => {
      if (res.shortcutKey) shortcutInput.value = res.shortcutKey;
      if (res.playbackSpeed) speedInput.value = res.playbackSpeed;
    });
  
    shortcutInput.addEventListener("keydown", (e) => {
      e.preventDefault();
      const keys = [];
      if (e.ctrlKey) keys.push("Control");
      if (e.shiftKey) keys.push("Shift");
      if (e.altKey) keys.push("Alt");
      keys.push(e.key);
      shortcutInput.value = keys.join("+");
    });
  
    saveBtn.addEventListener("click", () => {
      const shortcutVal = shortcutInput.value.trim();
      const speedVal = parseFloat(speedInput.value);
      if (!shortcutVal) {
        alert("단축키를 입력하세요.");
        return;
      }
      if (isNaN(speedVal) || speedVal < 0.1 || speedVal > 10) {
        alert("재생 속도는 0.1 ~ 10 범위로 설정하세요.");
        return;
      }
      chrome.storage.local.set({
        shortcutKey: shortcutVal,
        playbackSpeed: speedVal
      }, () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if (tabs[0] && tabs[0].id !== undefined) {
            chrome.tabs.sendMessage(tabs[0].id, {action: "updateSpeed", speed: speedVal});
          }
        });
        window.close();
      });
    });
  
    pauseBtn.addEventListener("click", () => {
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if (tabs[0] && tabs[0].id !== undefined) {
          chrome.tabs.sendMessage(tabs[0].id, {action: "pauseAll"});
        }
      });
    });
  
    resumeBtn.addEventListener("click", () => {
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if (tabs[0] && tabs[0].id !== undefined) {
          chrome.tabs.sendMessage(tabs[0].id, {action: "resumeAll"});
        }
      });
    });
  
    blockNetworkBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({action: "blockAll"}, (resp) => {
        console.log("네트워크 차단 완료:", resp);
      });
    });
  
    unblockNetworkBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({action: "unblockAll"}, (resp) => {
        console.log("네트워크 허용 완료:", resp);
      });
    });
  });
  