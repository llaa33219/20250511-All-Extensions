chrome.runtime.onInstalled.addListener(() => {
    chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [],
      removeRuleIds: []
    });
  });
  
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "unblockAll") {
      chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ["ruleset_1"] }, () => {
        sendResponse({ result: "OK" });
      });
      return true;
    } else if (msg.action === "blockAll") {
      chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ["ruleset_1"] }, () => {
        sendResponse({ result: "OK" });
      });
      return true;
    }
  });
  