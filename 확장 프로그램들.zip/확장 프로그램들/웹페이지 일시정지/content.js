const originalSetTimeout = window.setTimeout;
const originalClearTimeout = window.clearTimeout;
const originalSetInterval = window.setInterval;
const originalClearInterval = window.clearInterval;
const originalRequestAnimationFrame = window.requestAnimationFrame;
const originalCancelAnimationFrame = window.cancelAnimationFrame || window.webkitCancelAnimationFrame;
const originalDateNow = Date.now;
const originalPerfNow = performance.now.bind(performance);
const originalPlay = HTMLMediaElement.prototype.play;
const originalPause = HTMLMediaElement.prototype.pause;

let audioContexts = [];
let isPaused = false;
let currentSpeed = 1.0;
let currentShortcut = "";

let timeouts = [];
let intervals = [];
let rafIds = [];

let baseDateTime = originalDateNow();
let basePerfTime = originalPerfNow();
let pausedDateTime = 0;
let pausedPerfTime = 0;

(function overrideAudioContext(){
  const AC = window.AudioContext || window.webkitAudioContext;
  if (AC) {
    const OverAC = function() {
      const ac = new AC();
      audioContexts.push(ac);
      return ac;
    };
    window.AudioContext = OverAC;
    if (window.webkitAudioContext) {
      window.webkitAudioContext = OverAC;
    }
  }
})();

window.setTimeout = function(fn, delay, ...args){
  const scaled = delay / currentSpeed;
  const id = originalSetTimeout(() => {
    timeouts = timeouts.filter(t => t.id !== id);
    fn();
  }, scaled, ...args);
  timeouts.push({id, fn, delay: scaled});
  return id;
};

window.clearTimeout = function(id){
  originalClearTimeout(id);
  timeouts = timeouts.filter(t => t.id !== id);
};

window.setInterval = function(fn, delay, ...args){
  const scaled = delay / currentSpeed;
  const id = originalSetInterval(fn, scaled, ...args);
  intervals.push({id, fn, delay: scaled});
  return id;
};

window.clearInterval = function(id){
  originalClearInterval(id);
  intervals = intervals.filter(i => i.id !== id);
};

window.requestAnimationFrame = function(cb){
  if (isPaused) {
    return 0;
  }
  const id = originalRequestAnimationFrame((ts) => {
    const scaledTS = (ts - basePerfTime) * currentSpeed + basePerfTime;
    cb(scaledTS);
    rafIds = rafIds.filter(r => r !== id);
  });
  rafIds.push(id);
  return id;
};

window.cancelAnimationFrame = function(id){
  originalCancelAnimationFrame(id);
  rafIds = rafIds.filter(r => r !== id);
};

Date.now = function(){
  if (isPaused) {
    return baseDateTime + pausedDateTime;
  } else {
    const diff = originalDateNow() - (baseDateTime + pausedDateTime);
    return baseDateTime + pausedDateTime + diff * currentSpeed;
  }
};

performance.now = function(){
  if (isPaused) {
    return basePerfTime + pausedPerfTime;
  } else {
    const diff = originalPerfNow() - (basePerfTime + pausedPerfTime);
    return basePerfTime + pausedPerfTime + diff * currentSpeed;
  }
};

HTMLMediaElement.prototype.play = function(){
  if (isPaused) {
    return Promise.resolve();
  } else {
    this.playbackRate = currentSpeed;
    return originalPlay.apply(this, arguments);
  }
};

HTMLMediaElement.prototype.pause = function(){
  return originalPause.apply(this, arguments);
};

function pauseAll(){
  if (isPaused) return;
  timeouts.forEach(t => originalClearTimeout(t.id));
  intervals.forEach(i => originalClearInterval(i.id));
  rafIds.forEach(r => originalCancelAnimationFrame(r));

  timeouts = [];
  intervals = [];
  rafIds = [];

  const pauseStyle = document.getElementById("stop-everything-pause-style");
  if (pauseStyle) pauseStyle.remove();
  const st = document.createElement("style");
  st.id = "stop-everything-pause-style";
  st.innerHTML = `
    * {
      animation-play-state: paused !important;
      transition-property: none !important;
    }
  `;
  document.head.appendChild(st);

  document.querySelectorAll("video, audio").forEach(m => {
    try { m.pause(); } catch(e){}
  });
  audioContexts.forEach(ac => {
    if (ac.state === "running") {
      ac.suspend().catch(() => {});
    }
  });

  const realNow = originalDateNow();
  const realPerf = originalPerfNow();
  pausedDateTime = realNow - baseDateTime - pausedDateTime;
  pausedPerfTime = realPerf - basePerfTime - pausedPerfTime;

  isPaused = true;
}

function resumeAll(){
  if (!isPaused) return;
  const pStyle = document.getElementById("stop-everything-pause-style");
  if (pStyle) pStyle.remove();

  const runStyle = document.getElementById("stop-everything-run-style");
  if (runStyle) runStyle.remove();
  const st = document.createElement("style");
  st.id = "stop-everything-run-style";
  st.innerHTML = `
    * {
      animation-play-state: running !important;
    }
  `;
  document.head.appendChild(st);

  document.querySelectorAll("video, audio").forEach(m => {
    try {
      m.playbackRate = currentSpeed;
      m.play();
    } catch(e){}
  });
  audioContexts.forEach(ac => {
    if (ac.state === "suspended") {
      ac.resume().catch(() => {});
    }
  });

  const now = originalDateNow();
  const pnow = originalPerfNow();
  baseDateTime = now - (baseDateTime + pausedDateTime);
  basePerfTime = pnow - (basePerfTime + pausedPerfTime);
  pausedDateTime = 0;
  pausedPerfTime = 0;

  isPaused = false;
}

function updateSpeed(spd){
  currentSpeed = spd;
  document.querySelectorAll("video, audio").forEach(m => {
    try {
      m.playbackRate = spd;
    } catch(e){}
  });
  const speedStyle = document.getElementById("stop-everything-speed-style");
  if (speedStyle) speedStyle.remove();
  const sst = document.createElement("style");
  sst.id = "stop-everything-speed-style";
  sst.innerHTML = `
    * {
      animation-duration: calc(1s / ${spd}) !important;
      transition-duration: calc(1s / ${spd}) !important;
    }
  `;
  document.head.appendChild(sst);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "pauseAll") {
    pauseAll();
  } else if (msg.action === "resumeAll") {
    resumeAll();
  } else if (msg.action === "updateSpeed") {
    updateSpeed(msg.speed);
  }
  return true;
});

chrome.storage.local.get(["shortcutKey","playbackSpeed"], (res) => {
  if (res.shortcutKey) currentShortcut = res.shortcutKey;
  if (res.playbackSpeed) {
    currentSpeed = res.playbackSpeed;
    updateSpeed(currentSpeed);
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.shortcutKey) {
      currentShortcut = changes.shortcutKey.newValue;
    }
    if (changes.playbackSpeed) {
      currentSpeed = changes.playbackSpeed.newValue;
      updateSpeed(currentSpeed);
    }
  }
});

document.addEventListener("keydown", (e) => {
  if (!currentShortcut) return;
  const keys = currentShortcut.split("+");
  const lastKey = keys[keys.length - 1].toLowerCase();
  const ctrlNeeded = keys.includes("Control");
  const shiftNeeded = keys.includes("Shift");
  const altNeeded = keys.includes("Alt");

  if (
    e.key.toLowerCase() === lastKey &&
    e.ctrlKey === ctrlNeeded &&
    e.shiftKey === shiftNeeded &&
    e.altKey === altNeeded
  ) {
    if (isPaused) {
      resumeAll();
    } else {
      pauseAll();
    }
  }
});
