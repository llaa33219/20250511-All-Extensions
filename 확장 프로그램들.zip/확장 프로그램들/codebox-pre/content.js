(function() {
  // chrome.runtime API는 확장 프로그램 컨텍스트에서만 사용 가능합니다.
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getURL) {
    console.error("chrome.runtime API를 사용할 수 없습니다. 이 코드는 Chrome 확장 프로그램 컨텍스트에서만 작동합니다.");
    return;
  }

  /**
   * 가장 가까운 <code> 요소를 찾기 위한 함수.
   * copy 버튼의 형제나 상위 요소를 순회하여 <code> 요소를 반환합니다.
   * @param {HTMLElement} element 시작 요소.
   * @return {HTMLElement|null} 찾은 <code> 요소 또는 null.
   */
  function findNearestCodeElement(element) {
    if (element.tagName && element.tagName.toLowerCase() === "code") {
      return element;
    }
    if (element.previousElementSibling && element.previousElementSibling.tagName.toLowerCase() === "code") {
      return element.previousElementSibling;
    }
    if (element.nextElementSibling && element.nextElementSibling.tagName.toLowerCase() === "code") {
      return element.nextElementSibling;
    }
    let container = element.closest("pre");
    if (container) {
      const code = container.querySelector("code");
      if (code) return code;
    }
    container = element.parentElement;
    while (container && container !== document.body) {
      if (container.tagName.toLowerCase() === "code") {
        return container;
      }
      const code = container.querySelector("code");
      if (code) return code;
      container = container.parentElement;
    }
    return null;
  }

  /**
   * sandbox.html을 iframe으로 로드하여 Python 코드를 실행하는 함수.
   * @param {string} code Python 코드 문자열.
   * @return {Promise<string>} 실행 결과 문자열 또는 에러 메시지.
   */
  function runPythonViaSandbox(code) {
    return new Promise((resolve, reject) => {
      const sandboxUrl = chrome.runtime.getURL("sandbox.html");
      const iframe = document.createElement("iframe");
      iframe.style.display = "none"; // 화면에 보이지 않도록
      iframe.src = sandboxUrl;
      document.body.appendChild(iframe);

      // 타임아웃: 20초 후 응답 없으면 타임아웃 처리
      const timeoutId = setTimeout(() => {
        window.removeEventListener("message", handleMessage);
        if (iframe.parentNode) {
          document.body.removeChild(iframe);
        }
        reject("타임아웃: sandbox에서 응답이 오지 않았습니다.");
      }, 20000);

      function handleMessage(event) {
        if (event.source === iframe.contentWindow) {
          clearTimeout(timeoutId);
          window.removeEventListener("message", handleMessage);
          if (iframe.parentNode) {
            document.body.removeChild(iframe);
          }
          if (event.data.error) {
            reject(event.data.error);
          } else {
            resolve(event.data.result);
          }
        }
      }
      window.addEventListener("message", handleMessage);

      iframe.onload = () => {
        console.log("sandbox iframe loaded, sending code for execution");
        try {
          iframe.contentWindow.postMessage(code, "*");
        } catch (err) {
          clearTimeout(timeoutId);
          window.removeEventListener("message", handleMessage);
          if (iframe.parentNode) {
            document.body.removeChild(iframe);
          }
          reject("postMessage error: " + err.toString());
        }
      };

      iframe.onerror = (err) => {
        clearTimeout(timeoutId);
        window.removeEventListener("message", handleMessage);
        if (iframe.parentNode) {
          document.body.removeChild(iframe);
        }
        reject("iframe error: " + err.toString());
      };
    });
  }

  /**
   * HTML 코드를 미리보기하기 위한 함수.
   * inline 스크립트 실행을 위해 iframe에 sandbox="allow-scripts"를 설정합니다.
   * @param {string} code HTML 코드 문자열.
   */
  function runHTMLPreview(code) {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts");
    iframe.style.width = "100%";
    iframe.style.height = "400px";
    iframe.style.border = "1px solid #ccc";
    iframe.srcdoc = code;
    showModal("HTML 미리보기", iframe);
  }

  /**
   * JavaScript 코드를 실행하는 함수.
   * @param {string} code JavaScript 코드 문자열.
   */
  function runJavaScript(code) {
    try {
      const result = new Function(code)();
      alert("JavaScript 실행 결과:\n" + result);
    } catch (e) {
      alert("JavaScript 실행 에러:\n" + e);
    }
  }

  /**
   * 간단한 모달 팝업을 생성하여 내용을 표시합니다.
   * @param {string} title 팝업 제목.
   * @param {HTMLElement} contentElement 표시할 내용.
   */
  function showModal(title, contentElement) {
    let existingOverlay = document.getElementById("code-runner-popup-overlay");
    if (existingOverlay) {
      existingOverlay.remove();
    }
    let existingPopup = document.getElementById("code-runner-popup");
    if (existingPopup) {
      existingPopup.remove();
    }
    const overlay = document.createElement("div");
    overlay.id = "code-runner-popup-overlay";
    const popup = document.createElement("div");
    popup.id = "code-runner-popup";

    const header = document.createElement("div");
    header.style.display = "flex";
    header.style.justifyContent = "space-between";
    header.style.alignItems = "center";
    header.style.marginBottom = "10px";

    const titleElem = document.createElement("span");
    titleElem.innerText = title;
    titleElem.style.fontWeight = "bold";

    const closeBtn = document.createElement("button");
    closeBtn.innerText = "X";
    closeBtn.className = "close-btn";
    closeBtn.addEventListener("click", () => {
      overlay.remove();
      popup.remove();
    });

    header.appendChild(titleElem);
    header.appendChild(closeBtn);
    popup.appendChild(header);
    popup.appendChild(contentElement);

    document.body.appendChild(overlay);
    document.body.appendChild(popup);
  }

  /**
   * 결과를 표시할 <pre> 요소를 생성합니다.
   * @param {string} text 결과 텍스트.
   * @return {HTMLElement} 결과 표시용 요소.
   */
  function createResultElement(text) {
    const pre = document.createElement("pre");
    pre.style.whiteSpace = "pre-wrap";
    pre.textContent = text;
    return pre;
  }

  /**
   * copy 버튼(aria-label="Copy")의 왼쪽에 "실행" 버튼을 추가합니다.
   * 코드 요소는 copy 버튼의 형제나 부모 체인 내에서 <code> 요소를 찾습니다.
   */
  function addRunButtons() {
    const copyButtons = document.querySelectorAll("button[aria-label='Copy']");
    copyButtons.forEach(copyButton => {
      try {
        if (copyButton.dataset.hasRunButton === "true") return;

        const runButton = document.createElement("button");
        runButton.innerText = "실행";
        runButton.style.marginRight = "4px";

        if (copyButton.parentNode) {
          copyButton.parentNode.insertBefore(runButton, copyButton);
        } else {
          console.warn("copyButton에 부모 노드가 없습니다.", copyButton);
          return;
        }
        copyButton.dataset.hasRunButton = "true";

        let codeElement = findNearestCodeElement(copyButton);
        if (!codeElement) {
          console.warn("코드 요소를 찾을 수 없습니다.", copyButton);
          return;
        }

        let language = "plaintext";
        codeElement.classList.forEach(cls => {
          if (cls.indexOf("language-python") !== -1) {
            language = "python";
          } else if (cls.indexOf("language-html") !== -1) {
            language = "html";
          } else if (cls.indexOf("language-js") !== -1 || 
                     cls.indexOf("language-javascript") !== -1) {
            language = "javascript";
          }
        });

        runButton.addEventListener("click", () => {
          const code = codeElement.innerText;
          if (language === "python") {
            runPythonViaSandbox(code)
              .then(result => {
                showModal("Python 실행 결과", createResultElement(result));
              })
              .catch(err => {
                showModal("Python 실행 에러", createResultElement(err));
              });
          } else if (language === "html") {
            runHTMLPreview(code);
          } else if (language === "javascript") {
            runJavaScript(code);
          } else {
            alert("현재 지원되는 언어는 Python, HTML, JavaScript입니다.");
          }
        });
      } catch (e) {
        console.error("addRunButtons 처리 중 에러:", e);
      }
    });
  }

  // 초기 실행: 페이지 내의 기존 copy 버튼에 대해 실행 버튼을 추가합니다.
  addRunButtons();

  // DOM 변화가 있을 때 실행 버튼을 다시 추가하기 위해 MutationObserver 사용.
  const observer = new MutationObserver(() => {
    addRunButtons();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
