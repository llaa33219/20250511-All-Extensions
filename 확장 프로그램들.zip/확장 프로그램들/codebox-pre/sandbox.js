async function initPyodideAndListen() {
    // 온라인으로 제공되는 Pyodide를 indexURL을 통해 로드합니다.
    self.pyodide = await loadPyodide({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.23.3/full/" });
    window.addEventListener('message', async (event) => {
      if (event.data && event.data.type === 'runPython') {
        try {
          await pyodide.runPythonAsync(`
  import sys
  import io
  _buffer = io.StringIO()
  sys.stdout = _buffer
          `);
          await pyodide.runPythonAsync(event.data.code);
          let output = await pyodide.runPythonAsync('sys.stdout.getvalue()');
          await pyodide.runPythonAsync('sys.stdout = sys.__stdout__');
          window.parent.postMessage({ type: 'pythonResult', result: output }, "*");
        } catch (e) {
          window.parent.postMessage({ type: 'pythonResult', result: "Error: " + e.message }, "*");
        }
      }
    });
  }
  
  initPyodideAndListen();
  