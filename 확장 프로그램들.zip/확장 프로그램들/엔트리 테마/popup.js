document.addEventListener('DOMContentLoaded', () => {
  const darkChk = document.getElementById('darkMode');
  const coldChk = document.getElementById('coldMode');

  // 저장된 테마 체크
  chrome.storage.sync.get('selectedTheme', (data) => {
    if (data.selectedTheme === 'dark') {
      darkChk.checked = true;
      coldChk.checked = false;
    } else if (data.selectedTheme === 'cold') {
      darkChk.checked = false;
      coldChk.checked = true;
    } else {
      darkChk.checked = false;
      coldChk.checked = false;
    }
  });

  darkChk.addEventListener('change', () => {
    if (darkChk.checked) {
      coldChk.checked = false;
      chrome.storage.sync.set({ selectedTheme: 'dark' });
    } else {
      if (!coldChk.checked) {
        chrome.storage.sync.set({ selectedTheme: 'none' });
      }
    }
  });

  coldChk.addEventListener('change', () => {
    if (coldChk.checked) {
      darkChk.checked = false;
      chrome.storage.sync.set({ selectedTheme: 'cold' });
    } else {
      if (!darkChk.checked) {
        chrome.storage.sync.set({ selectedTheme: 'none' });
      }
    }
  });
});
