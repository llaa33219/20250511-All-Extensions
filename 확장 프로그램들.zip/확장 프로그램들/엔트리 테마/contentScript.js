(function(){
    // 이미 변환한 요소 기록
    const processedSet = new WeakSet();
    let observer = null;
  
    // ------------------------- 
    // Lab 변환에 필요한 함수
    // ------------------------- 
    function srgbToLab(r,g,b){ /* sRGB->XYZ->Lab 변환 */ /* 생략(아래 상세코드) */ }
    function labToSrgb(L,a,b){ /* Lab->XYZ->sRGB 변환 */ /* 생략(아래 상세코드) */ }
  
    // 실제 변환함수 (축약)
    function transformDark(r,g,b){
      // 특정색 치환
      if(r===22 && g===216 && b===163){
        return [114,85,238];
      }
      const [L,a_,b_] = srgbToLab(r,g,b);
      let Lmod = L*0.5;
      if(Lmod<10) Lmod=10; 
      if(Lmod>90) Lmod=90;
      return labToSrgb(Lmod,a_,b_);
    }
    function transformCold(r,g,b){
      let [L,a_,b_] = srgbToLab(r,g,b);
      L*=1.05; if(L>100) L=100;
      b_*=1.3; 
      a_*=0.8;
      return labToSrgb(L,a_,b_);
    }
  
    function parseColor(strColor){ /* 'rgb(255,255,255)', '#abc' 등 파싱 */ /* 생략 */ }
  
    function recolorElement(el, theme){
      const tag = el.tagName.toLowerCase();
      if(tag==='canvas'||tag==='img'||tag==='iframe') return;
      const inlineStyle=(el.getAttribute('style')||'').toLowerCase();
      if(inlineStyle.includes('background-image')) return;
  
      const cs=window.getComputedStyle(el);
  
      // color
      const cRGB = parseColor(cs.color);
      if(cRGB){
        const [r2,g2,b2]=(theme==='dark')
          ? transformDark(cRGB[0],cRGB[1],cRGB[2])
          : transformCold(cRGB[0],cRGB[1],cRGB[2]);
        el.style.color=`rgb(${r2},${g2},${b2})`;
      }
      // background-color
      // border-color
      // outline-color
      // fill/stroke (SVG)
      // box-shadow
      // ... (이전 답변 참조, 동일)
  
      processedSet.add(el);
    }
  
    function applyLabTheme(theme){
      const allElems=document.querySelectorAll('*');
      allElems.forEach(el=>{
        if(!processedSet.has(el)){
          recolorElement(el,theme);
        }
      });
    }
  
    function applyTheme(theme){
      if(observer){
        observer.disconnect();
        observer=null;
      }
      processedSet.clear(); 
  
      if(!theme || theme==='none') return;
  
      applyLabTheme(theme);
  
      observer=new MutationObserver(muts=>{
        applyLabTheme(theme);
      });
      observer.observe(document.documentElement, {
        childList:true,
        subtree:true
      });
    }
  
    // 1) 초기
    chrome.storage.sync.get('selectedTheme',(data)=>{
      applyTheme(data.selectedTheme);
    });
    // 2) 변경
    chrome.storage.onChanged.addListener((changes, areaName)=>{
      if(areaName==='sync' && changes.selectedTheme){
        applyTheme(changes.selectedTheme.newValue);
      }
    });
  
    console.log('[LAB] contentScript loaded', location.href);
  })();
  