window.addEventListener('load', function() {
    // Function to disable existing styles for .css-1j7ibx
    function disableExistingStyles() {
        const styles = document.querySelectorAll('style');
        styles.forEach(style => {
            if (style.innerText.includes('.css-1j7ibx')) {
                style.innerText = style.innerText.replace('.css-1j7ibx', '.css-1j7ibx-disabled');
            }
        });
    }

    // Disable existing styles
    disableExistingStyles();

    // Add the new style for .css-1j7ibx
    let styleElement = document.createElement('style');
    styleElement.innerText = `
        .css-1j7ibx {
            display: block !important;
            position: static !important;
            inset: 0px;
            z-index: 120 !important;
            background-color: rgba(0, 0, 0, 0) !important;
        }
        
        .css-1ad1slj {
            flex: 1 1 0px;
            overflow-y: auto;
            padding: 18px;
            background-color: rgba(210, 213, 220, 0);
            box-shadow: rgba(0, 0, 0, 0) 0px 10px 8px 0px;
            box-sizing: border-box;
        }
        
        .css-8al697 {
            position: static;
            inset: 0px;
            border-style: solid;
            border-color: rgba(0, 0, 0, 0);
            z-index: 120;
        }

        canvas {
            overflow-clip-margin: padding-box;
            overflow: visible;
        }

        .css-15638m7 {
            position: static;
            top: 0px;
            bottom: 0px;
            left: 0px;
            z-index: 30;
            width: 74px;
            background-color: rgba(247, 249, 250, 0);
            text-align: center;
        }

        .css-1qwsq2j::before {
            position: static;
            top: -31px;
            left: 0px;
            width: 74px;
            height: 30px;
            content: "";
            background: url(https://www.google.com/url?sa=i&url=https%3A%2F%2Fblog.naver.com%2Ftableset10%2F221193252898&psig=AOvVaw3yzP7f6AUKrS93mwHD5qMo&ust=1722173814372000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCODApMWrx4cDFQAAAAAdAAAAABAJ) 0% 0% / 74px no-repeat;
        }

        .css-1qwsq2j {
            position: fixed;
            bottom: 0px;
            left: 0px;
            background-color: rgba(233, 241, 244, 0);
            padding: 17px 8px;
            border-top: 1px solid rgba(221, 228, 231, 0);
        }

        .css-1njmbsg {
            position: absolute;
            top: 50%;
            left: calc(51px);
            width: 46px;
            height: 46px;
            border-radius: 50%;
            background-color: rgba(247, 249, 250, 0);
            transform: translateY(-50%);
        }
    `;
    document.head.appendChild(styleElement);
});
