/* globals chrome */
const USNT = {
  /** 북마크 폴더 확보 */
  async ensureFolder() {
    const title = 'Unlimited shortcuts New Tab';
    const found = await chrome.bookmarks.search({ title });
    return found.length ? found[0] : chrome.bookmarks.create({ title });
  },

  /** 폴더의 링크 수집 */
  async getLinks(folderId) {
    const nodes = await chrome.bookmarks.getChildren(folderId);
    return nodes.filter(n => n.url);
  },

  /** UI 새로 그리기 */
  async render(folderId) {
    const overlay = document.getElementById('usnt-overlay');
    overlay.querySelectorAll('.usnt-tile:not(.usnt-add)').forEach(e => e.remove());

    const links = await USNT.getLinks(folderId);
    links.forEach(link => {
      const tile = document.createElement('div');
      tile.className = 'usnt-tile';
      tile.innerHTML = `<img src="chrome://favicon/size/64@1x/${link.url}"><span>${link.title}</span>`;
      tile.onclick = () => location.href = link.url;
      overlay.insertBefore(tile, document.getElementById('usnt-add'));
    });
  },

  /** 북마크 추가 */
  async addBookmark(folderId) {
    const url = prompt('URL 입력:');
    if (!url) return;
    const title = prompt('표시명 입력:', url);
    if (title === null) return;
    await chrome.bookmarks.create({ parentId: folderId, title, url });
    USNT.render(folderId);
  },

  /** 배경 로드 */
  async loadBg() {
    const { bgDataUrl } = await chrome.storage.sync.get('bgDataUrl');
    if (bgDataUrl) document.body.style.backgroundImage = `url(${bgDataUrl})`;
  },

  /** 배경 선택 */
  async pickBg() {
    const fp = document.createElement('input');
    fp.type = 'file'; fp.accept = 'image/*';
    fp.onchange = async () => {
      const file = fp.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async e => {
        const bgDataUrl = e.target.result;
        await chrome.storage.sync.set({ bgDataUrl });
        document.body.style.backgroundImage = `url(${bgDataUrl})`;
      };
      reader.readAsDataURL(file);
    };
    fp.click();
  }
};

(async () => {
  // <div id="usnt-overlay"> & 배경 버튼 삽입
  const overlay = document.createElement('div');
  overlay.id = 'usnt-overlay';
  overlay.innerHTML = `<div id="usnt-add" class="usnt-tile usnt-add">＋</div>`;
  document.body.appendChild(overlay);

  const bgBtn = document.createElement('button');
  bgBtn.id = 'usnt-bgBtn';
  bgBtn.textContent = '🎨';
  document.body.appendChild(bgBtn);

  // 기능 연결
  const folder = await USNT.ensureFolder();
  await USNT.loadBg();
  await USNT.render(folder.id);

  document.getElementById('usnt-add').onclick = () => USNT.addBookmark(folder.id);
  bgBtn.onclick = USNT.pickBg;
})();
