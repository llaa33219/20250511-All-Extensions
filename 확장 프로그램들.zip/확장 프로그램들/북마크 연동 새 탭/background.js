// 새 탭이 열릴 때 Google로 리다이렉트
chrome.tabs.onCreated.addListener((tab) => {
    if (tab.pendingUrl === 'chrome://newtab/' || tab.url === 'chrome://newtab/') {
      chrome.tabs.update(tab.id, { url: 'https://www.google.com/' });
    }
  });
  
  // 확장 프로그램이 설치될 때 실행
  chrome.runtime.onInstalled.addListener(async () => {
    console.log('Unlimited shortcuts New Tab 확장 프로그램이 설치되었습니다.');
    
    // 북마크 폴더 생성 또는 확인
    await createBookmarkFolderIfNotExists();
  });
  
  // 북마크 폴더 생성 또는 확인
  async function createBookmarkFolderIfNotExists() {
    const BOOKMARK_FOLDER_NAME = 'Unlimited shortcuts New Tab';
    
    try {
      // 북마크 트리에서 폴더 찾기
      const bookmarkItems = await chrome.bookmarks.search({ title: BOOKMARK_FOLDER_NAME });
      
      if (bookmarkItems.length === 0) {
        // 폴더가 없으면 생성
        await chrome.bookmarks.create({
          parentId: '1', // 북마크 바 ID
          title: BOOKMARK_FOLDER_NAME
        });
        console.log(`'${BOOKMARK_FOLDER_NAME}' 북마크 폴더가 생성되었습니다.`);
      } else {
        console.log(`'${BOOKMARK_FOLDER_NAME}' 북마크 폴더가 이미 존재합니다.`);
      }
    } catch (error) {
      console.error('북마크 폴더 생성 오류:', error);
    }
  }
  
  // 메시지 리스너 등록
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getBookmarkFolder') {
      // 북마크 폴더 ID 반환
      chrome.bookmarks.search({ title: 'Unlimited shortcuts New Tab' }, (results) => {
        if (results.length > 0) {
          sendResponse({ folderId: results[0].id });
        } else {
          sendResponse({ folderId: null });
        }
      });
      return true; // 비동기 응답을 위해 true 반환
    }
  });