![image](https://github.com/user-attachments/assets/7224577b-5e98-444e-96e8-bea83d2ef086)
**<>code** 를 누른 후 **Download ZIP**를 눌러서 **zip파일로 다운로드**를 해줍니다.<br>
![image](https://github.com/user-attachments/assets/e198719a-26f3-4f02-bdd0-157b055abe51)<br>
**확장 프로그램**탭으로 들어가 줍니다.<br>
![image](https://github.com/user-attachments/assets/2ebddf5b-7c4b-4434-ae7e-2efaa68668d4)<br>
오른쪽 위에 **개발자 모드**를 눌러서 **개발자 모드를 활성화** 해줍니다.<br>
![image](https://github.com/user-attachments/assets/cfacf1c3-ff23-4243-a67b-bc66807feeba)<br>
이렇게 활성화가 되었으면 ![image](https://github.com/user-attachments/assets/ced14243-18d0-4d77-8d0c-54f369f802fa) 을 눌러서 **압축을 해제한 확장 프로그램 파일을 추가**해서 확장 프로그램을 추가해 줍니다.<br>
![image](https://github.com/user-attachments/assets/986558d5-918c-4427-9421-214dd43ee13d)
