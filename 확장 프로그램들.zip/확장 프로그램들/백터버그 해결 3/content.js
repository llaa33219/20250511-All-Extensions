// 원본 HTML snippet (링크는 무조건 원본 그대로):
// <li id="txoh" class="entryPlaygroundPictureElement entryPictureSelected"><div class="entryPlaygroundPictureOrder">3</div><div id="t_txoh" class="entryPlaygroundPictureThumbnail" style="background-image: url(&quot;/uploads/9c/57/thumb/9c572182618b3efa2c023ce3a03974f9.png&quot;);"></div><input class="entryPlaygroundPictureName entryEllipsis"><div id="s_txoh" class="entryPlaygroundPictureSize">211 X 345</div><div class="entryPlayground_del">삭제</div></li>

(function() {
    'use strict';

    // 백그라운드 이미지 style에서 URL 추출 함수
    function extractUrlFromStyle(style) {
        const match = style.match(/url\(["']?([^"')]+)["']?\)/);
        return match ? match[1] : null;
    }

    // SVG URL을 기록할 전역 변수 (변환된 경로만 기록, 나중에 "https://playentry.org" 접두어를 붙여 사용)
    let recordedSvgUrl = null;

    // 주어진 URL이 실제로 존재하는지 HEAD 요청을 통해 확인하는 함수
    function checkSvgExists(fullUrl) {
        return fetch(fullUrl, { method: 'HEAD' })
            .then(response => response.ok)
            .catch(() => false);
    }

    // "백터 버그를 해결" 버튼을 생성하여 기존 버튼 컨테이너에 추가하는 함수
    function addVectorBugFixButton(buttonContainer) {
        // 이미 추가되었으면 중복 추가하지 않음
        if (buttonContainer.querySelector('.vector-bug-fix-btn')) return;

        const newDiv = document.createElement('div');
        newDiv.className = 'sc-dtBdUo hHvdph';

        const newButton = document.createElement('button');
        newButton.className = 'sc-hmdomO cncwLk BaseCommonBtn vector-bug-fix-btn';
        newButton.setAttribute('role', 'button');
        newButton.textContent = '백터 버그를 해결한 모양을 다운로드';

        newDiv.appendChild(newButton);
        buttonContainer.appendChild(newDiv);

        // 버튼 클릭 시 SVG 파일을 불러와 ns1:href=를 xlink:href=로 변경 후, DOMParser로 <svg> 루트 요소만 추출하여 다운로드 실행
        newButton.addEventListener('click', function() {
            if (!recordedSvgUrl) {
                alert('SVG URL이 기록되어 있지 않습니다.');
                return;
            }
            const fullUrl = 'https://playentry.org' + recordedSvgUrl;
            fetch(fullUrl)
                .then(response => response.text())
                .then(svgText => {
                    // 모든 ns1:href= 를 xlink:href= 로 변경
                    let fixedSvg = svgText.replace(/ns1:href=/g, 'xlink:href=');
                    // DOMParser를 이용하여 SVG 문서를 파싱
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(fixedSvg, 'image/svg+xml');
                    const svgEl = doc.querySelector('svg');
                    if (!svgEl) {
                        alert('다운로드할 SVG를 찾을 수 없습니다.');
                        return;
                    }
                    // XMLSerializer로 <svg> 루트 요소만 직렬화하여 최종 SVG 문자열 생성
                    const finalSvg = new XMLSerializer().serializeToString(svgEl);
                    if (finalSvg.indexOf('ns1:href=') === -1) {
                        const blob = new Blob([finalSvg], { type: 'image/svg+xml' });
                        const downloadUrl = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = downloadUrl;
                        a.download = fullUrl.split('/').pop();
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(downloadUrl);
                    } else {
                        alert('버그가 여전히 존재합니다.');
                    }
                })
                .catch(error => {
                    console.error('SVG 파일을 불러오는 중 오류 발생:', error);
                });
        });
    }

    // 버튼 컨테이너(모양 가져오기, 저장하기 버튼이 있는 영역)가 DOM에 나타날 때까지 기다리는 함수
    function waitForButtonContainer(callback) {
        let container = document.querySelector('div.sc-iHGNWf.YLkFh');
        if (container) {
            callback(container);
        } else {
            const containerObserver = new MutationObserver((mutations, observer) => {
                container = document.querySelector('div.sc-iHGNWf.YLkFh');
                if (container) {
                    observer.disconnect();
                    callback(container);
                }
            });
            containerObserver.observe(document.body, { childList: true, subtree: true });
        }
    }

    // li 요소에서 백그라운드 이미지 URL을 검사 및 기록하는 함수
    function checkAndRecordSvg(liElement) {
        const thumbDiv = liElement.querySelector('div.entryPlaygroundPictureThumbnail');
        if (thumbDiv && thumbDiv.style.backgroundImage) {
            let url = extractUrlFromStyle(thumbDiv.style.backgroundImage);
            if (url) {
                url = url.trim();
                // "/thumb/"를 "/image/"로 변경
                url = url.replace('/thumb/', '/image/');
                // 파일 확장자가 .png인 경우 .svg로 변경
                url = url.replace(/\.png$/i, '.svg');
                const fullUrl = 'https://playentry.org' + url;
                // 실제 파일이 존재하는지 확인
                checkSvgExists(fullUrl).then(exists => {
                    if (exists) {
                        recordedSvgUrl = url; // 이후 접두어를 붙여 사용
                        waitForButtonContainer(function(buttonContainer) {
                            addVectorBugFixButton(buttonContainer);
                        });
                    }
                });
            }
        }
    }

    // li 요소에 클릭 이벤트를 부착하여 사용자가 선택할 때마다 URL을 갱신하도록 하는 함수
    function attachClickHandler(liElement) {
        liElement.addEventListener('click', function() {
            checkAndRecordSvg(liElement);
        });
    }

    // MutationObserver 콜백: li 태그가 추가될 때마다 검사하고 클릭 이벤트도 부착
    function observerCallback(mutationsList) {
        mutationsList.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        if (node.matches('li.entryPlaygroundPictureElement')) {
                            checkAndRecordSvg(node);
                            attachClickHandler(node);
                        }
                        node.querySelectorAll && node.querySelectorAll('li.entryPlaygroundPictureElement').forEach(li => {
                            checkAndRecordSvg(li);
                            attachClickHandler(li);
                        });
                    }
                });
            }
        });
    }

    // 문서 전체에 대해 MutationObserver 설정
    const observer = new MutationObserver(observerCallback);
    observer.observe(document.body, { childList: true, subtree: true });

    // 페이지 로드 시 기존 요소들에 대해 한 번 검사 및 클릭 이벤트 부착
    window.addEventListener('load', function() {
        document.querySelectorAll('li.entryPlaygroundPictureElement').forEach(li => {
            checkAndRecordSvg(li);
            attachClickHandler(li);
        });
    });

    // 현재 선택된(li.entryPictureSelected) 요소를 주기적으로 폴링하여 실시간 반영
    setInterval(function() {
        const selectedLi = document.querySelector('li.entryPlaygroundPictureElement.entryPictureSelected');
        if (selectedLi) {
            checkAndRecordSvg(selectedLi);
        }
    }, 300);
})();
