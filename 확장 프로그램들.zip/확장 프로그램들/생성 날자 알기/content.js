console.log("Content script loaded");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "convertURL") {
    console.log("Received convertURL action");
    const url = window.location.pathname;
    const parts = url.split('/');
    
    // 하위 링크 부분 추출 (4번째 부분부터 이어지는 부분)
    const subPath = parts.slice(4).join('/');

    if (subPath.length >= 8) {
      const charAt8 = subPath.charAt(7);  // 0-based index
      const modifiedString = subPath.substring(0, 8) + '.' + subPath.substring(8);

      // 8번째 문자와 그 뒤의 문자를 각각 10진수로 변환
      const part1 = charAt8.charCodeAt(0);
      const part2 = modifiedString.charCodeAt(9);

      // 10진수로 변환된 값을 소수점으로 조합
      const combinedValue = parseFloat(`${part1}.${part2}`);

      // 유닉스 타임스탬프로 변환
      const unixTimestamp = combinedValue * 1000;
      const date = new Date(unixTimestamp);
      const humanReadableDate = date.toLocaleString();

      console.log(`Modified String: ${modifiedString}`);
      console.log(`10진수 변환 1번째: ${part1}`);
      console.log(`10진수 변환 2번째: ${part2}`);
      console.log(`조합된 값: ${combinedValue}`);
      console.log(`Unix Timestamp: ${unixTimestamp}`);
      console.log(`Human-readable Date: ${humanReadableDate}`);

      sendResponse({
        modifiedString: modifiedString,
        part1: part1,
        part2: part2,
        combinedValue: combinedValue,
        unixTimestamp: unixTimestamp,
        humanReadableDate: humanReadableDate
      });
    } else {
      sendResponse({ error: "하위 링크 부분이 너무 짧습니다." });
    }
  }
  return true; // 비동기 응답을 사용하려면 true를 반환해야 함
});
