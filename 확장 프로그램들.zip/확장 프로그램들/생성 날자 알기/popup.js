document.getElementById('convertButton').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length === 0) {
      alert("No active tab found.");
      return;
    }

    chrome.scripting.executeScript(
      {
        target: { tabId: tabs[0].id },
        function: convertURL
      },
      (results) => {
        const resultDiv = document.getElementById('result');
        if (results && results[0] && results[0].result) {
          const response = results[0].result;
          if (response.error) {
            resultDiv.textContent = response.error;
            alert("Error: " + response.error);
          } else {
            resultDiv.innerHTML = `
              <p>Modified String: ${response.modifiedString}</p>
              <p>16진수 변환 1번째: ${response.part1}</p>
              <p>16진수 변환 2번째: ${response.part2}</p>
              <p>조합된 값: ${response.combinedValue}</p>
              <p>Unix Timestamp: ${response.unixTimestamp}</p>
              <p>Human-readable Date: ${response.humanReadableDate}</p>
            `;
            alert(`Human-readable Date: ${response.humanReadableDate}`);
          }
        } else {
          resultDiv.textContent = "No response from content script.";
          alert("No response from content script.");
        }
      }
    );
  });
});

function convertURL() {
  try {
    const url = window.location.pathname;
    const parts = url.split('/');
    const subPath = parts.slice(3).join('/');

    if (parts[1] === 'profile' || parts[1] === 'project') {
      // Profile 또는 Project인 경우 별도의 처리
      return convertShortURL(parts);
    } else {
      // 그 외의 경우 일반 처리
      if (subPath.length >= 8) {
        const charAt8 = subPath.charAt(7);  // 0-based index
        const modifiedString = subPath.substring(0, 8) + '.' + subPath.substring(8);

        // 8번째 문자와 그 뒤의 문자를 각각 16진수로 변환
        const part1Hex = subPath.substring(0, 8);
        const part2Hex = subPath.substring(8);

        // 16진수를 10진수로 변환
        const part1 = parseInt(part1Hex, 16);
        const part2 = parseInt(part2Hex, 16);

        // 10진수로 변환된 값을 소수점으로 조합
        const combinedValue = parseFloat(`${part1}.${part2}`);

        // 유닉스 타임스탬프로 변환
        const unixTimestamp = combinedValue;
        const date = new Date(unixTimestamp * 1000);
        const humanReadableDate = date.toLocaleString();

        return {
          modifiedString: modifiedString,
          part1: part1,
          part2: part2,
          combinedValue: combinedValue,
          unixTimestamp: unixTimestamp,
          humanReadableDate: humanReadableDate
        };
      } else {
        return { error: "하위 링크 부분이 너무 짧습니다." };
      }
    }
  } catch (e) {
    return { error: e.message };
  }
}

function convertShortURL(parts) {
  try {
    const subPath = parts.slice(2).join('/');
    if (subPath.length >= 1) {
      const part1Hex = subPath.padEnd(8, '0');
      const part2Hex = '0'.repeat(8);

      // 16진수를 10진수로 변환
      const part1 = parseInt(part1Hex, 16);
      const part2 = parseInt(part2Hex, 16);

      // 10진수로 변환된 값을 소수점으로 조합
      const combinedValue = parseFloat(`${part1}.${part2}`);

      // 유닉스 타임스탬프로 변환
      const unixTimestamp = combinedValue;
      const date = new Date(unixTimestamp * 1000);
      const humanReadableDate = date.toLocaleString();

      return {
        modifiedString: subPath,
        part1: part1,
        part2: part2,
        combinedValue: combinedValue,
        unixTimestamp: unixTimestamp,
        humanReadableDate: humanReadableDate
      };
    } else {
      return { error: "하위 링크가 없습니다." };
    }
  } catch (e) {
    return { error: e.message };
  }
}
