// 설정
const config = {
    selectors: {
      regButton: 'a[data-btn-type="login"][data-testid="button"]',
      commentTextarea: '#Write'
    },
    endpoints: {
      imageUpload: 'https://playentry.org/rest/picture',
      createComment: 'https://playentry.org/graphql/CREATE_COMMENT'
    },
    stickers: {
      defaultStickerId: '6049a7d7cea5c400506e9bee',
      defaultStickerItemId: '6049ab66b9d3cd007d0dedf5'
    }
  };
  
  // 등록 버튼을 찾아 이미지 업로드 버튼 추가하기
  function observeForRegButton() {
    const observer = new MutationObserver((mutations) => {
      const regButton = document.querySelector(config.selectors.regButton);
      if (regButton && !document.querySelector('#imageUploadButton')) {
        addImageUploadButton(regButton);
        // 버튼을 찾고 추가했으니 관찰 중단
        observer.disconnect();
      }
    });
  
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  // 이미지 업로드 버튼 추가
  function addImageUploadButton(regButton) {
    const uploadButton = document.createElement('button');
    uploadButton.textContent = '이미지 선택 후 업로드';
    uploadButton.id = 'imageUploadButton';
    uploadButton.style.marginLeft = '10px';
    uploadButton.addEventListener('click', handleImageUpload);
    
    regButton.parentNode.insertBefore(uploadButton, regButton.nextSibling);
  }
  
  // 이미지 업로드 처리
  async function handleImageUpload() {
    // 파일 입력 요소 생성
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    
    // 파일 선택 처리
    fileInput.addEventListener('change', async (event) => {
      const file = event.target.files[0];
      if (file) {
        try {
          // 이미지 업로드
          const imageData = await uploadImage(file);
          
          // 이미지로 댓글 작성
          if (imageData && imageData._id) {
            await submitCommentWithImage(imageData);
          }
        } catch (error) {
          console.error('업로드 과정에서 오류 발생:', error);
          alert('업로드 실패: ' + error.message);
        }
      }
    });
    
    // 파일 선택 다이얼로그 열기
    fileInput.click();
  }
  
  // 이미지 업로드 함수
  async function uploadImage(file) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', 'notcompress');
    formData.append('generateThumb', 'true');
    
    try {
      const response = await fetch(config.endpoints.imageUpload, {
        method: 'POST',
        headers: {
          'accept': 'application/json, text/plain, */*'
        },
        body: formData,
        mode: 'cors',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`이미지 업로드 실패: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('이미지 업로드 성공:', data);
      return data;
    } catch (error) {
      console.error('이미지 업로드 오류:', error);
      throw new Error('이미지 업로드 실패. 다시 시도해주세요.');
    }
  }
  
  // URL에서 타겟 추출
  function extractTarget() {
    let target = '';
    const urlMatch = window.location.pathname.match(/\/project\/([^/]+)/);
    if (urlMatch && urlMatch[1]) {
      target = urlMatch[1];
    }
    return target;
  }
  
  // CSRF 토큰 추출
  function extractCsrfToken() {
    // 1. 먼저 meta 태그에서 찾기
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    if (csrfMeta && csrfMeta.getAttribute('content')) {
      return csrfMeta.getAttribute('content');
    }
    
    // 2. HTML 내의 스크립트에서 찾기
    let csrfToken = '';
    try {
      // 페이지 내 모든 스크립트 태그 탐색
      const scripts = document.querySelectorAll('script:not([src])');
      for (const script of scripts) {
        const content = script.textContent;
        // CSRF 토큰을 포함할 수 있는 패턴 찾기
        const csrfMatch = content.match(/csrfToken[\s]*[=:][\s]*["']([^"']+)["']/);
        if (csrfMatch && csrfMatch[1]) {
          csrfToken = csrfMatch[1];
          break;
        }
      }
    } catch (e) {
      console.error('CSRF 토큰 추출 중 오류:', e);
    }
    
    // 3. 폼 요소에서 찾기
    if (!csrfToken) {
      const csrfInput = document.querySelector('input[name="_csrf"], input[name="csrf-token"], input[name="csrf"]');
      if (csrfInput) {
        csrfToken = csrfInput.value;
      }
    }
    
    return csrfToken;
  }
  
  // X-Token 추출
  function extractXToken() {
    let xToken = '';
    
    // 1. HTML 내의 스크립트에서 X-Token 찾기
    try {
      const scripts = document.querySelectorAll('script:not([src])');
      for (const script of scripts) {
        const content = script.textContent;
        
        // X-Token을 포함할 수 있는 다양한 패턴 찾기
        const tokenPatterns = [
          /token[\s]*[=:][\s]*["']([^"']+)["']/,
          /x-token[\s]*[=:][\s]*["']([^"']+)["']/,
          /xToken[\s]*[=:][\s]*["']([^"']+)["']/,
          /authToken[\s]*[=:][\s]*["']([^"']+)["']/,
          /eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\.[^"'\s}]+/  // JWT 패턴 찾기
        ];
        
        for (const pattern of tokenPatterns) {
          const match = content.match(pattern);
          if (match && match[1]) {
            xToken = match[1];
            break;
          }
        }
        
        if (xToken) break;
      }
    } catch (e) {
      console.error('X-Token 추출 중 오류:', e);
    }
    
    // 2. data 속성에서 찾기
    if (!xToken) {
      const elemWithToken = document.querySelector('[data-token], [data-x-token]');
      if (elemWithToken) {
        xToken = elemWithToken.dataset.token || elemWithToken.dataset.xToken;
      }
    }
    
    // 3. 네트워크 요청 헤더에서 캡처된 토큰이 페이지에 숨겨져 있는 경우
    if (!xToken) {
      // 페이지에서 JWT 패턴 찾기
      const pageContent = document.documentElement.outerHTML;
      const jwtPattern = /eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\.[^"'\s<>]+\.[^"'\s<>]+/g;
      const jwtMatches = pageContent.match(jwtPattern);
      
      if (jwtMatches && jwtMatches.length > 0) {
        xToken = jwtMatches[0]; // 첫 번째 JWT 형식 토큰 사용
      }
    }
    
    return xToken;
  }
  
  // 이미지와 함께 댓글 작성
  async function submitCommentWithImage(imageData) {
    // 댓글 내용 가져오기
    const textarea = document.querySelector(config.selectors.commentTextarea);
    const commentContent = textarea ? textarea.value : '';
    
    // URL에서 타겟 가져오기
    const target = extractTarget();
    if (!target) {
      alert('프로젝트 대상을 찾을 수 없습니다. 프로젝트 페이지에 있는지 확인해주세요.');
      return;
    }
    
    // 필요한 토큰 가져오기
    const csrfToken = extractCsrfToken();
    const xToken = extractXToken();
    if (!csrfToken || !xToken) {
      alert('인증 토큰을 추출할 수 없습니다. 로그인되어 있는지 확인해주세요.');
      return;
    }
    
    // GraphQL 쿼리 준비
    const requestBody = {
      query: `
      mutation CREATE_COMMENT(
          
      $content: String
      $image: String
      $sticker: ID
      $stickerItem: ID
      $target: String
      $targetSubject: String
      $targetType: String
      $groupId: ID
  
      ) {
          createComment(
              
      content: $content
      image: $image
      sticker: $sticker
      stickerItem: $stickerItem
      target: $target
      targetSubject: $targetSubject
      targetType: $targetType
      groupId: $groupId
  
          ) {
              warning
              comment {
                  
      id
      user {
          
      id
      nickname
      profileImage {
          
      id
      name
      label {
          
      ko
      en
      ja
      vn
  
      }
      filename
      imageType
      dimension {
          
      width
      height
  
      }
      trimmed {
          filename
          width
          height
      }
  
      }
      status {
          following
          follower
      }
      description
      role
      mark {
          
      id
      name
      label {
          
      ko
      en
      ja
      vn
  
      }
      filename
      imageType
      dimension {
          
      width
      height
  
      }
      trimmed {
          filename
          width
          height
      }
   
      }
  
      }
      content
      created
      removed
      blamed
      blamedBy
      commentsLength
      likesLength
      isLike
      hide
      pinned
      image {
          
      id
      name
      label {
          
      ko
      en
      ja
      vn
  
      }
      filename
      imageType
      dimension {
          
      width
      height
  
      }
      trimmed {
          filename
          width
          height
      }
  
      }
      sticker {
          
      id
      name
      label {
          
      ko
      en
      ja
      vn
  
      }
      filename
      imageType
      dimension {
          
      width
      height
  
      }
      trimmed {
          filename
          width
          height
      }
  
      }
  
              }
          }
      }
  `,
      variables: {
        content: commentContent,
        image: imageData._id, // 업로드한 이미지 ID 사용
        sticker: imageData._id, // 기본 스티커 ID 유지
        stickerItem: config.stickers.defaultStickerItemId, // 기본 스티커 아이템 ID 유지
        target: target,
        targetSubject: 'project',
        targetType: 'individual'
      }
    };
    
    try {
      const response = await fetch(config.endpoints.createComment, {
        method: 'POST',
        headers: {
          'accept': '*/*',
          'content-type': 'application/json',
          'csrf-token': csrfToken,
          'x-client-type': 'Client',
          'x-token': xToken
        },
        body: JSON.stringify(requestBody),
        mode: 'cors',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`댓글 작성 실패: ${response.status}`);
      }
      
      const result = await response.json();
      console.log('댓글 작성 성공:', result);
      alert('이미지와 함께 댓글이 성공적으로 작성되었습니다!');
      
      // 성공 후 댓글 영역 초기화
      if (textarea) {
        textarea.value = '';
      }
    } catch (error) {
      console.error('댓글 작성 오류:', error);
      throw new Error('댓글 작성 실패. 다시 시도해주세요.');
    }
  }
  
  // 페이지 로드 시 실행
  window.addEventListener('load', () => {
    observeForRegButton();
    
    // 또한 버튼이 이미 DOM에 있는 경우 즉시 확인
    const regButton = document.querySelector(config.selectors.regButton);
    if (regButton && !document.querySelector('#imageUploadButton')) {
      addImageUploadButton(regButton);
    }
  });