// Handle errors
function handleError(errorMessage) {
    // Update status to show error
    updateStatus('error', workflowState.currentStep);
    
    // Add error message to conversation
    addMessageToConversation('system', `Error: ${errorMessage}`);
    
    // Notify popup
    chrome.runtime.sendMessage({
      type: 'workflowError',
      error: errorMessage
    });
    
    // Retry logic could be added here
  }// Background script to manage the workflow process
  
  // Workflow state
  let workflowState = {
    status: 'idle',
    currentStep: 0,
    userPrompt: '',
    plan: [],
    stepResponses: [],
    finalResponse: '',
    chatGptTab: null
  };
  
  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'startWorkflow') {
      startWorkflow(message.userPrompt);
    }
  });
  
  // Listen for messages from content scripts
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Received message from content script:', message.type);
    
    if (message.type === 'contentScriptReady') {
      console.log('Content script is ready in tab:', sender.tab.id, 'URL:', message.url);
      handleContentScriptReady(sender.tab.id);
    } else if (message.type === 'planCreated') {
      console.log('Plan created with', message.plan.length, 'steps');
      handlePlanCreated(message.plan);
    } else if (message.type === 'stepCompleted') {
      console.log('Step', message.stepNumber, 'completed');
      handleStepCompleted(message.stepNumber, message.response);
    } else if (message.type === 'evaluationComplete') {
      console.log('Evaluation complete');
      handleEvaluationComplete(message.result);
    } else if (message.type === 'error') {
      console.error('Error from content script:', message.error);
      // Handle error, possibly retry or notify user
      handleError(message.error);
    }
  });
  
  // Start the workflow process
  async function startWorkflow(userPrompt) {
    // Reset workflow state
    workflowState = {
      status: 'starting',
      currentStep: 0,
      userPrompt,
      plan: [],
      stepResponses: [],
      finalResponse: '',
      chatGptTab: null
    };
    
    // Update status
    updateStatus('planning', 0);
    
    // Add user message to conversation
    addMessageToConversation('user', userPrompt);
    
    // Open ChatGPT
    await openChatGpt();
    
    // Content script will take over from here
  }
  
  // Function to open ChatGPT in a new tab
  async function openChatGpt() {
    return new Promise((resolve) => {
      chrome.tabs.create({ url: 'https://chatgpt.com/' }, (tab) => {
        workflowState.chatGptTab = tab.id;
        resolve(tab);
      });
    });
  }
  
  // Handle when content script is ready
  function handleContentScriptReady(tabId) {
    console.log('Handling content script ready, comparing tab IDs:', tabId, workflowState.chatGptTab);
    
    if (tabId === workflowState.chatGptTab) {
      // The content script is ready, send it the current workflow state
      console.log('Sending startProcessing message to content script');
      
      // 약간 지연 후 메시지 전송 (페이지가 완전히 로드되도록)
      setTimeout(() => {
        chrome.tabs.sendMessage(tabId, {
          type: 'startProcessing',
          state: workflowState
        }, (response) => {
          // 응답이 없는 경우 오류 체크
          if (chrome.runtime.lastError) {
            console.error('Error sending message to content script:', chrome.runtime.lastError);
          } else if (response) {
            console.log('Content script responded:', response);
          }
        });
      }, 2000);
    } else {
      console.log('Tab ID mismatch, not sending workflow state');
    }
  }
  
  // Handle when the 40-step plan is created
  function handlePlanCreated(plan) {
    workflowState.plan = plan;
    workflowState.currentStep = 1;
    updateStatus('executing', 1);
    
    // Add the plan to the conversation
    const planMessage = "Created a 40-step plan:\n\n" + plan.map((step, i) => `${i+1}. ${step}`).join('\n');
    addMessageToConversation('assistant', planMessage);
    
    // Close the current tab and open a new one for the first step
    chrome.tabs.remove(workflowState.chatGptTab, async () => {
      await openChatGpt();
    });
  }
  
  // Handle when a step is completed
  function handleStepCompleted(stepNumber, response) {
    workflowState.stepResponses[stepNumber - 1] = response;
    
    // Add the step response to the conversation
    addMessageToConversation('assistant', `Step ${stepNumber} completed: ${response.substring(0, 100)}...`);
    
    if (stepNumber < 40) {
      // Move to the next step
      workflowState.currentStep = stepNumber + 1;
      updateStatus('executing', stepNumber + 1);
      
      // Close the current tab and open a new one for the next step
      chrome.tabs.remove(workflowState.chatGptTab, async () => {
        await openChatGpt();
      });
    } else {
      // All steps completed, move to evaluation
      updateStatus('evaluating', 40);
      
      // Close the current tab and open a new one for evaluation
      chrome.tabs.remove(workflowState.chatGptTab, async () => {
        await openChatGpt();
      });
    }
  }
  
  // Handle when the evaluation is complete
  function handleEvaluationComplete(result) {
    workflowState.finalResponse = result;
    updateStatus('completed', 40);
    
    // Add the final result to the conversation
    addMessageToConversation('assistant', `Final result: ${result}`);
    
    // Close the ChatGPT tab
    chrome.tabs.remove(workflowState.chatGptTab);
    
    // Notify popup that workflow is complete
    chrome.runtime.sendMessage({
      type: 'workflowComplete'
    });
  }
  
  // Function to update status
  function updateStatus(status, step) {
    workflowState.status = status;
    workflowState.currentStep = step;
    
    // Update storage
    chrome.storage.local.set({
      workflowStatus: status,
      currentStep: step
    });
    
    // Notify popup
    chrome.runtime.sendMessage({
      type: 'statusUpdate',
      status,
      step
    });
  }
  
  // Function to add a message to the conversation
  function addMessageToConversation(role, content) {
    chrome.storage.local.get(['conversation'], (result) => {
      const conversation = result.conversation || [];
      conversation.push({ role, content });
      chrome.storage.local.set({ conversation });
    });
    
    // Notify popup
    chrome.runtime.sendMessage({
      type: 'newMessage',
      role,
      content
    });
  }