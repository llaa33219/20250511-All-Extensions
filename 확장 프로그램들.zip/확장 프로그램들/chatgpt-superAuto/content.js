// Content script to interact with ChatGPT

// Global variables
let currentState = null;
let responseObserver = null;
let responseElement = null;
let lastResponseText = '';
let responseStabilityCounter = 0;

// Utility function to wait for page load
function waitForPageLoad() {
  return new Promise((resolve) => {
    if (document.readyState === 'complete') {
      resolve();
    } else {
      window.addEventListener('load', resolve);
    }
  });
}

// Utility function to wait for an element
function waitForElement(selector, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    // Check if element already exists
    const element = document.querySelector(selector);
    if (element) {
      return resolve(element);
    }
    
    // Set up timeout
    const timeout = setTimeout(() => {
      observer.disconnect();
      reject(new Error(`Timeout waiting for element: ${selector}`));
    }, timeoutMs);
    
    // Set up observer
    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (element) {
        clearTimeout(timeout);
        observer.disconnect();
        resolve(element);
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  });
}

// Find textarea input element
function findTextInput() {
  // Try multiple selectors
  const selectors = [
    '#prompt-textarea',
    'textarea[placeholder*="Send a message"]',
    'textarea',
    'div[contenteditable="true"]'
  ];
  
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      console.log(`Found text input with selector: ${selector}`);
      return element;
    }
  }
  
  // Last resort: find any textarea
  const textareas = document.getElementsByTagName('textarea');
  if (textareas.length > 0) {
    console.log('Found textarea by tag name');
    return textareas[0];
  }
  
  return null;
}

// Find send button
function findSendButton() {
  // Try multiple selectors
  const selectors = [
    'button[data-testid="send-button"]',
    'button[aria-label="Send message"]',
    'button.absolute.p-1'
  ];
  
  for (const selector of selectors) {
    const button = document.querySelector(selector);
    if (button) {
      console.log(`Found send button with selector: ${selector}`);
      return button;
    }
  }
  
  // Last resort: find button with SVG near the textarea
  const textarea = findTextInput();
  if (textarea) {
    const buttons = Array.from(document.querySelectorAll('button'));
    for (const button of buttons) {
      if (button.querySelector('svg')) {
        const buttonRect = button.getBoundingClientRect();
        const textareaRect = textarea.getBoundingClientRect();
        
        // Check if button is nearby the textarea
        if (Math.abs(textareaRect.bottom - buttonRect.top) < 50 ||
            Math.abs(textareaRect.right - buttonRect.left) < 50) {
          console.log('Found send button by position near textarea');
          return button;
        }
      }
    }
  }
  
  return null;
}

// Find response element
function findResponseElement() {
  // Try multiple selectors
  const selectors = [
    'div[data-message-author-role="assistant"]',
    '.markdown',
    '.prose',
    '[data-testid^="conversation-turn-"]'
  ];
  
  for (const selector of selectors) {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      // Get the last element (most recent response)
      console.log(`Found response elements with selector: ${selector}`);
      return elements[elements.length - 1];
    }
  }
  
  // Last resort: find divs that might contain the response
  const divs = document.querySelectorAll('div.text-base');
  if (divs.length > 0) {
    console.log('Found potential response element by class');
    return divs[divs.length - 1];
  }
  
  return null;
}

// Extract text from response element
function extractResponseText(element) {
  if (!element) return '';
  
  // Clone the element to avoid modifying the page
  const clone = element.cloneNode(true);
  
  // Remove any script elements
  const scripts = clone.querySelectorAll('script, style, button');
  scripts.forEach(script => script.remove());
  
  // Get text content
  let text = clone.textContent.trim();
  
  // Remove any disclaimer texts that might appear at the end
  const disclaimers = [
    "ChatGPT can make mistakes",
    "I'm an AI",
    "I'm ChatGPT"
  ];
  
  for (const disclaimer of disclaimers) {
    const index = text.indexOf(disclaimer);
    if (index !== -1) {
      text = text.substring(0, index).trim();
    }
  }
  
  return text;
}

// Extract steps from response text
function extractSteps(text) {
  // Try to find numbered steps (1. Step, 2. Step, etc.)
  const stepRegex = /\b(\d+)\.[\s\n]+(.*?)(?=\n\s*\d+\.|$)/gs;
  const steps = [];
  let match;
  
  while ((match = stepRegex.exec(text)) !== null) {
    const stepNumber = parseInt(match[1]);
    const stepText = match[2].trim();
    
    if (stepNumber >= 1 && stepNumber <= 40) {
      steps[stepNumber - 1] = stepText;
    }
  }
  
  // Ensure we have 40 steps
  if (steps.length === 40 && steps.every(step => step)) {
    return steps;
  }
  
  // Fallback: split by newlines and look for lines starting with numbers
  const lines = text.split('\n');
  const candidateSteps = [];
  
  for (const line of lines) {
    const trimmed = line.trim();
    const numberMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
    if (numberMatch) {
      const stepNumber = parseInt(numberMatch[1]);
      const stepText = numberMatch[2].trim();
      
      if (stepNumber >= 1 && stepNumber <= 40) {
        candidateSteps[stepNumber - 1] = stepText;
      }
    }
  }
  
  if (candidateSteps.length === 40 && candidateSteps.every(step => step)) {
    return candidateSteps;
  }
  
  // Last resort: just take the first 40 non-empty lines
  return lines
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .slice(0, 40)
    .map((line, i) => line.replace(/^\d+\.\s+/, '').trim());
}

// Send text to ChatGPT
async function sendText(text) {
  try {
    // Wait for page to be fully loaded
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Find the input field
    const input = findTextInput();
    if (!input) {
      throw new Error('Could not find input field');
    }
    
    // Clear and focus the input
    input.focus();
    
    // Different handling based on element type
    if (input.tagName === 'TEXTAREA') {
      input.value = '';
      input.value = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      // For contenteditable divs
      input.textContent = '';
      input.textContent = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    // Find the send button
    const sendButton = findSendButton();
    if (!sendButton) {
      throw new Error('Could not find send button');
    }
    
    // Click the send button
    sendButton.click();
    console.log('Message sent');
    
    return true;
  } catch (error) {
    console.error('Error sending text:', error);
    return false;
  }
}

// Monitor for response
function monitorResponse(callback) {
  // Find the response element
  let attempts = 0;
  const maxAttempts = 10;
  let foundElement = false;
  
  const checkInterval = setInterval(async () => {
    attempts++;
    responseElement = findResponseElement();
    
    if (responseElement) {
      foundElement = true;
      clearInterval(checkInterval);
      
      // Start monitoring for changes
      lastResponseText = '';
      responseStabilityCounter = 0;
      
      responseObserver = new MutationObserver(() => {
        const currentText = extractResponseText(responseElement);
        
        if (currentText === lastResponseText) {
          responseStabilityCounter++;
          
          if (responseStabilityCounter >= 5) {
            responseObserver.disconnect();
            callback(currentText);
          }
        } else {
          lastResponseText = currentText;
          responseStabilityCounter = 0;
        }
      });
      
      responseObserver.observe(responseElement, {
        childList: true,
        subtree: true,
        characterData: true
      });
      
      // Set a timeout for the response as well
      setTimeout(() => {
        if (responseObserver) {
          responseObserver.disconnect();
          callback(extractResponseText(responseElement));
        }
      }, 60000);
    } else if (attempts >= maxAttempts) {
      clearInterval(checkInterval);
      console.error('Could not find response element after', maxAttempts, 'attempts');
      callback('');
    }
  }, 1000);
}

// Process planning stage
async function processPlanning() {
  console.log('Starting planning stage');
  
  const planningPrompt = `${currentState.userPrompt}\n\nPlease create a detailed 40-step plan for accomplishing this task. Format each step as a concise, actionable item in a numbered list.`;
  
  const sent = await sendText(planningPrompt);
  if (!sent) {
    chrome.runtime.sendMessage({
      type: 'error',
      error: 'Failed to send planning prompt'
    });
    return;
  }
  
  monitorResponse((responseText) => {
    console.log('Planning response received');
    
    if (responseText) {
      const plan = extractSteps(responseText);
      
      if (plan.length === 40) {
        chrome.runtime.sendMessage({
          type: 'planCreated',
          plan: plan
        });
      } else {
        chrome.runtime.sendMessage({
          type: 'error',
          error: `Could not extract 40 steps, found ${plan.length}`
        });
      }
    } else {
      chrome.runtime.sendMessage({
        type: 'error',
        error: 'Empty response received for planning'
      });
    }
  });
}

// Process a single step
async function processStep() {
  console.log(`Processing step ${currentState.currentStep}`);
  
  let stepPrompt = '';
  
  if (currentState.currentStep === 1) {
    // First step
    stepPrompt = `I am working on this task: "${currentState.userPrompt}"\n\nI have a 40-step plan. I'm on step 1: "${currentState.plan[0]}"\n\nPlease help me complete this step.`;
  } else {
    // Subsequent steps
    const previousStep = currentState.currentStep - 1;
    const previousResponse = currentState.stepResponses[previousStep - 1];
    
    stepPrompt = `I am working on this task: "${currentState.userPrompt}"\n\nI have a 40-step plan. I just completed step ${previousStep}: "${currentState.plan[previousStep - 1]}"\n\nThe result was: "${previousResponse.substring(0, 500)}${previousResponse.length > 500 ? '...' : ''}"\n\nNow I need to work on step ${currentState.currentStep}: "${currentState.plan[currentState.currentStep - 1]}"\n\nPlease help me complete this step.`;
  }
  
  const sent = await sendText(stepPrompt);
  if (!sent) {
    chrome.runtime.sendMessage({
      type: 'error',
      error: `Failed to send prompt for step ${currentState.currentStep}`
    });
    return;
  }
  
  monitorResponse((responseText) => {
    console.log(`Step ${currentState.currentStep} response received`);
    
    if (responseText) {
      chrome.runtime.sendMessage({
        type: 'stepCompleted',
        stepNumber: currentState.currentStep,
        response: responseText
      });
    } else {
      chrome.runtime.sendMessage({
        type: 'error',
        error: `Empty response received for step ${currentState.currentStep}`
      });
    }
  });
}

// Process evaluation
async function processEvaluation() {
  console.log('Starting evaluation');
  
  const finalResponse = currentState.stepResponses[39]; // Last step response
  
  const evaluationPrompt = `I have completed a 40-step plan for this task: "${currentState.userPrompt}"\n\nHere is the final result: "${finalResponse}"\n\nPlease evaluate this result and either:\n1. Respond with "Good" if the result is satisfactory, or\n2. Provide a new 40-step plan for improvements if the result needs further work.`;
  
  const sent = await sendText(evaluationPrompt);
  if (!sent) {
    chrome.runtime.sendMessage({
      type: 'error',
      error: 'Failed to send evaluation prompt'
    });
    return;
  }
  
  monitorResponse((responseText) => {
    console.log('Evaluation response received');
    
    if (responseText) {
      chrome.runtime.sendMessage({
        type: 'evaluationComplete',
        result: responseText
      });
    } else {
      chrome.runtime.sendMessage({
        type: 'error',
        error: 'Empty response received for evaluation'
      });
    }
  });
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Content script received message:', message.type);
  
  if (message.type === 'startProcessing') {
    // Store the workflow state
    currentState = message.state;
    console.log('Received workflow state:', currentState.status);
    
    // Send acknowledgment
    sendResponse({ status: 'received' });
    
    // Process based on the current state
    setTimeout(() => {
      try {
        if (currentState.status === 'starting' || currentState.status === 'planning') {
          processPlanning();
        } else if (currentState.status === 'executing') {
          processStep();
        } else if (currentState.status === 'evaluating') {
          processEvaluation();
        }
      } catch (error) {
        console.error('Error processing state:', error);
        chrome.runtime.sendMessage({
          type: 'error',
          error: error.message
        });
      }
    }, 1000);
  }
  
  // Return true for async response
  return true;
});

// Notify the background script that content script is loaded
(async function init() {
  try {
    console.log('Content script loaded on:', window.location.href);
    await waitForPageLoad();
    chrome.runtime.sendMessage({ 
      type: 'contentScriptReady',
      url: window.location.href
    });
  } catch (error) {
    console.error('Init error:', error);
  }
})();