document.addEventListener('DOMContentLoaded', function() {
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const messageContainer = document.getElementById('messageContainer');
    const progressBar = document.getElementById('progressBar');
    const currentStep = document.getElementById('currentStep');
    const statusDot = document.querySelector('.status-dot');
    const statusText = document.querySelector('.status-text');
  
    // Listen for status updates from the background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'statusUpdate') {
        updateStatus(message.status, message.step);
      } else if (message.type === 'newMessage') {
        addMessage(message.role, message.content);
        messageContainer.scrollTop = messageContainer.scrollHeight;
      } else if (message.type === 'workflowComplete') {
        updateStatus('idle', 40);
        addMessage('system', 'Workflow completed! The final result has been added to the conversation.');
      } else if (message.type === 'workflowError') {
        updateStatus('error', 0);
        addMessage('system', `Workflow encountered an error: ${message.error}. Please try again.`);
      }
    });
  
    // Check if there's an ongoing workflow
    chrome.storage.local.get(['workflowStatus', 'currentStep', 'conversation'], (result) => {
      if (result.workflowStatus && result.workflowStatus !== 'idle') {
        updateStatus(result.workflowStatus, result.currentStep || 0);
      }
      
      // Restore conversation history
      if (result.conversation && Array.isArray(result.conversation)) {
        result.conversation.forEach(msg => {
          addMessage(msg.role, msg.content);
        });
        messageContainer.scrollTop = messageContainer.scrollHeight;
      }
    });
  
    // Send message to start workflow
    sendButton.addEventListener('click', () => {
      const message = userInput.value.trim();
      if (message) {
        // Add user message to the UI
        addMessage('user', message);
        
        // Clear input
        userInput.value = '';
        
        // Update status
        updateStatus('starting', 0);
        
        // Send message to background script to start workflow
        chrome.runtime.sendMessage({
          type: 'startWorkflow',
          userPrompt: message
        });
      }
    });
  
    // Allow Enter key to send message
    userInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendButton.click();
      }
    });
  
    // Function to add a message to the conversation
    function addMessage(role, content) {
      const messageDiv = document.createElement('div');
      messageDiv.className = `message message-${role}`;
      
      const contentDiv = document.createElement('div');
      contentDiv.className = 'message-content';
      
      // If the content is markdown and role is assistant, render it as markdown
      if (role === 'assistant') {
        // Basic markdown rendering for code blocks
        content = content.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
        // Bold
        content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        // Italic
        content = content.replace(/\*(.*?)\*/g, '<em>$1</em>');
        // Lists
        content = content.replace(/^\s*-\s+(.*?)$/gm, '<li>$1</li>');
        // Wrap lists in ul
        if (content.includes('<li>')) {
          content = content.replace(/(<li>.*?<\/li>)/gs, '<ul>$1</ul>');
        }
        // Line breaks
        content = content.replace(/\n/g, '<br>');
      } else {
        // For user and system messages, just handle line breaks
        content = content.replace(/\n/g, '<br>');
      }
      
      contentDiv.innerHTML = content;
      messageDiv.appendChild(contentDiv);
      messageContainer.appendChild(messageDiv);
      
      // Save the message to storage
      chrome.storage.local.get(['conversation'], (result) => {
        const conversation = result.conversation || [];
        conversation.push({ role, content });
        chrome.storage.local.set({ conversation });
      });
    }
  
    // Function to update the workflow status
    function updateStatus(status, step) {
      statusDot.className = 'status-dot';
      
      switch(status) {
        case 'idle':
          statusDot.classList.add('offline');
          statusText.textContent = 'Idle';
          progressBar.style.width = '0%';
          currentStep.textContent = '0';
          break;
        case 'starting':
          statusDot.classList.add('working');
          statusText.textContent = 'Starting workflow...';
          progressBar.style.width = '0%';
          currentStep.textContent = '0';
          break;
        case 'planning':
          statusDot.classList.add('working');
          statusText.textContent = 'Creating 40-step plan...';
          progressBar.style.width = '5%';
          currentStep.textContent = '0';
          break;
        case 'executing':
          statusDot.classList.add('working');
          statusText.textContent = `Executing step ${step} of 40...`;
          const progress = (step / 40) * 100;
          progressBar.style.width = `${progress}%`;
          currentStep.textContent = step;
          break;
        case 'evaluating':
          statusDot.classList.add('working');
          statusText.textContent = 'Evaluating final result...';
          progressBar.style.width = '95%';
          currentStep.textContent = '40';
          break;
        case 'completed':
          statusDot.classList.add('online');
          statusText.textContent = 'Workflow completed!';
          progressBar.style.width = '100%';
          currentStep.textContent = '40';
          break;
        case 'error':
          statusDot.classList.add('error');
          statusText.textContent = 'Error encountered';
          progressBar.style.width = '0%';
          break;
      }
      
      // Save status to storage
      chrome.storage.local.set({
        workflowStatus: status,
        currentStep: step
      });
    }
  });