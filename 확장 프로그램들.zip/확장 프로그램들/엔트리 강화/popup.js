document.getElementById("applyBtn").addEventListener("click", async () => {
    const width = parseInt(document.getElementById("widthInput").value, 10);
    const height = parseInt(document.getElementById("heightInput").value, 10);
  
    if (isNaN(width) || isNaN(height)) {
      alert("해상도(숫자)를 올바르게 입력하세요!");
      return;
    }
  
    // 현재 활성 탭(tab)에 메시지 전달
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, {
      type: "CHANGE_CANVAS_RESOLUTION",
      width,
      height
    });
  
    // 팝업 닫기(선택 사항)
    window.close();
  });
  