(function() {
  // (예) 640×360을 1920×1080으로 쓰고 싶을 때
  const TARGET_WIDTH = 640;   // 기존 논리 너비
  const TARGET_HEIGHT = 360;  // 기존 논리 높이

  const ACTUAL_WIDTH = 1920;  // 원하는 물리 해상도
  const ACTUAL_HEIGHT = 1080;

  // scale factor
  const scaleX = ACTUAL_WIDTH / TARGET_WIDTH;   // 3
  const scaleY = ACTUAL_HEIGHT / TARGET_HEIGHT; // 3

  // 1) iframe + 현재 문서에서 #entryCanvas 찾기
  //    (필요하다면 setInterval이나 MutationObserver로 로딩 기다린 뒤 시도)
  function applyScalingToAllCanvas() {
    let found = false;

    // (a) 현재 문서
    const mainCanvas = document.getElementById("entryCanvas");
    if (mainCanvas) {
      setupScaledCanvas(mainCanvas);
      found = true;
    }

    // (b) 모든 iframe
    const iframes = document.getElementsByTagName("iframe");
    for (let i = 0; i < iframes.length; i++) {
      try {
        const iframeDoc = iframes[i].contentDocument || iframes[i].contentWindow.document;
        if (!iframeDoc) continue;
        const canvas = iframeDoc.getElementById("entryCanvas");
        if (canvas) {
          setupScaledCanvas(canvas);
          found = true;
        }
      } catch (err) {
        console.warn("cross-origin iframe 접근 불가:", err);
      }
    }

    if (!found) {
      console.log("entryCanvas를 찾지 못했습니다.");
    }
  }

  // 2) 실제로 “우회 스케일” 적용
  function setupScaledCanvas(canvas) {
    // 물리 해상도 변경
    canvas.width = ACTUAL_WIDTH;
    canvas.height = ACTUAL_HEIGHT;

    // 기존 코드가 "640×360"이라 가정하고 그릴 것이므로, 
    // 2D 컨텍스트에 scale()을 적용
    const ctx = canvas.getContext("2d");
    ctx.scale(scaleX, scaleY);

    console.log(
      `entryCanvas: 물리 ${ACTUAL_WIDTH}×${ACTUAL_HEIGHT}, 
       논리 ${TARGET_WIDTH}×${TARGET_HEIGHT} => scale(${scaleX}, ${scaleY}) 적용 완료.`
    );
  }

  // 실행
  applyScalingToAllCanvas();
})();
