/* global gifuct, UPNG */

document.addEventListener('DOMContentLoaded', () => {
    /*
     * ------------------  공통 유틸  ------------------
     */
    const $ = (sel) => document.querySelector(sel);
    const alarm = (msg, link) => {
      $('#alarmMsg').innerHTML = '';
      $('#alarmMsg').append(msg);
      if (link) {
        $('#alarmMsg').append(document.createElement('br'));
        const a = document.createElement('a');
        a.href = link; a.textContent = link; a.target = '_blank';
        $('#alarmMsg').append(a);
      }
      $('#alarm').style.display = 'flex';
    };
    $('#alarmClose').addEventListener('click', () => $('#alarm').style.display = 'none');
  
    const executeCommand = async (command, cb) => {
      const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
      try {
        const [result] = await chrome.scripting.executeScript({
          target:{ tabId:tab.id },
          func:(cmd)=>new Promise((resolve)=>{
            const wait=()=>{ if(typeof Entry!=='undefined'){ try{
                resolve(Function(`"use strict"; ${cmd}`)());
            }catch(e){resolve({error:e.message})} } else setTimeout(wait,100);};
            wait();
          }),
          args:[command],
          world:'MAIN'
        });
        if (result.result?.error) throw new Error(result.result.error);
        cb(result.result);
      } catch(e){ console.error(e); cb(null,e.message); }
    };
  
    /*
     * ---------------  기존 버튼 핸들러 ---------------
     * (기존 코드 유지, 변경 없음)
     */
    $('#getProjectId').addEventListener('click', () => {
      executeCommand('return Entry.projectId;', (res, err) => $('#projectResult').textContent = err || `프로젝트 ID: ${res}`);
    });
    $('#hideTimer').addEventListener('click', () => executeCommand(`
        Entry.engine.projectTimer.setX(-Number.MAX_VALUE);
        return "초시계가 숨겨졌습니다";`, ()=>{}));
    $('#hideAnswer').addEventListener('click', () => executeCommand(`
        Entry.container.inputValue.setX(-Number.MAX_VALUE);
        return "대답 입력창이 숨겨졌습니다";`, ()=>{}));
    $('#fpsApply').addEventListener('click', () => {
      const v = parseInt($('#fpsInput').value); if(isNaN(v)){alert('숫자를 입력해주세요!');return;}
      executeCommand(`Entry.FPS=${v}; return "FPS가 ${v}로 설정됨";`,()=>{ $('#fpsInput').value='';});
    });
    $('#messageLengthApply').addEventListener('click', () => {
      const v = parseInt($('#messageLengthInput').value); if(isNaN(v)){alert('숫자를 입력해주세요!');return;}
      executeCommand(`EntryStatic.messageMaxLength=${v}; return "신호 길이가 ${v}자로 변경됨";`,()=>{$('#messageLengthInput').value='';});
    });
    $('#showFps').addEventListener('click', () => executeCommand('return Entry.FPS;', (r,e)=> $('#fpsResult').textContent=e||`현재 FPS: ${r}`));
    $('#undoButton').addEventListener('click', () => {
      const v = parseInt($('#undoSteps').value)||1;
      executeCommand(`Entry.stateManager.undo(${v}); return "${v}단계 되돌리기 완료";`,()=>{$('#undoSteps').value='';});
    });
    $('#addScene').addEventListener('click', () => {
      executeCommand(`try{Entry.scene.addScene();return"새로운 장면이 추가되었습니다";}catch(e){return"장면 추가 중 오류: "+e.message}`, (r,e)=> $('#sceneResult').textContent=e||r);
    });
    $('#changeFontApply').addEventListener('click', () => {
      const f=$('#fontNameInput').value.trim(); if(!f){alert('폰트 이름을 입력해주세요!');return;}
      executeCommand(`Entry.playground.object.entity.setFontType('${f}'); return "폰트 변경 시도: '${f}'";`, (r,e)=>{$('#fontResult').textContent=e||r;$('#fontNameInput').value='';});
    });
  
    /*
     * --------------- 썸네일(정적) 업로드 ---------------
     */
    $('#selectThumbnail').addEventListener('click', ()=>$('#thumbnailFile').click());
  
    $('#saveThumbnail').addEventListener('click', async () => {
      const f = $('#thumbnailFile').files[0];
      if(!f){alarm('썸네일 파일을 먼저 선택하세요.');return;}
      if(f.type !== 'image/png'){alarm('PNG만 지원합니다. GIF/MP4는 "움직이는 썸네일" 버튼을 이용하세요.');return;}
      if(f.size > 1_000_000) alarm('용량이 1 MB를 초과했습니다. 자동 압축 중…');
      const dataURL = await fileToDataURL(f, 1024*1024);
      injectThumbnail(dataURL, false);
    });
  
    /*
     * ------------- 움직이는 썸네일 워크플로우 ------------
     */
    $('#animatedThumbnail').addEventListener('click', () => {
      $('#thumbnailFile').click();
      $('#thumbnailFile').onchange = async () => {
        const f = $('#thumbnailFile').files[0];
        if(!f) return;
        if(!/^(image\/gif|video\/mp4|video\/webm|image\/apng)$/.test(f.type)){
          alarm('지원되지 않는 형식입니다. gif/mp4/webm만 선택하세요.'); return;
        }
        alarm('변환 중입니다… 잠시만 기다려 주세요.');
        try{
          let apngBlob;
          if(f.type === 'image/gif'){
            apngBlob = await gifToApngBlob(f);
          }else if(f.type.startsWith('video/')){
            apngBlob = await videoToApngBlob(f);
          }else{
            apngBlob = f; // 이미 APNG
          }
          apngBlob = await ensureSize(apngBlob, 1_000_000); // 1 MB 이내로 맞추기
          const dataURL = await blobToDataURL(apngBlob);
          injectThumbnail(dataURL, true);
          $('#alarm').style.display='none';
        }catch(e){
          console.error(e);
          alarm('변환 실패: '+e.message);
        }
      };
    });
  
    /*
     * ------------------- 헬퍼 함수 -------------------
     */
    const fileToDataURL = (file, maxBytes) => new Promise((res,rej)=>{
      const reader = new FileReader();
      reader.onload = async e => {
        let blob = dataURLtoBlob(e.target.result);
        blob = await ensureSize(blob, maxBytes);
        res(await blobToDataURL(blob));
      };
      reader.onerror = () => rej(reader.error);
      reader.readAsDataURL(file);
    });
  
    const injectThumbnail = (dataURL, isAnimated) => {
      executeCommand(`Entry.canvas_.toDataURL = () => '${dataURL}'; return '썸네일 적용 완료';`, (r,e)=>{
        $('#thumbResult').textContent = e|| (isAnimated?'움직이는 ':'정적 ')+'썸네일이 적용되었습니다. 작품을 저장하세요!';
      });
    };
  
    const dataURLtoBlob = (url) => {
      const [meta, b64] = url.split(',');
      const mime = meta.match(/:(.*?);/)[1];
      return new Blob([Uint8Array.from(atob(b64), c=>c.charCodeAt(0))], {type:mime});
    };
    const blobToDataURL = (blob) => new Promise((res)=>{
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.readAsDataURL(blob);
    });
  
    /* 용량 초과 시 자동 리사이즈 (PNG/APNG) */
    async function ensureSize(blob, limit){
      if(blob.size <= limit) return blob;
      // 비율 반복 감소
      let scale = 0.9, canvas = document.createElement('canvas'), img = new Image();
      img.src = await blobToDataURL(blob); await img.decode();
      while(blob.size > limit && scale > 0.2){
        canvas.width = img.width*scale; canvas.height = img.height*scale;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img,0,0,canvas.width,canvas.height);
        blob = await new Promise(res=>canvas.toBlob(res,'image/png',0.9));
        scale -= 0.1;
      }
      return blob;
    }
  
    /* GIF → APNG */
    async function gifToApngBlob(file){
      const buf = new Uint8Array(await file.arrayBuffer());
      const gif = gifuct.parseGIF(buf);
      const frames = gifuct.decompressFrames(gif, true);
      const w = gif.lsd.width, h = gif.lsd.height;
      const rgbaFrames = [], delays = [];
      const canv = document.createElement('canvas'); canv.width=w; canv.height=h;
      const ctx = canv.getContext('2d');
      for(const f of frames){
        const imgData = ctx.createImageData(w,h);
        imgData.data.set(f.patch);
        ctx.putImageData(imgData,0,0);
        rgbaFrames.push(new Uint8Array(ctx.getImageData(0,0,w,h).data));
        delays.push((f.delay||10)*10); // centiseconds→ms
      }
      const apng = UPNG.encode(rgbaFrames, w, h, 0, delays);
      return new Blob([apng], {type:'image/png'});
    }
  
    /* MP4/WEBM → APNG (앞 1초 10프레임) */
    async function videoToApngBlob(file){
      const url = URL.createObjectURL(file);
      const video = document.createElement('video');
      video.src = url; await video.play().catch(()=>{});
      await new Promise(res=>video.onloadeddata = res);
      const w = video.videoWidth, h = video.videoHeight;
      const canv = document.createElement('canvas'); canv.width=w; canv.height=h;
      const ctx = canv.getContext('2d');
      const rgbaFrames = [], delays = [];
      const grab = (t)=>new Promise((res)=>{
        video.currentTime = t;
        video.onseeked = ()=>{ ctx.drawImage(video,0,0,w,h);
          rgbaFrames.push(new Uint8Array(ctx.getImageData(0,0,w,h).data));
          delays.push(100); res(); };
      });
      const steps = 10, duration = Math.min(1, video.duration);
      for(let i=0;i<steps;i++) await grab((duration/steps)*i);
      video.pause(); URL.revokeObjectURL(url);
      const apng = UPNG.encode(rgbaFrames, w, h, 0, delays);
      return new Blob([apng], {type:'image/png'});
    }
  });
  