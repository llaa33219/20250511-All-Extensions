(function() {
  console.debug("[DEBUG] 확장 프로그램 스크립트 시작");
  
  /*************************************************
   * [추가] 0) HTML에서 csrf-token, x-token 추출하는 함수
   *************************************************/
  function getTokensFromDom() {
    let csrfToken = "";
    let xToken = "";

    // 1) <meta name="csrf-token" content="..."> 에서 추출
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    if (metaTag) {
      csrfToken = metaTag.getAttribute('content') || "";
    }

    // 2) <script id="__NEXT_DATA__" ...> 안의 JSON에서 x-token 추출
    const nextDataScript = document.querySelector('#__NEXT_DATA__');
    if (nextDataScript) {
      try {
        const json = JSON.parse(nextDataScript.textContent);
        // xToken: props.initialState.common.user.xToken
        xToken = json?.props?.initialState?.common?.user?.xToken || "";
      } catch (e) {
        // console.warn("NEXT_DATA JSON 파싱 오류:", e);
      }
    }

    return { csrfToken, xToken };
  }

  // 전역 변수에 커스텀 스티커 base64 데이터를 저장합니다.
  let customStickerData = null;

  // 파일 선택 input을 생성(숨김)
  const fileInput = document.createElement("input");
  fileInput.type = "file";
  fileInput.accept = "image/*";
  fileInput.style.display = "none";
  document.body.appendChild(fileInput);
  console.debug("[DEBUG] fileInput 생성 및 body에 추가됨.");

  // 파일이 선택되면 FileReader로 base64 문자열로 변환하고, 스티커 영역에 적용합니다.
  fileInput.addEventListener("change", function(e) {
    console.debug("[DEBUG] fileInput change 이벤트 발생");
    const file = e.target.files[0];
    if (file) {
      console.debug("[DEBUG] 선택된 파일:", file);
      readFileAsBase64(file)
        .then(base64 => {
          console.debug("[DEBUG] 파일 base64 변환 완료:", base64);
          customStickerData = base64;
          // 스티커 표시 영역 업데이트
          const stickerElem = document.querySelector('.css-fjfa6z.e1h77j9v3');
          if (stickerElem) {
            const img = stickerElem.querySelector('img');
            if (img) {
              img.src = base64;
              console.debug("[DEBUG] 스티커 영역의 이미지 src 업데이트됨.");
            } else {
              console.warn("[DEBUG] 스티커 영역에 <img> 태그가 없음.");
            }
          } else {
            console.warn("[DEBUG] 스티커 영역(.css-fjfa6z.e1h77j9v3) 없음.");
          }
        })
        .catch(error => {
          console.error("[DEBUG] 커스텀 스티커 파일 읽기 실패:", error);
        });
    } else {
      console.debug("[DEBUG] 파일이 선택되지 않음.");
    }
  });

  // File 객체를 base64 문자열로 읽는 함수
  function readFileAsBase64(file) {
    console.debug("[DEBUG] readFileAsBase64() 호출", file);
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        console.debug("[DEBUG] FileReader onload 완료");
        resolve(reader.result);
      };
      reader.onerror = (err) => {
        console.error("[DEBUG] FileReader onerror:", err);
        reject(err);
      };
      reader.readAsDataURL(file);
      console.debug("[DEBUG] FileReader readAsDataURL 호출");
    });
  }

  // 스티커 업로드 버튼(이모티콘 업로드 버튼)을 추가하거나 기존 요소에 이벤트 리스너를 붙입니다.
  function addStickerUploadListener() {
    console.debug("[DEBUG] addStickerUploadListener() 호출");
    let stickerButton = document.querySelector('a.css-1394o6u.e1h77j9v5');

    if (!stickerButton) {
      console.warn("[DEBUG] 기존 스티커 버튼을 찾지 못했습니다. 새 버튼을 생성합니다.");
      // 새 버튼 생성
      stickerButton = document.createElement("a");
      stickerButton.setAttribute("role", "button");
      stickerButton.className = "css-1394o6u e1h77j9v5";
      stickerButton.innerHTML = '<span class="blind">스티커</span>';
      // 스티커 버튼을 추가할 컨테이너 찾기 (예: css-ljggwk.e1h77j9v9)
      const container = document.querySelector(".css-ljggwk.e1h77j9v9");
      if (!container) {
        // [추가] 컨테이너를 못 찾았을 때 500ms 후 재시도
        console.warn("[DEBUG] 스티커 버튼을 추가할 컨테이너를 찾지 못했습니다. 500ms 후 재시도.");
        setTimeout(addStickerUploadListener, 500);
        return;
      }
      // 아래 로직(컨테이너에 button 삽입)은 그대로 유지
      const regSpan = container.querySelector("span.css-11ofcmn.e1h77j9v8");
      if (regSpan) {
        container.insertBefore(stickerButton, regSpan);
        console.debug("[DEBUG] 새 스티커 버튼이 등록 버튼 앞에 추가됨.");
      } else {
        container.appendChild(stickerButton);
        console.debug("[DEBUG] 새 스티커 버튼이 컨테이너에 추가됨.");
      }
    } else {
      console.debug("[DEBUG] 기존 스티커 버튼을 찾았습니다.");
    }

    stickerButton.addEventListener("click", function(e) {
      e.preventDefault();
      e.stopPropagation();
      console.debug("[DEBUG] 스티커 버튼 클릭됨. fileInput 클릭 트리거");
      fileInput.click(); // 파일 선택 대화상자 열기
    });
  }

  // 등록 버튼이 동적으로 로드될 수 있으므로, 해당 버튼이 나타날 때까지 재시도합니다.
  function overrideRegisterButton() {
    console.debug("[DEBUG] overrideRegisterButton() 호출");
    const registerBtn = document.querySelector('a.css-1adjw8a.e13821ld2');
    if (!registerBtn) {
      console.warn("[DEBUG] 등록 버튼(a.css-1adjw8a.e13821ld2)을 찾지 못했습니다. 500ms 후 재시도.");
      setTimeout(overrideRegisterButton, 500);
      return;
    }
    
    console.debug("[DEBUG] 등록 버튼 발견:", registerBtn);
    registerBtn.addEventListener("click", function(e) {
      e.preventDefault();
      e.stopPropagation();
      console.debug("[DEBUG] 등록 버튼 클릭됨");

      const textarea = document.getElementById("Write");
      const contentValue = textarea ? textarea.value : "";
      console.debug("[DEBUG] textarea 내용:", contentValue);

      // 만약 사용자가 커스텀 스티커를 업로드 했다면 그 데이터를 사용합니다.
      if (customStickerData) {
        console.debug("[DEBUG] customStickerData가 존재함. 바로 요청 전송");
        sendGraphQLRequest(contentValue, customStickerData);
      } else {
        // 커스텀 스티커가 없으면, 스티커 영역에 있는 이미지의 src를 가져와 사용합니다.
        const stickerElem = document.querySelector('.css-fjfa6z.e1h77j9v3');
        if (stickerElem) {
          const img = stickerElem.querySelector("img");
          if (img && img.src) {
            console.debug("[DEBUG] 스티커 영역의 이미지 src:", img.src);
            if (img.src.startsWith("data:")) {
              console.debug("[DEBUG] 이미지 src가 이미 base64 data URL임.");
              sendGraphQLRequest(contentValue, img.src);
            } else {
              console.debug("[DEBUG] 이미지 src를 base64로 변환 시도");
              getImageBase64(img.src)
                .then(base64Str => {
                  console.debug("[DEBUG] 변환된 base64:", base64Str);
                  sendGraphQLRequest(contentValue, base64Str);
                })
                .catch(error => {
                  console.error("[DEBUG] 스티커 이미지 변환 실패:", error);
                  sendGraphQLRequest(contentValue, null);
                });
            }
          } else {
            console.debug("[DEBUG] 스티커 영역에 이미지가 없거나 src가 비어 있음.");
            sendGraphQLRequest(contentValue, null);
          }
        } else {
          console.debug("[DEBUG] 스티커 영역(.css-fjfa6z.e1h77j9v3)을 찾지 못함.");
          sendGraphQLRequest(contentValue, null);
        }
      }
    });
  }

  // GraphQL 요청 전송 함수 (sticker 변수를 String 타입으로 전송)
  function sendGraphQLRequest(contentValue, stickerData) {
    console.debug("[DEBUG] sendGraphQLRequest() 호출. content:", contentValue, "stickerData:", stickerData);

    // [추가] DOM에서 토큰을 가져온다.
    const { csrfToken, xToken } = getTokensFromDom();

    const mutationQuery = `
      mutation CREATE_ENTRYSTORY(
          $content: String
          $text: String
          $image: String
          $sticker: String
          $stickerItem: String
          $cursor: String
      ) {
          createEntryStory(
              content: $content
              text: $text
              image: $image
              sticker: $sticker
              stickerItem: $stickerItem
              cursor: $cursor
          ) {
              warning
              discuss {
                  id
                  title
                  content
                  created
                  commentsLength
                  likesLength
              }
          }
      }
      `;
  
    const variables = {
      content: contentValue,
      text: "",
      image: null,
      sticker: stickerData,   // base64 문자열 또는 null
      stickerItem: null,
      cursor: null
    };
  
    const options = {
      method: "POST",
      headers: {
        "accept": "*/*",
        "accept-language": "ja",
        "content-type": "application/json",
        "csrf-token": csrfToken,    // [수정] 하드코딩 제거 후 DOM에서 추출값 사용
        "priority": "u=1, i",
        "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Linux\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-client-type": "Client",
        "x-token": xToken,         // [수정] 하드코딩 제거 후 DOM에서 추출값 사용
      },
      referrer: "https://playentry.org/community/entrystory/list?sort=created&term=all",
      referrerPolicy: "unsafe-url",
      body: JSON.stringify({ query: mutationQuery, variables }),
      mode: "cors",
      credentials: "include"
    };
  
    console.debug("[DEBUG] GraphQL 요청 옵션 구성:", options);
    fetch("https://playentry.org/graphql/CREATE_ENTRYSTORY", options)
      .then(response => {
        console.debug("[DEBUG] GraphQL 응답 상태:", response.status);
        return response.json();
      })
      .then(data => {
        console.debug("[DEBUG] GraphQL 응답 데이터:", data);
        alert("등록 요청이 전송되었습니다.");
      })
      .catch(error => {
        console.error("[DEBUG] 등록 요청 전송 실패:", error);
        alert("등록 요청 전송 실패");
      });
  }

  // URL을 받아 base64 문자열로 변환하는 함수 (이미지 URL 변환)
  function getImageBase64(url) {
    console.debug("[DEBUG] getImageBase64() 호출, url:", url);
    return fetch(url)
      .then(response => response.blob())
      .then(blob => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          console.debug("[DEBUG] getImageBase64() 변환 완료");
          resolve(reader.result);
        };
        reader.onerror = (err) => {
          console.error("[DEBUG] getImageBase64() 변환 오류:", err);
          reject(err);
        };
        reader.readAsDataURL(blob);
      }));
  }

  // DOM이 준비되면 스티커 업로드 버튼과 등록 버튼 동작을 초기화합니다.
  function init() {
    console.debug("[DEBUG] init() 호출, DOMContentLoaded 후 실행");
    addStickerUploadListener();
    overrideRegisterButton();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
