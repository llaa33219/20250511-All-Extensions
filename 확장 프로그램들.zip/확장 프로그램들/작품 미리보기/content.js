// content.js

// 2초마다 주기적으로 실행할 함수
function replaceAnchors() {
    // 교체 대상 <a> 요소들을 전부 찾기
    const anchors = document.querySelectorAll("a.tagmanagerundefined.css-kkg74o.e1lvzky421");
  
    anchors.forEach(anchor => {
      const href = anchor.getAttribute("href"); // 예: /project/abcd1234
      if (!href) return;
  
      // /project/ 다음에 오는 부분(글자1) 파싱
      const projectId = href.split("/project/")[1];
      if (!projectId) return;
  
      // 새 iframe 생성
      const iframe = document.createElement("iframe");
      iframe.src = `https://playentry.org/iframe/${projectId}`;
      // 필요한 클래스나 스타일을 추가
      // 여기서는 .css-kkg74o를 그대로 활용
      iframe.classList.add("css-kkg74o");
  
      // <a>를 <iframe>으로 교체
      anchor.parentNode.replaceChild(iframe, anchor);
    });
  }
  
  // DOM이 로드된 후, 2초 간격으로 replaceAnchors() 실행
  document.addEventListener("DOMContentLoaded", () => {
    // 즉시 한 번 실행
    replaceAnchors();
  
    // 이후 2초마다 실행
    setInterval(() => {
      replaceAnchors();
    }, 2000);
  });
  