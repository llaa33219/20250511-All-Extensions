/**
 * 개선된 요청 큐 처리 함수
 */
async function processRequestQueue() {
  if (processingRequest) {
    scheduleQueueProcessing(1000);
    return;
  }
  
  if (!isOnline) {
    scheduleQueueProcessing(3000);
    return;
  }
  
  if (requestQueue.length === 0) {
    processingFailCount = 0;
    return;
  }
  
  processingRequest = true;

  try {
    // 우선순위 정렬
    requestQueue.sort((a, b) => a.priority - b.priority);
    
    // 맨 앞(가장 높은 우선순위)을 하나 꺼냄
    const nextJob = requestQueue.shift();
    if (!nextJob) {
      processingRequest = false;
      return;
    }

    // 작업에 재시도 카운터와 최대 재시도 횟수 추가
    if (nextJob.retryCount === undefined) {
      nextJob.retryCount = 0;
      nextJob.maxRetries = nextJob.maxRetries || 3;
    }
    
    try {
      // 실행 전 토큰 상태 확인
      const now = Date.now();
      if (now - lastTokenRefresh > TOKEN_REFRESH_INTERVAL || consecutiveForbiddenCount >= MAX_FORBIDDEN_BEFORE_REFRESH) {
        try {
          await refreshTokens();
        } catch (err) {
          // 실패해도 진행 (작업에서 다시 시도할 수 있음)
        }
      }
      
      // 타임아웃 설정
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error("Request timeout")), 30000);
      });
      
      // 실제 작업 실행
      await Promise.race([
        nextJob.fn(),
        timeoutPromise
      ]);
      
      processingFailCount = 0;
      
      // 성공한 요청 저장소에서 제거
      if (nextJob.requestId && savedRequests.has(nextJob.requestId)) {
        savedRequests.delete(nextJob.requestId);
        savePendingRequestsToStorage();
      }
      
      if (nextJob.label) console.log(`[QUEUE] ${nextJob.label} 처리 완료, 큐 길이: ${requestQueue.length}`);
    } catch (err) {
      processingFailCount++;
      
      // 403 에러일 경우 토큰 갱신 시도
      if (err.message && err.message.includes("403")) {
        console.warn(`[QUEUE] 403 에러 발생! 작업: ${nextJob.label}, 재시도: ${nextJob.retryCount}/${nextJob.maxRetries}`);
        
        // 연속 403 에러 발생 시 토큰 갱신
        if (++consecutiveForbiddenCount >= MAX_FORBIDDEN_BEFORE_REFRESH) {
          try {
            await refreshTokens();
          } catch (refreshErr) {
            console.error("[AUTH] 작업 중 토큰 갱신 실패:", refreshErr);
          }
        }
      } else {
        console.warn(`[QUEUE] 실패 (${nextJob.retryCount}/${nextJob.maxRetries}): ${nextJob.label}`, err);
      }
      
      // 재시도 로직
      if (nextJob.retryCount < nextJob.maxRetries) {
        // 403 에러일 경우 더 긴 지연 시간 적용
        const backoffTime = err.message && err.message.includes("403")
          ? Math.min(5000 * Math.pow(2, nextJob.retryCount), 30000) // 최대 30초
          : Math.min(1000 * Math.pow(2, nextJob.retryCount), 10000); // 최대 10초
        
        nextJob.retryCount++;
        nextJob.priority += 0.1;
        
        // 중요 요청이면 저장
        if (nextJob.priority <= 1.5 && nextJob.requestId) {
          savedRequests.set(nextJob.requestId, {
            type: nextJob.type || "unknown",
            data: nextJob.data || {},
            timestamp: Date.now()
          });
          savePendingRequestsToStorage();
        }
        
        // 큐에 다시 추가 (지연 시간 적용)
        setTimeout(() => {
          requestQueue.push(nextJob);
          scheduleQueueProcessing(0);
        }, backoffTime);
      }
    } finally {
      // 다음 요청 전 대기 (서버 부하 감소)
      await new Promise(r => setTimeout(r, 500));
    }
  } catch (err) {
    console.error("[QUEUE] 큐 처리 중 심각한 오류:", err);
    processingFailCount++;
  } finally {
    processingRequest = false;
    
    // 큐에 남은 작업이 있으면 계속 처리
    if (requestQueue.length > 0) {
      scheduleQueueProcessing(Math.min(100 * Math.pow(2, processingFailCount), 5000));
    } else {
      processingFailCount = 0;
    }
  }
}

/**
 * 반복적인 좋아요/좋아요 취소 패턴 실행 함수
 * @param {string} discussId - 게시물 ID
 */
async function performLikeUnlikePattern(discussId) {
  console.log(`[PATTERN] 좋아요/좋아요 취소 패턴 시작: ${discussId}`);
  
  // 패턴 시작 플래그 설정 (이미 패턴 중인지 확인용)
  if (!window.__likeUnlikePatterns) {
    window.__likeUnlikePatterns = new Map();
  }
  
  // 이미 실행 중인 패턴이 있으면 중단
  if (window.__likeUnlikePatterns.has(discussId)) {
    console.log(`[PATTERN] 이미 실행 중인 패턴 존재: ${discussId}`);
    return;
  }
  
  // 새 패턴 시작 플래그 설정
  window.__likeUnlikePatterns.set(discussId, true);
  
  // 패턴 실행 루프
  const runPatternLoop = async () => {
    try {
      // 패턴이 중단되었는지 확인
      if (!window.__likeUnlikePatterns.has(discussId)) {
        console.log(`[PATTERN] 패턴 중단됨: ${discussId}`);
        return;
      }
      
      // 1. 좋아요 요청 전송
      const likeRequestId = `pattern_like_${discussId}_${Date.now()}`;
      console.log(`[PATTERN] 좋아요 요청: ${discussId}`);
      
      try {
        await window.originalLikeDiscuss(discussId);
      } catch (err) {
        console.warn(`[PATTERN] 좋아요 요청 실패: ${discussId}`, err);
      }
      
      // 2. 좋아요 취소 요청 10번 연속 전송
      for (let i = 0; i < 10; i++) {
        // 패턴이 중단되었는지 확인
        if (!window.__likeUnlikePatterns.has(discussId)) {
          console.log(`[PATTERN] 패턴 중단됨: ${discussId}`);
          return;
        }
        
        const unlikeRequestId = `pattern_unlike_${discussId}_${Date.now()}_${i}`;
        console.log(`[PATTERN] 좋아요 취소 요청 ${i+1}/10: ${discussId}`);
        
        try {
          await window.originalUnlikeDiscuss(discussId);
        } catch (err) {
          console.warn(`[PATTERN] 좋아요 취소 요청 실패 (${i+1}/10): ${discussId}`, err);
        }
      }
      
      // 3. 1초 대기 후 다시 실행
      console.log(`[PATTERN] 1초 대기 후 재실행: ${discussId}`);
      setTimeout(runPatternLoop, 1000);
    } catch (err) {
      console.error(`[PATTERN] 패턴 실행 중 오류: ${discussId}`, err);
      
      // 오류가 발생해도 계속 실행 시도
      setTimeout(runPatternLoop, 1000);
    }
  };
  
  // 패턴 실행 시작
  runPatternLoop();
}

/**
 * 패턴 중단 함수
 * @param {string} discussId - 게시물 ID (없으면 모든 패턴 중단)
 */
function stopLikeUnlikePattern(discussId = null) {
  if (!window.__likeUnlikePatterns) return;
  
  if (discussId) {
    // 특정 패턴만 중단
    window.__likeUnlikePatterns.delete(discussId);
    console.log(`[PATTERN] 패턴 중단: ${discussId}`);
  } else {
    // 모든 패턴 중단
    window.__likeUnlikePatterns.clear();
    console.log(`[PATTERN] 모든 패턴 중단`);
  }
}

/**
 * 수정된 사용자 액션 기반 좋아요 함수 - 패턴 실행
 * @param {string} discussId - 게시물 ID
 */
function likeDiscussWithContext(discussId) {
  // 1. 사용자 액션 기록
  const priority = recordUserAction(USER_ACTION.LIKE_ACTION, { discussId, targetId: discussId });
  
  // 2. 패턴 실행 시작
  performLikeUnlikePattern(discussId);
}

/**
 * 수정된 사용자 액션 기반 좋아요 취소 함수 - 패턴 중단
 * @param {string} discussId - 게시물 ID
 */
function unlikeDiscussWithContext(discussId) {
  // 1. 사용자 액션 기록
  const priority = recordUserAction(USER_ACTION.LIKE_ACTION, { discussId, targetId: discussId });
  
  // 2. 패턴 중단 (원래 좋아요 취소 버튼을 누르면 패턴 중단)
  stopLikeUnlikePattern(discussId);
  
  // 3. 요청 스케줄링 (우선순위 적용)
  const requestId = `unlike_discuss_${discussId}_${Date.now()}`;
  
  scheduleRequest(
    () => window.originalUnlikeDiscuss(discussId),
    priority,
    "UnlikeAction",
    3,
    requestId,
    USER_ACTION.LIKE_ACTION,
    { discussId }
  );
}

/**
 * 댓글 새로고침 및 업데이트
 * @param {string} discussId - 게시물 ID
 */
async function refetchCommentsAndUpdate(discussId) {
  try {
    // 이미 로딩 중이면 중복 요청 방지
    if (window.__commentIsLoadingMap[discussId]) {
      console.log(`[COMMENT] 댓글 새로고침 건너뜀 (이미 로딩 중): ${discussId}`);
      return;
    }
    
    window.__commentIsLoadingMap[discussId] = true;
    
    // API URL 생성
    const apiUrl = `/api/discussions/${discussId}/comments?limit=10`;
    
    // 요청 옵션 설정
    const options = {
      method: "GET",
      credentials: "include",
      headers: { ...requestOptions.headers }
    };
    
    try {
      // 댓글 가져오기
      const response = await throttledFetch(apiUrl, options);
      const data = await response.json();
      
      // 캐시 업데이트
      if (data.comments) {
        // 기존 캐시 백업
        const oldComments = window.__commentCacheForComments[discussId] || [];
        
        // 새 댓글 데이터로 캐시 업데이트
        window.__commentCacheForComments[discussId] = data.comments;
        
        // 업데이트된 캐시가 있으면 DOM 업데이트 트리거
        if (oldComments.length > 0 || data.comments.length > 0) {
          // UI 업데이트 (DOM 조작)
          updateCommentsUI(discussId, data);
        }
        
        // 총 댓글 수 업데이트
        if (data.total !== undefined) {
          window.__commentTotalMap[discussId] = data.total;
        }
        
        // 모든 댓글이 로드되었는지 여부 설정
        const isFullyLoaded = data.comments.length >= (data.total || 0);
        window.__commentFullyLoadedMap[discussId] = isFullyLoaded;
        
        if (isFullyLoaded) {
          // 모든 댓글이 로드된 경우 해당 섹션 기록
          userInteractionState.fullyLoadedComments.add(discussId);
        }
      }
      
      return data;
    } catch (err) {
      console.error(`[COMMENT] 댓글 새로고침 실패: ${discussId}`, err);
      throw err;
    } finally {
      // 로딩 상태 해제
      window.__commentIsLoadingMap[discussId] = false;
    }
  } catch (err) {
    console.error(`[COMMENT] 댓글 새로고침 중 오류: ${discussId}`, err);
    throw err;
  }
}

/**
 * 댓글 UI 업데이트 함수
 * @param {string} discussId - 게시물 ID
 * @param {object} data - 새 댓글 데이터
 */
function updateCommentsUI(discussId, data) {
  try {
    // 댓글 목록 컨테이너 찾기
    const commentContainer = document.querySelector(`[data-discuss-id="${discussId}"] .css-4e8bhg.euhmxlr2 ul.css-1vg7k8n.euhmxlr3`);
    if (!commentContainer) return;
    
    // 현재 표시된 댓글 요소들 수집
    const existingCommentElements = {};
    commentContainer.querySelectorAll('li').forEach(li => {
      const commentId = li.querySelector('[data-comment-id]')?.getAttribute('data-comment-id');
      if (commentId) {
        existingCommentElements[commentId] = li;
      }
    });
    
    // 새 댓글 목록으로 UI 업데이트
    const fragment = document.createDocumentFragment();
    const newComments = data.comments || [];
    
    if (newComments.length === 0) {
      // 댓글이 없는 경우
      const emptyMessage = document.createElement('div');
      emptyMessage.className = 'css-1qc38dz euhmxlr4';
      emptyMessage.textContent = '첫 댓글을 남겨보세요!';
      fragment.appendChild(emptyMessage);
    } else {
      // 댓글이 있는 경우 각 댓글 요소 생성
      newComments.forEach(comment => {
        if (existingCommentElements[comment.id]) {
          // 기존 요소 재사용 (편집 중인 경우 제외)
          if (!window.__editingCommentSet.has(comment.id)) {
            fragment.appendChild(existingCommentElements[comment.id]);
            delete existingCommentElements[comment.id];
          }
        } else {
          // 새 요소 생성
          const commentElement = createCommentElement(comment, discussId);
          fragment.appendChild(commentElement);
        }
      });
    }
    
    // 편집 중인 댓글 요소 복원 (변경하지 않음)
    Object.values(existingCommentElements).forEach(element => {
      const commentId = element.querySelector('[data-comment-id]')?.getAttribute('data-comment-id');
      if (commentId && window.__editingCommentSet.has(commentId)) {
        fragment.appendChild(element);
      }
    });
    
    // 컨테이너 비우고 새 요소로 채우기
    commentContainer.innerHTML = '';
    commentContainer.appendChild(fragment);
    
    // 댓글 수 표시 업데이트
    updateCommentCountUI(discussId, data.total || 0);
    
    // 더보기 버튼 상태 업데이트
    updateLoadMoreButtonUI(discussId, data);
  } catch (err) {
    console.error(`[UI] 댓글 UI 업데이트 중 오류: ${discussId}`, err);
  }
}

/**
 * 댓글 요소 생성 함수
 * @param {object} comment - 댓글 데이터
 * @param {string} discussId - 게시물 ID
 * @returns {HTMLElement} 댓글 요소
 */
function createCommentElement(comment, discussId) {
  const li = document.createElement('li');
  li.className = 'css-u1nrp7 e9nkex10';
  li.setAttribute('data-comment-id', comment.id);
  
  // 댓글 HTML 구조 생성 (실제 구현은 사이트 구조에 맞게 조정 필요)
  li.innerHTML = `
    <div class="css-ocy6k5 e9nkex13">
      <div class="css-8s6a6w e9nkex14">
        <a href="/user/${comment.user.username}" class="css-1mvrrzr e9nkex15">
          <img src="${comment.user.profileImage || '/default-profile.png'}" alt="프로필" class="css-1cqverl e9nkex16">
        </a>
        <div class="css-1fp0dlg e9nkex17">
          <div class="css-1xxe1k4 e9nkex19">
            <a href="/user/${comment.user.username}" class="css-n3xrnb e9nkex110">${comment.user.username}</a>
            <span class="css-1fwu8f e9nkex112">${formatDate(comment.createdAt)}</span>
          </div>
          <div class="css-1f7lx0i e9nkex113">
            <div class="css-1o3ro91 e9nkex115">${comment.content}</div>
          </div>
          <div class="css-1u51lz9 e9nkex118">
            <button type="button" class="css-1h8wiil e9nkex119" data-comment-like-button="${comment.id}">
              <span>${comment.liked ? '좋아요 취소' : '좋아요'}</span>
              <span class="css-1oa6jh2 e9nkex120">${comment.likeCount || 0}</span>
            </button>
            ${comment.isOwner ? `
              <button type="button" class="css-1h8wiil e9nkex119" data-comment-edit-button="${comment.id}">수정</button>
              <button type="button" class="css-1h8wiil e9nkex119" data-comment-delete-button="${comment.id}">삭제</button>
            ` : ''}
          </div>
        </div>
      </div>
    </div>
  `;
  
  // 이벤트 리스너 추가 (필요시)
  setupCommentEventListeners(li, comment, discussId);
  
  return li;
}

/**
 * 날짜 포맷팅 헬퍼 함수
 * @param {string} dateString - ISO 날짜 문자열
 * @returns {string} 포맷된 날짜
 */
function formatDate(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now - date;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  
  if (diffMin < 1) return '방금 전';
  if (diffMin < 60) return `${diffMin}분 전`;
  if (diffHour < 24) return `${diffHour}시간 전`;
  if (diffDay < 7) return `${diffDay}일 전`;
  
  return `${date.getFullYear()}.${(date.getMonth() + 1).toString().padStart(2, '0')}.${date.getDate().toString().padStart(2, '0')}`;
}

/**
 * 댓글 요소에 이벤트 리스너 추가
 * @param {HTMLElement} element - 댓글 요소
 * @param {object} comment - 댓글 데이터
 * @param {string} discussId - 게시물 ID
 */
function setupCommentEventListeners(element, comment, discussId) {
  // 좋아요 버튼 클릭 이벤트
  const likeBtn = element.querySelector(`[data-comment-like-button="${comment.id}"]`);
  if (likeBtn) {
    likeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // 좋아요 액션 기록
      recordUserAction(USER_ACTION.LIKE_ACTION, { 
        discussId, 
        commentId: comment.id,
        targetId: comment.id
      });
      
      // 좋아요 또는 좋아요 취소 API 호출
      const requestId = `like_comment_${comment.id}_${Date.now()}`;
      if (comment.liked) {
        scheduleRequest(
          () => unlikeComment(comment.id, discussId),
          PRIORITY.USER_DIRECT_ACTION,
          "CommentUnlike",
          3,
          requestId,
          USER_ACTION.LIKE_ACTION,
          { discussId, commentId: comment.id }
        );
      } else {
        scheduleRequest(
          () => likeComment(comment.id, discussId),
          PRIORITY.USER_DIRECT_ACTION,
          "CommentLike",
          3,
          requestId,
          USER_ACTION.LIKE_ACTION,
          { discussId, commentId: comment.id }
        );
      }
    });
  }
  
  // 수정 버튼 클릭 이벤트
  const editBtn = element.querySelector(`[data-comment-edit-button="${comment.id}"]`);
  if (editBtn) {
    editBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // 편집 중인 댓글 집합에 추가
      window.__editingCommentSet.add(comment.id);
      
      // 수정 UI로 전환
      const contentDiv = element.querySelector('.css-1o3ro91.e9nkex115');
      if (contentDiv) {
        const originalContent = comment.content;
        const editForm = document.createElement('div');
        editForm.className = 'comment-edit-form';
        editForm.innerHTML = `
          <textarea class="css-2x8g4q e9nkex123">${originalContent}</textarea>
          <div class="css-1u51lz9 e9nkex118">
            <button type="button" class="css-1h8wiil e9nkex119 save-button">저장</button>
            <button type="button" class="css-1h8wiil e9nkex119 cancel-button">취소</button>
          </div>
        `;
        
        contentDiv.replaceWith(editForm);
        
        // 저장 버튼 이벤트
        editForm.querySelector('.save-button').addEventListener('click', () => {
          const newContent = editForm.querySelector('textarea').value.trim();
          if (newContent) {
            // 우선순위 적용하여 댓글 수정 요청
            const requestId = `edit_comment_${comment.id}_${Date.now()}`;
            scheduleRequest(
              () => updateComment(comment.id, newContent, discussId),
              PRIORITY.USER_DIRECT_ACTION,
              "CommentEdit",
              3,
              requestId,
              USER_ACTION.COMMENT_CREATE,
              { discussId, commentId: comment.id }
            );
          }
          
          // 편집 상태 해제
          window.__editingCommentSet.delete(comment.id);
        });
        
        // 취소 버튼 이벤트
        editForm.querySelector('.cancel-button').addEventListener('click', () => {
          // 원래 콘텐츠로 복원
          const newContentDiv = document.createElement('div');
          newContentDiv.className = 'css-1o3ro91 e9nkex115';
          newContentDiv.textContent = originalContent;
          editForm.replaceWith(newContentDiv);
          
          // 편집 상태 해제
          window.__editingCommentSet.delete(comment.id);
        });
        
        // 포커스 설정
        editForm.querySelector('textarea').focus();
      }
    });
  }
  
  // 삭제 버튼 클릭 이벤트
  const deleteBtn = element.querySelector(`[data-comment-delete-button="${comment.id}"]`);
  if (deleteBtn) {
    deleteBtn.addEventListener('click', (e) => {
      e.preventDefault();
      
      if (confirm('정말로 이 댓글을 삭제하시겠습니까?')) {
        // 우선순위 적용하여 댓글 삭제 요청
        const requestId = `delete_comment_${comment.id}_${Date.now()}`;
        scheduleRequest(
          () => deleteComment(comment.id, discussId),
          PRIORITY.USER_DIRECT_ACTION,
          "CommentDelete",
          3,
          requestId,
          USER_ACTION.COMMENT_CREATE,
          { discussId, commentId: comment.id }
        );
      }
    });
  }
}

/**
 * 댓글 수 UI 업데이트
 * @param {string} discussId - 게시물 ID
 * @param {number} count - 댓글 수
 */
function updateCommentCountUI(discussId, count) {
  // 댓글 수 표시 요소 찾기
  const countElement = document.querySelector(`[data-discuss-id="${discussId}"] .css-2d5p6p.euhmxlr1 span`);
  if (countElement) {
    countElement.textContent = `댓글 ${count}개`;
  }
}

/**
 * 더보기 버튼 UI 업데이트
 * @param {string} discussId - 게시물 ID
 * @param {object} data - 댓글 데이터
 */
function updateLoadMoreButtonUI(discussId, data) {
  // 더보기 버튼 컨테이너 찾기
  const loadMoreContainer = document.querySelector(`[data-discuss-id="${discussId}"] .css-4e8bhg.euhmxlr2 .css-5cxp0r.e7uljkc1`);
  if (!loadMoreContainer) return;
  
  const comments = data.comments || [];
  const total = data.total || 0;
  
  // 더 로드할 댓글이 있는지 확인
  if (comments.length < total) {
    // 더보기 버튼 표시
    loadMoreContainer.style.display = 'block';
    loadMoreContainer.innerHTML = `
      <button type="button" class="css-1ikn90u e7uljkc2" onclick="loadMoreComments('${discussId}')">
        더보기 (${comments.length}/${total})
      </button>
    `;
    
    // 완전 로드 상태 업데이트
    window.__commentFullyLoadedMap[discussId] = false;
  } else {
    // 더보기 버튼 숨김
    loadMoreContainer.style.display = 'none';
    
    // 완전 로드 상태 업데이트
    window.__commentFullyLoadedMap[discussId] = true;
    userInteractionState.fullyLoadedComments.add(discussId);
  }
}

/**
 * 댓글용 좋아요/좋아요 취소 패턴 함수
 * @param {string} commentId - 댓글 ID
 * @param {string} discussId - 게시물 ID
 */
async function performCommentLikeUnlikePattern(commentId, discussId) {
  console.log(`[PATTERN] 댓글 좋아요/좋아요 취소 패턴 시작: ${commentId}`);
  
  // 패턴 시작 플래그 설정 (이미 패턴 중인지 확인용)
  if (!window.__commentLikePatterns) {
    window.__commentLikePatterns = new Map();
  }
  
  // 이미 실행 중인 패턴이 있으면 중단
  if (window.__commentLikePatterns.has(commentId)) {
    console.log(`[PATTERN] 이미 실행 중인 댓글 패턴 존재: ${commentId}`);
    return;
  }
  
  // 새 패턴 시작 플래그 설정
  window.__commentLikePatterns.set(commentId, true);
  
  // 패턴 실행 루프
  const runCommentPatternLoop = async () => {
    try {
      // 패턴이 중단되었는지 확인
      if (!window.__commentLikePatterns.has(commentId)) {
        console.log(`[PATTERN] 댓글 패턴 중단됨: ${commentId}`);
        return;
      }
      
      // 1. 좋아요 API 직접 호출
      console.log(`[PATTERN] 댓글 좋아요 요청: ${commentId}`);
      const likeApiUrl = `/api/comments/${commentId}/like`;
      const likeOptions = {
        method: "POST",
        credentials: "include",
        headers: { ...requestOptions.headers }
      };
      
      try {
        const likeResponse = await throttledFetch(likeApiUrl, likeOptions);
        const likeData = await likeResponse.json();
        
        if (likeData.success) {
          updateCommentLikeUI(commentId, true, likeData.likeCount || 0);
        }
      } catch (err) {
        console.warn(`[PATTERN] 댓글 좋아요 요청 실패: ${commentId}`, err);
      }
      
      // 2. 좋아요 취소 요청 10번 연속 전송
      for (let i = 0; i < 10; i++) {
        // 패턴이 중단되었는지 확인
        if (!window.__commentLikePatterns.has(commentId)) {
          console.log(`[PATTERN] 댓글 패턴 중단됨: ${commentId}`);
          return;
        }
        
        console.log(`[PATTERN] 댓글 좋아요 취소 요청 ${i+1}/10: ${commentId}`);
        const unlikeApiUrl = `/api/comments/${commentId}/unlike`;
        const unlikeOptions = {
          method: "POST",
          credentials: "include",
          headers: { ...requestOptions.headers }
        };
        
        try {
          const unlikeResponse = await throttledFetch(unlikeApiUrl, unlikeOptions);
          const unlikeData = await unlikeResponse.json();
          
          if (unlikeData.success) {
            updateCommentLikeUI(commentId, false, unlikeData.likeCount || 0);
          }
        } catch (err) {
          console.warn(`[PATTERN] 댓글 좋아요 취소 요청 실패 (${i+1}/10): ${commentId}`, err);
        }
      }
      
      // 3. 1초 대기 후 다시 실행
      console.log(`[PATTERN] 댓글 1초 대기 후 재실행: ${commentId}`);
      setTimeout(runCommentPatternLoop, 1000);
    } catch (err) {
      console.error(`[PATTERN] 댓글 패턴 실행 중 오류: ${commentId}`, err);
      
      // 오류가 발생해도 계속 실행 시도
      setTimeout(runCommentPatternLoop, 1000);
    }
  };
  
  // 패턴 실행 시작
  runCommentPatternLoop();
}

/**
 * 댓글 패턴 중단 함수
 * @param {string} commentId - 댓글 ID (없으면 모든 패턴 중단)
 */
function stopCommentLikePattern(commentId = null) {
  if (!window.__commentLikePatterns) return;
  
  if (commentId) {
    // 특정 패턴만 중단
    window.__commentLikePatterns.delete(commentId);
    console.log(`[PATTERN] 댓글 패턴 중단: ${commentId}`);
  } else {
    // 모든 패턴 중단
    window.__commentLikePatterns.clear();
    console.log(`[PATTERN] 모든 댓글 패턴 중단`);
  }
}

/**
 * 수정된 댓글 좋아요 함수 - 패턴 기능 추가
 * @param {string} commentId - 댓글 ID
 * @param {string} discussId - 게시물 ID
 */
async function likeComment(commentId, discussId) {
  // API URL 및 옵션 설정
  const apiUrl = `/api/comments/${commentId}/like`;
  const options = {
    method: "POST",
    credentials: "include",
    headers: { ...requestOptions.headers }
  };
  
  try {
    const response = await throttledFetch(apiUrl, options);
    const data = await response.json();
    
    if (data.success) {
      // 성공 시 UI 업데이트
      updateCommentLikeUI(commentId, true, data.likeCount || 0);
      
      // 댓글에 대해서도 패턴 실행 (commentId를 키로 사용)
      performCommentLikeUnlikePattern(commentId, discussId);
    }
    
    return data;
  } catch (err) {
    console.error(`[COMMENT] 댓글 좋아요 실패: ${commentId}`, err);
    throw err;
  }
}

/**
 * 수정된 댓글 좋아요 취소 함수 - 패턴 중단
 * @param {string} commentId - 댓글 ID
 * @param {string} discussId - 게시물 ID
 */
async function unlikeComment(commentId, discussId) {
  // 패턴 중단
  stopCommentLikePattern(commentId);
  
  // API URL 및 옵션 설정
  const apiUrl = `/api/comments/${commentId}/unlike`;
  const options = {
    method: "POST",
    credentials: "include",
    headers: { ...requestOptions.headers }
  };
  
  try {
    const response = await throttledFetch(apiUrl, options);
    const data = await response.json();
    
    if (data.success) {
      // 성공 시 UI 업데이트
      updateCommentLikeUI(commentId, false, data.likeCount || 0);
    }
    
    return data;
  } catch (err) {
    console.error(`[COMMENT] 댓글 좋아요 취소 실패: ${commentId}`, err);
    throw err;
  }
}

/**
 * 댓글 좋아요 UI 업데이트
 * @param {string} commentId - 댓글 ID
 * @param {boolean} liked - 좋아요 상태
 * @param {number} likeCount - 좋아요 수
 */
function updateCommentLikeUI(commentId, liked, likeCount) {
  // 좋아요 버튼 찾기
  const likeBtn = document.querySelector(`[data-comment-like-button="${commentId}"]`);
  if (!likeBtn) return;
  
  // 텍스트 업데이트
  const textSpan = likeBtn.querySelector('span:first-child');
  if (textSpan) {
    textSpan.textContent = liked ? '좋아요 취소' : '좋아요';
  }
  
  // 개수 업데이트
  const countSpan = likeBtn.querySelector('.css-1oa6jh2.e9nkex120');
  if (countSpan) {
    countSpan.textContent = likeCount;
  }
  
  // 캐시 업데이트
  updateCommentCache(commentId, { liked, likeCount });
}

/**
 * 댓글 수정 함수
 * @param {string} commentId - 댓글 ID
 * @param {string} content - 새 내용
 * @param {string} discussId - 게시물 ID
 */
async function updateComment(commentId, content, discussId) {
  // API URL 및 옵션 설정
  const apiUrl = `/api/comments/${commentId}`;
  const options = {
    method: "PUT",
    credentials: "include",
    headers: { 
      ...requestOptions.headers,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ content })
  };
  
  try {
    const response = await throttledFetch(apiUrl, options);
    const data = await response.json();
    
    if (data.success) {
      // 성공 시 UI 업데이트
      updateCommentContentUI(commentId, content);
      
      // 캐시 업데이트
      updateCommentCache(commentId, { content });
    }
    
    return data;
  } catch (err) {
    console.error(`[COMMENT] 댓글 수정 실패: ${commentId}`, err);
    throw err;
  }
}

/**
 * 댓글 내용 UI 업데이트
 * @param {string} commentId - 댓글 ID
 * @param {string} content - 새 내용
 */
function updateCommentContentUI(commentId, content) {
  // 댓글 요소 찾기
  const commentLi = document.querySelector(`li[data-comment-id="${commentId}"]`);
  if (!commentLi) return;
  
  // 에디터가 열려있으면 닫고 업데이트된 내용으로 교체
  const editForm = commentLi.querySelector('.comment-edit-form');
  if (editForm) {
    const contentDiv = document.createElement('div');
    contentDiv.className = 'css-1o3ro91 e9nkex115';
    contentDiv.textContent = content;
    editForm.replaceWith(contentDiv);
  } else {
    // 에디터가 없는 경우 직접 내용 업데이트
    const contentDiv = commentLi.querySelector('.css-1o3ro91.e9nkex115');
    if (contentDiv) {
      contentDiv.textContent = content;
    }
  }
  
  // 편집 상태 해제
  window.__editingCommentSet.delete(commentId);
}

/**
 * 댓글 삭제 함수
 * @param {string} commentId - 댓글 ID
 * @param {string} discussId - 게시물 ID
 */
async function deleteComment(commentId, discussId) {
  // API URL 및 옵션 설정
  const apiUrl = `/api/comments/${commentId}`;
  const options = {
    method: "DELETE",
    credentials: "include",
    headers: { ...requestOptions.headers }
  };
  
  try {
    const response = await throttledFetch(apiUrl, options);
    const data = await response.json();
    
    if (data.success) {
      // 성공 시 UI에서 댓글 제거
      removeCommentFromUI(commentId, discussId);
      
      // 캐시에서도 제거
      removeCommentFromCache(commentId, discussId);
      
      // 댓글 수 업데이트
      const total = window.__commentTotalMap[discussId] || 0;
      if (total > 0) {
        window.__commentTotalMap[discussId] = total - 1;
        updateCommentCountUI(discussId, total - 1);
      }
    }
    
    return data;
  } catch (err) {
    console.error(`[COMMENT] 댓글 삭제 실패: ${commentId}`, err);
    throw err;
  }
}

/**
 * UI에서 댓글 제거
 * @param {string} commentId - 댓글 ID
 * @param {string} discussId - 게시물 ID
 */
function removeCommentFromUI(commentId, discussId) {
  // 댓글 요소 찾기 및 제거
  const commentLi = document.querySelector(`li[data-comment-id="${commentId}"]`);
  if (commentLi) {
    commentLi.remove();
  }
}

/**
 * 댓글 캐시 업데이트
 * @param {string} commentId - 댓글 ID
 * @param {object} updates - 업데이트할 속성들
 */
function updateCommentCache(commentId, updates) {
  // 모든 게시물 캐시 순회
  for (const [discussId, comments] of Object.entries(window.__commentCacheForComments)) {
    // 해당 댓글 찾기
    const commentIndex = comments.findIndex(c => c.id === commentId);
    if (commentIndex !== -1) {
      // 캐시 업데이트
      window.__commentCacheForComments[discussId][commentIndex] = {
        ...window.__commentCacheForComments[discussId][commentIndex],
        ...updates
      };
      break;
    }
  }
}

/**
 * 캐시에서 댓글 제거
 * @param {string} commentId - 댓글 ID
 * @param {string} discussId - 게시물 ID
 */
function removeCommentFromCache(commentId, discussId) {
  // 특정 게시물의 댓글 캐시에서 제거
  if (window.__commentCacheForComments[discussId]) {
    window.__commentCacheForComments[discussId] = window.__commentCacheForComments[discussId].filter(
      comment => comment.id !== commentId
    );
  }
}

/******************************************************************* 
 * 전역에서 쓸 "스토리지 설정" 관련 변수들 + 로딩, 감시
 *******************************************************************/
let allowHtml = false;
let allowMarkdown = false;
let allowJs = false;
let extensionEnabled = true; // 기본값: true 라 가정

// 댓글 캐시(글ID -> [commentData, ...])
if (!window.__commentCacheForComments) {
  window.__commentCacheForComments = {};
}

// -------------------------------------------------------------
// (추가) "더보기 중복 클릭" 문제 방지용 로딩 상태
// -------------------------------------------------------------
if (!window.__commentIsLoadingMap) {
  window.__commentIsLoadingMap = {};
}

// -------------------------------------------------------------
// (추가) 편집 중인 댓글 ID 저장용(중복 DOM 갱신 방지)
// -------------------------------------------------------------
if (!window.__editingCommentSet) {
  window.__editingCommentSet = new Set();
}

// [수정/추가] "페이지별 searchAfter" 목록
//             첫 페이지는 null(검색 파라미터 없이 요청)
if (!window.__loadedSearchAfters) {
  window.__loadedSearchAfters = [ null ];
}

/*******************************************************************
 * (추가) 댓글 관련해서: 전체 댓글 수, 완전 로딩 여부 저장용 Map
 *******************************************************************/
if (!window.__commentTotalMap) {
  window.__commentTotalMap = {};  // discussId -> totalCount
}
if (!window.__commentFullyLoadedMap) {
  window.__commentFullyLoadedMap = {}; // discussId -> bool
}

/*******************************************************************
 * (추가) "요청 스케줄링"을 위한 전역 큐
 *   - 너무 많은 fetch가 동시에 몰리지 않도록 순차적으로 처리
 *******************************************************************/
let requestQueue = []; // { fn: ()=>Promise, priority: number, label?: string }[]
let processingRequest = false; // 지금 어떤 요청(fn) 실행 중인지 여부

// 네트워크 상태 추적
let isOnline = navigator.onNetworkChange ? navigator.onLine : true;
window.addEventListener('online', () => {
  isOnline = true;
  console.log("[NETWORK] 온라인 상태로 변경됨, 큐 처리 재개");
  scheduleQueueProcessing(100); // 온라인 복귀 시 빠르게 처리
});
window.addEventListener('offline', () => {
  isOnline = false;
  console.log("[NETWORK] 오프라인 상태로 변경됨, 큐 처리 일시 중단");
});

// 큐 처리 스케줄링 관련 변수
let queueProcessingTimeout = null;
let processingFailCount = 0;
const MAX_PROCESSING_FAILS = 5;

// 요청 중복 방지용 Map
const pendingRequests = new Map();

// 저장된 요청 정보
let savedRequests = new Map();

// 토큰 새로고침 관련 변수
let lastTokenRefresh = 0;
const TOKEN_REFRESH_INTERVAL = 60000; // 1분마다 토큰 갱신 시도
let consecutiveForbiddenCount = 0;
const MAX_FORBIDDEN_BEFORE_REFRESH = 3; // 연속 3번 403 에러 시 강제 토큰 갱신

/*******************************************************************
 * (개선) 사용자 상호작용 우선순위 시스템
 *******************************************************************/

// 우선순위 레벨 상수 세분화
const PRIORITY = {
  USER_DIRECT_ACTION: 0,    // 사용자가 직접 수행한 중요 액션 (최우선)
  VISIBLE_COMMENTS: 1,      // 화면에 보이는 펼쳐진 댓글 영역
  CURRENT_VIEW_CONTENT: 2,  // 현재 보고 있는 콘텐츠 영역
  LATEST_CONTENT: 3,        // 최신 글/콘텐츠 (맨 위 부분)
  BACKGROUND: 4,            // 백그라운드 작업
  LOW: 5                    // 비핵심 작업
};

// 사용자 액션 타입 정의
const USER_ACTION = {
  COMMENT_CLICK: 'comment_click',       // 댓글 클릭
  COMMENT_LOAD_MORE: 'comment_more',    // 댓글 더보기
  POST_LOAD_MORE: 'post_more',          // 글 더보기
  COMMENT_CREATE: 'comment_create',     // 댓글 작성
  LIKE_ACTION: 'like_action',           // 좋아요 액션
  SCROLL: 'scroll',                     // 스크롤
  REFRESH: 'refresh'                    // 새로고침
};

// 확장된 사용자 상호작용 추적
const userInteractionState = {
  lastAction: null,                     // 마지막 액션 타입
  lastActionTime: Date.now(),           // 마지막 액션 시간
  lastActionTargetId: null,             // 마지막 액션 대상 ID
  lastScrollTime: Date.now(),           // 마지막 스크롤 시간
  visiblePosts: new Set(),              // 화면에 보이는 게시물 ID
  visibleComments: new Set(),           // 화면에 보이는 댓글 ID
  expandedCommentSections: new Set(),   // 펼쳐진 댓글 섹션들
  fullyLoadedComments: new Set(),       // 모두 로드된 댓글 섹션들
  userAtTop: false,                     // 사용자가 페이지 상단에 있는지
  userIdleTime: 0,                      // 유휴 시간 (초)
  recentActionHistory: [],              // 최근 액션 이력 (최대 10개)
  activeRequests: new Map()             // 현재 활성화된 요청들
};

/**
 * 사용자 액션 기록 함수 - 모든 상호작용 로직의 시작점
 * @param {string} actionType - USER_ACTION 상수 중 하나
 * @param {object} data - 액션 관련 데이터 (discussId, commentId 등)
 */
function recordUserAction(actionType, data = {}) {
  const now = Date.now();
  const prevAction = userInteractionState.lastAction;
  
  // 상태 업데이트
  userInteractionState.lastAction = actionType;
  userInteractionState.lastActionTime = now;
  userInteractionState.lastActionTargetId = data.targetId || data.discussId || data.commentId || null;
  userInteractionState.userIdleTime = 0; // 활동 감지로 유휴 시간 리셋
  
  // 스크롤 시간 업데이트
  if (actionType === USER_ACTION.SCROLL) {
    userInteractionState.lastScrollTime = now;
    
    // 페이지 최상단 감지
    userInteractionState.userAtTop = window.scrollY < 200;
  }
  
  // 댓글 섹션 확장 상태 추적
  if (actionType === USER_ACTION.COMMENT_CLICK && data.discussId) {
    userInteractionState.expandedCommentSections.add(data.discussId);
  }
  
  // 댓글 전체 로드 상태 추적
  if (actionType === USER_ACTION.COMMENT_LOAD_MORE && data.discussId) {
    if (window.__commentFullyLoadedMap[data.discussId]) {
      userInteractionState.fullyLoadedComments.add(data.discussId);
    }
  }
  
  // 액션 기록 추가
  userInteractionState.recentActionHistory.unshift({
    type: actionType,
    targetId: userInteractionState.lastActionTargetId,
    time: now
  });
  
  // 최대 10개 기록 유지
  if (userInteractionState.recentActionHistory.length > 10) {
    userInteractionState.recentActionHistory.pop();
  }
  
  // 활성 요청 관리
  if (data.requestId) {
    userInteractionState.activeRequests.set(data.requestId, {
      type: actionType,
      targetId: userInteractionState.lastActionTargetId,
      priority: calculatePriorityForAction(actionType, data),
      time: now
    });
  }
  
  // 디버깅
  console.log(`[Action] ${actionType} -> ${JSON.stringify(data)}`);
  
  // 화면 요소 업데이트 트리거
  updateVisibleElements();
  
  // 중요한 액션 후에는 우선순위 재조정
  if (actionType !== USER_ACTION.SCROLL) {
    adjustAllRequestPriorities();
  }
  
  return calculatePriorityForAction(actionType, data);
}

/**
 * 액션 타입과 컨텍스트에 따른 우선순위 계산
 * @param {string} actionType - 액션 타입
 * @param {object} data - 액션 데이터
 * @returns {number} 계산된 우선순위 값
 */
function calculatePriorityForAction(actionType, data = {}) {
  // 기본 우선순위 설정
  let priority;
  
  switch (actionType) {
    // 1. 사용자 직접 수행 액션 - 최우선
    case USER_ACTION.COMMENT_CLICK:
    case USER_ACTION.COMMENT_LOAD_MORE:
    case USER_ACTION.POST_LOAD_MORE: 
    case USER_ACTION.COMMENT_CREATE:
    case USER_ACTION.LIKE_ACTION:
      priority = PRIORITY.USER_DIRECT_ACTION;
      break;
      
    // 2. 화면에 보이는 펼쳐진 댓글 영역
    case USER_ACTION.REFRESH:
      if (data.discussId && userInteractionState.expandedCommentSections.has(data.discussId) && 
          userInteractionState.fullyLoadedComments.has(data.discussId) &&
          userInteractionState.visiblePosts.has(data.discussId)) {
        priority = PRIORITY.VISIBLE_COMMENTS;
      } 
      // 3. 현재 보고 있는 콘텐츠 영역
      else if (data.discussId && userInteractionState.visiblePosts.has(data.discussId)) {
        priority = PRIORITY.CURRENT_VIEW_CONTENT;
      }
      // 4. 최신 글/콘텐츠 (맨 위 부분) 
      else if (userInteractionState.userAtTop) {
        priority = PRIORITY.LATEST_CONTENT;
      } 
      // 5. 백그라운드 작업
      else {
        priority = PRIORITY.BACKGROUND;
      }
      break;
      
    // 기본값은 낮은 우선순위
    default:
      priority = PRIORITY.LOW;
  }
  
  // 컨텍스트 기반 우선순위 미세 조정
  
  // 최근에 상호작용한 항목에 대한 작업은 우선순위 약간 상승
  if (data.targetId === userInteractionState.lastActionTargetId && 
      Date.now() - userInteractionState.lastActionTime < 10000) {
    priority -= 0.1;
  }
  
  // 화면에 보이는 항목에 대한 작업은 약간 우선순위 상승
  if (data.discussId && userInteractionState.visiblePosts.has(data.discussId)) {
    priority -= 0.2;
  }
  
  // 유휴 시간에 따른 조정 (1분 이상 유휴 상태면 백그라운드 우선순위 낮춤)
  if (priority >= PRIORITY.BACKGROUND && userInteractionState.userIdleTime > 60) {
    priority += 0.5;
  }
  
  return Math.max(0, priority); // 우선순위는 최소 0 보장
}

/**
 * 현재 화면에 보이는 요소들 업데이트 (게시물, 댓글 등)
 */
function updateVisibleElements() {
  // 이전 상태 백업
  const prevVisiblePosts = new Set(userInteractionState.visiblePosts);
  const prevVisibleComments = new Set(userInteractionState.visibleComments);
  
  // 상태 초기화
  userInteractionState.visiblePosts.clear();
  userInteractionState.visibleComments.clear();
  
  // 1. 화면에 보이는 글 확인
  const postLis = document.querySelectorAll("ul.css-1urx3um.e18x7bg03 li");
  postLis.forEach(li => {
    if (isInViewport(li) && li.__itemData && li.__itemData.id) {
      userInteractionState.visiblePosts.add(li.__itemData.id);
    }
  });
  
  // 2. 화면에 보이는 댓글 확인
  const commentLis = document.querySelectorAll("li.css-u1nrp7.e9nkex10");
  commentLis.forEach(li => {
    const likeBtn = li.querySelector('[data-comment-id]');
    if (isInViewport(li) && likeBtn) {
      const commentId = likeBtn.getAttribute('data-comment-id');
      if (commentId) {
        userInteractionState.visibleComments.add(commentId);
      }
    }
  });
  
  // 3. 댓글 섹션 확장 상태 업데이트
  const openCommentSections = document.querySelectorAll("ul.css-1urx3um.e18x7bg03 li .css-4e8bhg.euhmxlr2");
  openCommentSections.forEach((section) => {
    const li = section.closest('li');
    if (li && li.__itemData && li.__itemData.id) {
      userInteractionState.expandedCommentSections.add(li.__itemData.id);
      
      // 완전히 로드된 댓글 섹션 확인
      if (window.__commentFullyLoadedMap[li.__itemData.id]) {
        userInteractionState.fullyLoadedComments.add(li.__itemData.id);
      }
    }
  });
  
  // 가시성 변화가 있으면 우선순위 재조정
  if (hasVisibilityChanged(prevVisiblePosts, userInteractionState.visiblePosts) ||
      hasVisibilityChanged(prevVisibleComments, userInteractionState.visibleComments)) {
    adjustAllRequestPriorities();
  }
}

/**
 * 요청 스케줄링 함수 (우선순위 기반)
 * @param {Function} fn - 실행할 함수
 * @param {number} priority - 우선순위 (낮을수록 높은 우선순위)
 * @param {string} label - 요청 라벨 (디버깅용)
 * @param {number} maxRetries - 최대 재시도 횟수
 * @param {string} requestId - 요청 식별자
 * @param {string} type - 요청 타입
 * @param {object} data - 요청 관련 데이터
 */
function scheduleRequest(fn, priority, label, maxRetries = 3, requestId = null, type = null, data = null) {
  // 이미 처리 중인 요청인지 확인
  if (requestId && pendingRequests.has(requestId)) {
    console.log(`[QUEUE] 이미 처리 중인 요청 무시: ${label} (${requestId})`);
    return;
  }
  
  // ID가 있는 요청은 중복 방지 맵에 추가
  if (requestId) {
    pendingRequests.set(requestId, Date.now());
    
    // 실행 완료 시 맵에서 제거할 수 있도록 원본 함수 래핑
    const originalFn = fn;
    fn = async () => {
      try {
        const result = await originalFn();
        return result;
      } finally {
        pendingRequests.delete(requestId);
      }
    };
  }
  
  // 요청 큐에 추가
  requestQueue.push({
    fn,
    priority,
    label: `${label} (Priority: ${priority})`,
    maxRetries,
    requestId,
    type,
    data
  });
  
  // 우선순위에 따라 큐 정렬
  requestQueue.sort((a, b) => a.priority - b.priority);
  
  // 큐 처리 예약
  scheduleQueueProcessing();
}

/**
 * 영구 저장 요청 불러오기
 */
function loadPendingRequestsFromStorage() {
  try {
    const savedRequestsString = localStorage.getItem('pendingRequests');
    if (savedRequestsString) {
      const savedData = JSON.parse(savedRequestsString);
      // 만료된 요청 필터링 (1시간 이상 지난 요청)
      const now = Date.now();
      const filteredData = {};
      let count = 0;
      
      for (const [id, request] of Object.entries(savedData)) {
        if (now - request.timestamp < 3600000) { // 1시간 이내
          filteredData[id] = request;
          count++;
        }
      }
      
      if (count > 0) {
        savedRequests = new Map(Object.entries(filteredData));
        console.log(`[STORAGE] ${count}개의 저장된 요청 복원`);
        
        // 중요 요청 복원
        for (const [id, request] of savedRequests.entries()) {
          if (request.type === 'comment_create' || request.type === 'like_action') {
            restoreSavedRequest(id, request);
          }
        }
      }
    }
  } catch (err) {
    console.warn("[STORAGE] 저장된 요청 로드 실패:", err);
  }
}

/**
 * 저장된 요청 복원 함수
 */
function restoreSavedRequest(id, request) {
  // 요청 타입에 따라 적절한 함수 선택
  let fn;
  let priority = 1.0; // 중요하지만 최우선은 아님
  let label = "SavedRequest";
  
  switch (request.type) {
    case 'comment_create':
      if (request.data.discussId && request.data.commentText) {
        fn = () => createComment(request.data.discussId, request.data.commentText);
        label = "SavedComment";
      }
      break;
    case 'like_action':
      if (request.data.discussId) {
        fn = () => likeDiscuss(request.data.discussId);
        label = "SavedLike";
      }
      break;
    case 'unlike_action':
      if (request.data.discussId) {
        fn = () => unlikeDiscuss(request.data.discussId);
        label = "SavedUnlike";
      }
      break;
    // 다른 중요 요청 타입 추가 가능
  }
  
  if (fn) {
    scheduleRequest(fn, priority, label, 3, id, request.type, request.data);
  }
}

/**
 * 대기 중인 요청 저장 함수
 */
function savePendingRequestsToStorage() {
  try {
    if (savedRequests.size > 0) {
      const dataToSave = {};
      for (const [id, request] of savedRequests.entries()) {
        dataToSave[id] = request;
      }
      localStorage.setItem('pendingRequests', JSON.stringify(dataToSave));
    } else {
      localStorage.removeItem('pendingRequests');
    }
  } catch (err) {
    console.warn("[STORAGE] 요청 저장 실패:", err);
  }
}

/**
 * 요소가 화면에 보이는지 확인
 * @param {HTMLElement} element - 확인할 DOM 요소
 * @returns {boolean} 화면에 보이면 true
 */
function isInViewport(element) {
  if (!element) return false;
  
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= -rect.height &&
    rect.left >= -rect.width &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) + rect.height &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth) + rect.width
  );
}

/**
 * 두 집합의 차이 확인
 * @param {Set} prevSet - 이전 집합
 * @param {Set} currentSet - 현재 집합
 * @returns {boolean} 차이가 있으면 true
 */
function hasVisibilityChanged(prevSet, currentSet) {
  if (prevSet.size !== currentSet.size) return true;
  
  for (const item of prevSet) {
    if (!currentSet.has(item)) return true;
  }
  
  return false;
}

/**
 * 사용자 액션 기반 우선순위 적용된 댓글 펼치기 함수
 * @param {string} discussId - 게시물 ID
 */
function fetchCommentsThenExpandWithContext(discussId) {
  // 1. 사용자 액션 기록
  const priority = recordUserAction(USER_ACTION.COMMENT_CLICK, { discussId, targetId: discussId });
  
  // 2. 중복 요청 방지
  if (window.__commentIsLoadingMap[discussId]) {
    console.log(`[COMMENT] 이미 로딩 중: ${discussId}`);
    return;
  }
  
  // 3. 요청 스케줄링 (우선순위 적용)
  const requestId = `fetch_comments_${discussId}_${Date.now()}`;
  
  scheduleRequest(
    () => window.originalFetchCommentsThenExpand(discussId),
    priority,
    "CommentFetch",
    3,
    requestId,
    USER_ACTION.COMMENT_CLICK,
    { discussId }
  );
}

/**
 * 사용자 액션 기반 우선순위 적용된 댓글 더보기 함수
 * @param {string} discussId - 게시물 ID
 */
function loadMoreCommentsWithContext(discussId) {
  // 1. 사용자 액션 기록
  const priority = recordUserAction(USER_ACTION.COMMENT_LOAD_MORE, { discussId, targetId: discussId });
  
  // 2. 중복 요청 방지
  if (window.__commentIsLoadingMap[discussId]) {
    console.log(`[COMMENT] 댓글 더보기 이미 로딩 중: ${discussId}`);
    return;
  }
  
  // 3. 요청 스케줄링 (우선순위 적용)
  const requestId = `load_more_comments_${discussId}_${Date.now()}`;
  
  scheduleRequest(
    () => window.originalLoadMoreComments(discussId),
    priority,
    "CommentsLoadMore",
    3,
    requestId,
    USER_ACTION.COMMENT_LOAD_MORE,
    { discussId }
  );
}

/**
 * 사용자 액션 기반 우선순위 적용된 댓글 작성 함수
 * @param {string} discussId - 게시물 ID
 * @param {string} commentText - 댓글 내용
 */
function createCommentWithContext(discussId, commentText) {
  // 1. 사용자 액션 기록
  const priority = recordUserAction(USER_ACTION.COMMENT_CREATE, { discussId, targetId: discussId });
  
  // 2. 요청 스케줄링 (우선순위 적용)
  const requestId = `create_comment_${discussId}_${Date.now()}`;
  
  scheduleRequest(
    () => window.originalCreateComment(discussId, commentText),
    priority,
    "CommentCreate",
    3,
    requestId,
    USER_ACTION.COMMENT_CREATE,
    { discussId, commentText }
  );
}

/**
 * 전체 요청 큐의 우선순위 재조정
 */
function adjustAllRequestPriorities() {
  // 큐에 있는 모든 요청의 우선순위 재계산
  requestQueue.forEach(job => {
    if (job.type && job.data) {
      // 현재 컨텍스트에 맞게 우선순위 재계산
      const newPriority = calculatePriorityForAction(job.type, job.data);
      job.priority = newPriority;
    }
  });
  
  // 우선순위에 따라 큐 재정렬
  requestQueue.sort((a, b) => a.priority - b.priority);
  
  // 변경이 있으면 즉시 큐 처리 시작
  if (requestQueue.length > 0) {
    scheduleQueueProcessing(0);
  }
}

/**
 * 사용자 상호작용 이벤트 리스너 설정
 */
function setupEnhancedInteractionListeners() {
  // 스크롤 이벤트 감지
  window.addEventListener('scroll', _.throttle(() => {
    recordUserAction(USER_ACTION.SCROLL);
  }, 300));
  
  // 클릭, 키보드, 마우스 움직임 등 상호작용 감지
  ['click', 'keydown', 'mousemove', 'touchstart'].forEach(eventType => {
    document.addEventListener(eventType, _.throttle(() => {
      userInteractionState.userIdleTime = 0;
    }, 300));
  });
  
  // 화면 요소 정기 검사 (2초마다)
  setInterval(updateVisibleElements, 2000);
  
  // 유휴 시간 트래킹 (10초마다)
  setInterval(() => {
    if (Date.now() - userInteractionState.lastActionTime > 10000) {
      userInteractionState.userIdleTime += 10;
    }
  }, 10000);
  
  // 자동 댓글 새로고침 (30초마다)
  setInterval(() => {
    // 사용자가 활발히 활동 중이거나 최근 스크롤 중이면 자동 새로고침 일시 중단
    if (Date.now() - userInteractionState.lastActionTime > 5000 &&
        Date.now() - userInteractionState.lastScrollTime > 3000) {
      autoRefreshVisibleComments();
    }
  }, 30000);
  
  // 댓글 클릭 이벤트 위임 처리
  document.addEventListener('click', (e) => {
    // 댓글 더보기 버튼 클릭
    if (e.target && e.target.closest('.css-5cxp0r.e7uljkc1')) {
      const li = e.target.closest('li');
      if (li && li.__itemData && li.__itemData.id) {
        // 클릭 즉시 우선순위 설정 (이벤트 위임)
        recordUserAction(USER_ACTION.COMMENT_LOAD_MORE, { 
          discussId: li.__itemData.id, 
          targetId: li.__itemData.id 
        });
      }
    }
    
    // 댓글 섹션 펼치기/접기 버튼 클릭
    if (e.target && (
        e.target.closest('.css-2d5p6p.euhmxlr1') || 
        e.target.closest('.css-4e8bhg.euhmxlr2 .css-lmtjy0.euhmxlr0')
      )) {
      const li = e.target.closest('li');
      if (li && li.__itemData && li.__itemData.id) {
        // 클릭 즉시 우선순위 설정 (이벤트 위임)
        recordUserAction(USER_ACTION.COMMENT_CLICK, { 
          discussId: li.__itemData.id, 
          targetId: li.__itemData.id 
        });
      }
    }
    
    // 좋아요 버튼 클릭
    if (e.target && (
        e.target.closest('[data-like-button]') ||
        e.target.closest('[data-comment-like-button]')
      )) {
      const likeBtn = e.target.closest('[data-like-button]') || 
                      e.target.closest('[data-comment-like-button]');
      
      if (likeBtn) {
        const discussId = likeBtn.getAttribute('data-like-button') ||
                         likeBtn.closest('li')?.__itemData?.id;
        const commentId = likeBtn.getAttribute('data-comment-id');
        
        if (discussId || commentId) {
          // 클릭 즉시 우선순위 설정 (이벤트 위임)
          recordUserAction(USER_ACTION.LIKE_ACTION, { 
            discussId, 
            commentId,
            targetId: commentId || discussId
          });
        }
      }
    }
  });
}

/**
 * 자동 댓글 새로고침 함수 (화면에 보이는 펼쳐진 댓글 섹션)
 */
function autoRefreshVisibleComments() {
  userInteractionState.expandedCommentSections.forEach(discussId => {
    // 완전히 로드되었고 화면에 보이는 댓글 섹션만 새로고침
    if (userInteractionState.fullyLoadedComments.has(discussId) && 
        userInteractionState.visiblePosts.has(discussId)) {
      
      // 새로고침 요청 스케줄링
      const requestId = `auto_refresh_comments_${discussId}_${Date.now()}`;
      const priority = calculatePriorityForAction(USER_ACTION.REFRESH, { discussId });
      
      scheduleRequest(
        () => refetchCommentsAndUpdate(discussId),
        priority,
        "AutoRefreshComments",
        2,
        requestId,
        USER_ACTION.REFRESH,
        { discussId }
      );
    }
  });
}

/**
 * 토큰을 갱신하는 함수
 * @returns {Promise<{csrfToken: string, xToken: string}>} 갱신된 토큰
 */
async function refreshTokens() {
  console.log("[AUTH] 토큰 갱신 시도...");
  
  try {
    // 페이지 내용을 다시 로드하여 새 토큰 얻기
    const response = await fetch(location.href, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      redirect: "follow"
    });
    
    if (!response.ok) {
      throw new Error(`페이지 로드 실패: ${response.status}`);
    }
    
    const html = await response.text();
    
    // HTML에서 CSRF 토큰 추출
    let csrfToken = "";
    const csrfMatch = html.match(/<meta\s+name="csrf-token"\s+content="([^"]+)"/i);
    if (csrfMatch && csrfMatch[1]) {
      csrfToken = csrfMatch[1];
    }
    
    // HTML에서 xToken 추출 (NEXT_DATA에서)
    let xToken = "";
    const nextDataMatch = html.match(/<script\s+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i);
    if (nextDataMatch && nextDataMatch[1]) {
      try {
        const nextData = JSON.parse(nextDataMatch[1]);
        xToken = nextData?.props?.initialState?.common?.user?.xToken || "";
      } catch (e) {
        console.warn("[AUTH] NEXT_DATA JSON 파싱 실패:", e);
      }
    }
    
    if (!csrfToken || !xToken) {
      throw new Error("토큰 추출 실패");
    }
    
    console.log("[AUTH] 토큰 갱신 성공");
    lastTokenRefresh = Date.now();
    consecutiveForbiddenCount = 0;
    
    // 전역 요청 옵션 업데이트
    if (requestOptions && requestOptions.headers) {
      requestOptions.headers["csrf-token"] = csrfToken;
      requestOptions.headers["x-token"] = xToken;
    }
    
    return { csrfToken, xToken };
  } catch (err) {
    console.error("[AUTH] 토큰 갱신 실패:", err);
    throw err;
  }
}

/**
 * 큐 처리 스케줄링 함수 (지연 실행)
 * @param {number} delay - 지연 시간 (ms)
 */
function scheduleQueueProcessing(delay = 50) {
  if (queueProcessingTimeout) {
    clearTimeout(queueProcessingTimeout);
  }
  queueProcessingTimeout = setTimeout(() => {
    queueProcessingTimeout = null;
    processRequestQueue();
  }, delay);
}

/**
 * Fetch 함수에 타임아웃 적용
 */
function fetchWithTimeout(url, options, timeout = 30000) {
  return Promise.race([
    fetch(url, options),
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error(`Fetch timeout for ${url}`)), timeout)
    )
  ]);
}

/**
 * 개선된 fetch 함수 (403 에러 처리 추가)
 */
async function fetchWithRetry(url, options, maxRetries = 3) {
  // 토큰 만료 시간 체크 (1분마다 갱신)
  const now = Date.now();
  if (now - lastTokenRefresh > TOKEN_REFRESH_INTERVAL) {
    try {
      const { csrfToken, xToken } = await refreshTokens();
      
      // 옵션에 새 토큰 적용
      if (options && options.headers) {
        options.headers["csrf-token"] = csrfToken;
        options.headers["x-token"] = xToken;
      }
    } catch (err) {
      console.warn("[AUTH] 정기 토큰 갱신 실패:", err);
      // 실패해도 계속 진행 (기존 토큰으로 시도)
    }
  }
  
  let retries = 0;
  let lastError = null;
  
  while (retries <= maxRetries) {
    try {
      // 요청 전송
      const response = await fetchWithTimeout(url, options);
      
      // 응답 상태 확인
      if (response.status === 403) {
        consecutiveForbiddenCount++;
        
        // 연속 403 에러가 임계값을 초과하면 토큰 갱신
        if (consecutiveForbiddenCount >= MAX_FORBIDDEN_BEFORE_REFRESH) {
          console.warn(`[AUTH] 연속 ${MAX_FORBIDDEN_BEFORE_REFRESH}회 403 에러 발생, 토큰 강제 갱신`);
          
          try {
            const { csrfToken, xToken } = await refreshTokens();
            
            // 옵션에 새 토큰 적용
            if (options && options.headers) {
              options.headers["csrf-token"] = csrfToken;
              options.headers["x-token"] = xToken;
            }
          } catch (refreshErr) {
            console.error("[AUTH] 긴급 토큰 갱신 실패:", refreshErr);
          }
        }
        
        throw new Error(`HTTP error: ${response.status} Forbidden`);
      } else if (!response.ok) {
        // 403 외 다른 에러
        throw new Error(`HTTP error: ${response.status}`);
      }
      
      // 성공하면 연속 403 카운트 리셋
      consecutiveForbiddenCount = 0;
      return response;
    } catch (err) {
      lastError = err;
      retries++;
      
      // 서버 부하 방지를 위한 지수 백오프 대기
      if (err.message && err.message.includes("403")) {
        // 403 에러는 더 긴 대기 시간 적용 (서버 보호)
        console.warn(`[AUTH] Fetch 시도 ${retries}/${maxRetries + 1} 실패 (403 Forbidden):`, err);
        const delay = Math.min(5000 * Math.pow(2, retries - 1), 30000); // 최대 30초
        await new Promise(r => setTimeout(r, delay));
      } else {
        console.warn(`Fetch 시도 ${retries}/${maxRetries + 1} 실패:`, err);
        const delay = Math.min(1000 * Math.pow(2, retries - 1), 10000); // 최대 10초
        await new Promise(r => setTimeout(r, delay));
      }
      
      if (retries > maxRetries) {
        throw lastError;
      }
    }
  }
}

/**
 * 스로틀링 적용 함수 (한 번에 너무 많은 요청을 보내지 않도록)
 * @param {Function} fn 원본 함수
 * @param {number} limit 초당 최대 요청 수
 * @returns {Function} 스로틀링된 함수
 */
function throttleRequests(fn, limit = 5) {
  const queue = [];
  let inProgress = 0;
  let lastRequestTime = 0;
  
  // 큐에서 다음 요청 처리
  const processQueue = async () => {
    if (queue.length === 0 || inProgress >= limit) return;
    
    // 요청 간격 제어 (초당 limit개)
    const now = Date.now();
    const elapsed = now - lastRequestTime;
    const minInterval = 1000 / limit;
    
    if (elapsed < minInterval) {
      setTimeout(processQueue, minInterval - elapsed);
      return;
    }
    
    // 다음 요청 실행
    const next = queue.shift();
    inProgress++;
    lastRequestTime = Date.now();
    
    try {
      const result = await fn(...next.args);
      next.resolve(result);
    } catch (err) {
      next.reject(err);
    } finally {
      inProgress--;
      setTimeout(processQueue, 0);
    }
  };
  
  // 스로틀링된 함수 반환
  return (...args) => {
    return new Promise((resolve, reject) => {
      queue.push({ args, resolve, reject });
      processQueue();
    });
  };
}

// fetch 함수에 스로틀링 적용
const throttledFetch = throttleRequests(fetchWithRetry, 5); // 초당 최대 5개 요청

/**
 * 사용자 상호작용 우선순위 시스템 초기화 수정
 */
function initEnhancedUserInteractionSystem() {
  console.log("[개선된 우선순위 시스템] 초기화 중...");
  
  // 원본 함수 참조 보존
  if (!window.originalFetchCommentsThenExpand) {
    window.originalLikeDiscuss = likeDiscuss;
    window.originalUnlikeDiscuss = unlikeDiscuss;
    window.originalCreateComment = createComment;
    window.originalFetchCommentsThenExpand = fetchCommentsThenExpand;
    window.originalLoadMoreComments = loadMoreComments;
  }
  
  // 개선된 컨텍스트 인식 함수로 대체
  likeDiscuss = likeDiscussWithContext;
  unlikeDiscuss = unlikeDiscussWithContext;
  createComment = createCommentWithContext;
  fetchCommentsThenExpand = fetchCommentsThenExpandWithContext;
  loadMoreComments = loadMoreCommentsWithContext;
  
  // 이벤트 리스너 설정
  setupEnhancedInteractionListeners();
  
  // 초기 화면 상태 분석
  updateVisibleElements();
  
  // 저장된 요청 불러오기
  loadPendingRequestsFromStorage();
  
  // 패턴 관련 변수 초기화
  window.__likeUnlikePatterns = new Map();
  window.__commentLikePatterns = new Map();
  
  console.log("[개선된 우선순위 시스템] 초기화 완료");
  
  return {
    PRIORITY,
    USER_ACTION,
    userInteractionState,
    recordUserAction,
    updateVisibleElements,
    calculatePriorityForAction,
    stopLikeUnlikePattern,
    stopCommentLikePattern
  };
}

// 시스템 초기화 및 전역 객체로 노출
window.__prioritySystem = initEnhancedUserInteractionSystem();

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', () => {
  // 페이지 로드 이벤트 캡처
  console.log("[INIT] 페이지 로드됨, 우선순위 시스템 초기화");
  
  // 만약 이미 초기화되지 않았다면 초기화
  if (!window.__prioritySystem) {
    window.__prioritySystem = initEnhancedUserInteractionSystem();
  }
  
  // 페이지 로드 시 필요한 추가 작업
  // 맨 위 최신 글 자동 새로고침 설정 (1분 간격)
  setInterval(() => {
    // 사용자가 최상단에 있을 때만 새로고침
    if (userInteractionState.userAtTop && !processingRequest) {
      const priority = calculatePriorityForAction(USER_ACTION.REFRESH, { atTop: true });
      
      // 최신 글 새로고침 요청
      scheduleRequest(
        () => refreshLatestPosts(),
        priority,
        "RefreshLatestPosts",
        2,
        `refresh_latest_${Date.now()}`,
        USER_ACTION.REFRESH,
        { atTop: true }
      );
    }
  }, 60000); // 1분마다
});

// 페이지 언로드 시 정리 작업
window.addEventListener('beforeunload', () => {
  // 중요 요청 저장
  savePendingRequestsToStorage();
  
  // 모든 패턴 중단
  stopLikeUnlikePattern();
  stopCommentLikePattern();
  
  console.log("[CLEANUP] 페이지 언로드, 중요 요청 저장됨, 모든 패턴 중단");
});

// 최신 글 새로고침 함수 (가상 함수, 실제 구현은 필요에 따라 변경)
function refreshLatestPosts() {
  console.log("[REFRESH] 최신 글 새로고침 시도");
  // 실제 구현은 사이트의 API에 맞게 개발 필요
  return Promise.resolve();
}

// 글로벌 오류 핸들러 등록
window.addEventListener('error', (event) => {
  console.error("[ERROR] 글로벌 오류 발생:", event.error);
  
  // 심각한 오류 발생 시 시스템 상태 리셋
  if (processingRequest) {
    processingRequest = false;
    scheduleQueueProcessing(2000); // 2초 후 큐 처리 재개
  }
});

/**
 * 최신 게시물 불러오기 (가장 최신 페이지 로드)
 */
async function fetchLatestPosts() {
  try {
    // API URL 생성
    const apiUrl = `/api/discussions`;
    
    // 요청 옵션 설정
    const options = {
      method: "GET",
      credentials: "include",
      headers: { ...requestOptions.headers }
    };
    
    try {
      // 글 목록 가져오기
      const response = await throttledFetch(apiUrl, options);
      const data = await response.json();
      
      if (data.success && data.discussions) {
        // UI 업데이트 (DOM 조작)
        updatePostsUI(data.discussions);
      }
      
      return data;
    } catch (err) {
      console.error(`[POSTS] 최신 글 로드 실패`, err);
      throw err;
    }
  } catch (err) {
    console.error(`[POSTS] 최신 글 로드 중 오류`, err);
    throw err;
  }
}

/**
 * 게시물 UI 업데이트 함수
 * @param {Array} posts - 게시물 목록
 */
function updatePostsUI(posts) {
  try {
    // 게시물 목록 컨테이너 찾기
    const postContainer = document.querySelector("ul.css-1urx3um.e18x7bg03");
    if (!postContainer) return;
    
    // 현재 표시된 게시물 요소들 수집
    const existingPostElements = {};
    postContainer.querySelectorAll('li').forEach(li => {
      if (li.__itemData && li.__itemData.id) {
        existingPostElements[li.__itemData.id] = li;
      }
    });
    
    // 새 게시물 목록으로 UI 업데이트
    const fragment = document.createDocumentFragment();
    
    posts.forEach(post => {
      if (existingPostElements[post.id]) {
        // 기존 요소 재사용
        fragment.appendChild(existingPostElements[post.id]);
        delete existingPostElements[post.id];
      } else {
        // 새 요소 생성 (실제 구현은 사이트에 맞게 필요)
        // 여기에서는 단순화를 위해 생략
      }
    });
    
    // 컨테이너 비우고 새 요소로 채우기
    // 실제 구현에서는 이전 화면 상태를 유지하는 방법 필요
    // 예: 스크롤 위치, 확장된 댓글 섹션 등
  } catch (err) {
    console.error(`[UI] 게시물 UI 업데이트 중 오류`, err);
  }
}

/**
 * 새로운 글 더보기 기능
 */
function loadMorePostsWithContext() {
  // 사용자 액션 기록
  const priority = recordUserAction(USER_ACTION.POST_LOAD_MORE, { targetId: 'posts' });
  
  // 요청 스케줄링 (우선순위 적용)
  const requestId = `load_more_posts_${Date.now()}`;
  
  scheduleRequest(
    () => loadMorePosts(),
    priority,
    "PostsLoadMore",
    3,
    requestId,
    USER_ACTION.POST_LOAD_MORE,
    { targetId: 'posts' }
  );
}

/**
 * 더 많은 글 로드 함수 (원본 구현은 사이트 특성에 맞게 수정 필요)
 */
async function loadMorePosts() {
  // 기존 searchAfter 가져오기
  const lastSearchAfter = window.__loadedSearchAfters[window.__loadedSearchAfters.length - 1];
  
  try {
    // API URL 생성 (검색 파라미터 포함)
    let apiUrl = `/api/discussions?limit=20`;
    if (lastSearchAfter) {
      apiUrl += `&searchAfter=${encodeURIComponent(lastSearchAfter)}`;
    }
    
    // 요청 옵션 설정
    const options = {
      method: "GET",
      credentials: "include",
      headers: { ...requestOptions.headers }
    };
    
    // 글 목록 가져오기
    const response = await throttledFetch(apiUrl, options);
    const data = await response.json();
    
    if (data.success && data.discussions) {
      // 새 검색 커서 저장
      if (data.nextSearchAfter) {
        window.__loadedSearchAfters.push(data.nextSearchAfter);
      }
      
      // UI 업데이트 (DOM 조작) - 실제 구현은 사이트에 맞게 필요
      appendPostsToUI(data.discussions);
    }
    
    return data;
  } catch (err) {
    console.error(`[POSTS] 더 많은 글 로드 실패`, err);
    throw err;
  }
}

/**
 * UI에 추가 게시물 추가 함수
 * @param {Array} posts - 새 게시물 목록
 */
function appendPostsToUI(posts) {
  try {
    // 게시물 목록 컨테이너 찾기
    const postContainer = document.querySelector("ul.css-1urx3um.e18x7bg03");
    if (!postContainer) return;
    
    // 새 게시물 UI 요소 생성 (실제 구현은 사이트에 맞게 필요)
    const fragment = document.createDocumentFragment();
    
    posts.forEach(post => {
      // 여기에서는 단순화를 위해 생략
      // 실제 구현에서는 게시물 HTML 구조 생성 및 이벤트 리스너 추가 필요
    });
    
    // 컨테이너에 추가
    postContainer.appendChild(fragment);
    
    // 화면에 보이는 요소 업데이트
    updateVisibleElements();
  } catch (err) {
    console.error(`[UI] 게시물 추가 중 오류`, err);
  }
}

/**
 * lodash 유틸리티 간단 구현 (lodash가 없는 경우 대비)
 */
if (typeof _ === 'undefined') {
  console.log("[UTIL] lodash 없음, 기본 유틸리티 함수 구현");
  
  window._ = {
    throttle: function(func, wait) {
      let lastCall = 0;
      return function(...args) {
        const now = Date.now();
        if (now - lastCall >= wait) {
          lastCall = now;
          return func.apply(this, args);
        }
      };
    },
    debounce: function(func, wait) {
      let timeout;
      return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
      };
    }
  };
}

// 초기화 완료 메시지
console.log("[SYSTEM] 사용자 상호작용 우선순위 시스템 로드 완료. 버전: 1.0");