// background.js
chrome.runtime.onInstalled.addListener(() => {
    console.log("Entry Auto Backup Extension Installed.");
  });
  