// contentScript.js

// 기본 백업 주기(1분 = 60,000ms)
let backupInterval = 60 * 1000;
let autoSaveIntervalId = null;

// 실행 로그 확인용
console.log("[Entry Auto Backup] contentScript.js loaded");

// 최상위 프레임 / 현재 프레임에서 Entry 객체를 찾는 헬퍼 함수
function getEntry() {
  try {
    if (window.top && window.top.Entry) {
      return window.top.Entry; // 최상위 프레임에 Entry가 있으면 사용
    }
  } catch (e) {
    // cross-origin 에러 등 무시
  }
  return window.Entry; // 없다면 현재 프레임에서
}

/**
 * 스토리지에 저장된 백업 주기가 있으면 적용하고,
 * 없으면 기본값(1분)을 사용한다.
 */
function initAutoSave() {
  console.log("[Entry Auto Backup] initAutoSave() called");
  chrome.storage.local.get(["backupInterval"], (res) => {
    if (res.backupInterval) {
      backupInterval = Number(res.backupInterval);
      console.log("[Entry Auto Backup] Loaded stored backupInterval:", backupInterval);
    } else {
      console.log("[Entry Auto Backup] No stored backupInterval found, using default 60000ms");
    }
    startAutoSave();
  });
}

/**
 * 현재 설정된 백업 주기로 setInterval을 돌려
 * 주기적으로 프로젝트 데이터를 백업한다.
 */
function startAutoSave() {
  console.log("[Entry Auto Backup] startAutoSave() called");
  if (autoSaveIntervalId) {
    console.log("[Entry Auto Backup] Clearing existing interval:", autoSaveIntervalId);
    clearInterval(autoSaveIntervalId);
  }
  console.log("[Entry Auto Backup] Setting new interval with:", backupInterval, "ms");
  autoSaveIntervalId = setInterval(() => {
    saveProjectBackup();
  }, backupInterval);
  console.log("[Entry Auto Backup] autoSaveIntervalId set to:", autoSaveIntervalId);
}

/**
 * Entry.exportProject()를 통해 프로젝트 데이터를 추출,
 * projectId별로 local storage에 저장한다.
 */
function saveProjectBackup() {
  console.log("[Entry Auto Backup] saveProjectBackup() called");

  const entryObj = getEntry();
  if (!entryObj) {
    console.warn("[Entry Auto Backup] Entry is undefined, cannot exportProject().");
    return;
  }
  if (!entryObj.exportProject) {
    console.warn("[Entry Auto Backup] Entry.exportProject is not available, skipping backup.");
    return;
  }

  let projectId = entryObj.projectId;
  if (!projectId) {
    projectId = "unknown";
    console.log("[Entry Auto Backup] projectId not found, using 'unknown'");
  }

  try {
    console.log("[Entry Auto Backup] Attempting Entry.exportProject()...");
    const projectData = entryObj.exportProject();
    const timestamp = Date.now();
    console.log("[Entry Auto Backup] Successfully exported project data at:", new Date(timestamp).toLocaleString());

    chrome.storage.local.get(["entryBackups"], (result) => {
      console.log("[Entry Auto Backup] Fetched entryBackups from storage");
      let entryBackups = result.entryBackups || {};
      if (!entryBackups[projectId]) {
        entryBackups[projectId] = [];
        console.log(`[Entry Auto Backup] Creating new backup array for projectId=${projectId}`);
      }
      entryBackups[projectId].push({
        timestamp,
        data: projectData
      });
      chrome.storage.local.set({ entryBackups }, () => {
        console.log(`[Entry Auto Backup] Saved backup for ID=${projectId}, time=${new Date(timestamp).toLocaleString()}`);
      });
    });
  } catch (err) {
    console.error("[Entry Auto Backup] Failed to export project:", err);
  }
}

/**
 * popup 등에서 오는 메시지 처리
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[Entry Auto Backup] onMessage received:", message);

  const entryObj = getEntry();

  if (message.type === "GET_PROJECT_ID") {
    let pid = entryObj ? entryObj.projectId : null;
    console.log("[Entry Auto Backup] GET_PROJECT_ID => projectId:", pid);
    sendResponse({ projectId: pid ?? null });
    return true;

  } else if (message.type === "GET_BACKUPS_FOR_ID") {
    const pid = message.projectId || "unknown";
    console.log("[Entry Auto Backup] GET_BACKUPS_FOR_ID => projectId:", pid);
    chrome.storage.local.get(["entryBackups"], (res) => {
      let entryBackups = res.entryBackups || {};
      let backups = entryBackups[pid] || [];
      console.log(`[Entry Auto Backup] Fetched backups for projectId=${pid}, count=${backups.length}`);
      sendResponse({ backups });
    });
    return true;

  } else if (message.type === "GET_ALL_BACKUPS") {
    console.log("[Entry Auto Backup] GET_ALL_BACKUPS");
    chrome.storage.local.get(["entryBackups"], (res) => {
      let entryBackups = res.entryBackups || {};
      let all = [];
      Object.keys(entryBackups).forEach((id) => {
        entryBackups[id].forEach((b) => {
          all.push({
            projectId: id,
            timestamp: b.timestamp,
            data: b.data
          });
        });
      });
      all.sort((a, b) => a.timestamp - b.timestamp);
      console.log(`[Entry Auto Backup] Found total backups: ${all.length}`);
      sendResponse({ backups: all });
    });
    return true;

  } else if (message.type === "SET_BACKUP_INTERVAL") {
    backupInterval = message.interval;
    console.log("[Entry Auto Backup] SET_BACKUP_INTERVAL =>", backupInterval);
    chrome.storage.local.set({ backupInterval }, () => {
      startAutoSave();
      sendResponse({ success: true });
    });
    return true;

  } else if (message.type === "LOAD_BACKUP") {
    const { data } = message;
    console.log("[Entry Auto Backup] LOAD_BACKUP => Attempting load with data:", data);
    if (entryObj && entryObj.clearProject && entryObj.loadProject) {
      try {
        console.log("[Entry Auto Backup] Clearing current project...");
        entryObj.clearProject();
        console.log("[Entry Auto Backup] Loading project data...");
        entryObj.loadProject(data);
        console.log("[Entry Auto Backup] Successfully loaded backup data!");
        sendResponse({ success: true });
      } catch (err) {
        console.error("[Entry Auto Backup] Failed to load project:", err);
        sendResponse({ success: false, error: err.message });
      }
    } else {
      console.warn("[Entry Auto Backup] Entry is not ready or missing load functions.");
      sendResponse({ success: false, error: "Entry is not ready." });
    }
    return true;
  }
});

/**
 * 콘솔 명령어를 통한 수동 접근
 */
window.ProjectBackupExtension = {
  listAllBackups: function () {
    console.log("[Entry Auto Backup] listAllBackups() called");
    chrome.storage.local.get(["entryBackups"], (res) => {
      console.log("=== 전체 백업 목록 ===");
      console.log(res.entryBackups || {});
    });
  },
  loadBackup: function (projectId, index) {
    console.log("[Entry Auto Backup] loadBackup() called => projectId:", projectId, "index:", index);
    chrome.storage.local.get(["entryBackups"], (res) => {
      const entryBackups = res.entryBackups || {};
      const backups = entryBackups[projectId] || [];
      if (index >= 0 && index < backups.length) {
        try {
          console.log("[Entry Auto Backup] Clearing current project for loading backup...");
          const entryObj = getEntry();
          entryObj.clearProject();
          console.log("[Entry Auto Backup] Loading backup data for index:", index);
          entryObj.loadProject(backups[index].data);
          console.log(`백업 #${index} 로드 완료 (프로젝트ID: ${projectId})`);
        } catch (e) {
          console.error("[Entry Auto Backup] 프로젝트 로드 실패:", e);
        }
      } else {
        console.error("[Entry Auto Backup] 존재하지 않는 백업 index입니다.");
      }
    });
  }
};

// --------------------------
// 1) 기본 initAutoSave() (원래 코드)
// --------------------------
console.log("[Entry Auto Backup] Calling initAutoSave()...");
initAutoSave();

// --------------------------
// 2) [추가] Entry.projectId를 최대 10회, 3초 간격 확인
//    -> 잡히면 initAutoSave() 재호출
//    -> 안 잡히면 포기하고 그냥 unknown상태로 동작
// --------------------------
let waitForEntryIntervalCount = 0;
let waitForEntryInterval = setInterval(() => {
  waitForEntryIntervalCount++;
  const entryObj = getEntry();
  if (entryObj && entryObj.projectId) {
    console.log(`[Entry Auto Backup] Detected Entry.projectId='${entryObj.projectId}'. Re-calling initAutoSave() and stopping checks`);
    clearInterval(waitForEntryInterval);
    initAutoSave(); // projectId 감지된 시점에 재시작
  } else {
    console.log(`[Entry Auto Backup] [${waitForEntryIntervalCount}회] Still waiting for Entry.projectId...`);
    if (waitForEntryIntervalCount >= 10) {
      console.log("[Entry Auto Backup] Gave up waiting for Entry.projectId. Will proceed with 'unknown' ID if needed.");
      clearInterval(waitForEntryInterval);
    }
  }
}, 3000);
