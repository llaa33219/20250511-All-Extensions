// popup.js

document.addEventListener("DOMContentLoaded", function () {
    console.log("[Entry Auto Backup] popup.js => DOMContentLoaded");
    const projectIdSpan = document.getElementById("projectId");
    const backupList = document.getElementById("backupList");
    const intervalInput = document.getElementById("intervalInput");
    const saveIntervalBtn = document.getElementById("saveIntervalBtn");
    const showAllBtn = document.getElementById("showAllBtn");
    const allBackupsList = document.getElementById("allBackupsList");
  
    let currentProjectId = null;
  
    /**
     * 현재 탭(Entry 편집 페이지)의 projectId를 가져와 화면에 표시
     */
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      console.log("[Entry Auto Backup] popup.js => Requesting GET_PROJECT_ID from content script");
      chrome.tabs.sendMessage(tabs[0].id, { type: "GET_PROJECT_ID" }, function (response) {
        if (chrome.runtime.lastError) {
          console.error("[Entry Auto Backup] popup.js => chrome.runtime.lastError:", chrome.runtime.lastError.message);
          return;
        }
        console.log("[Entry Auto Backup] popup.js => GET_PROJECT_ID response:", response);
        currentProjectId = (response && response.projectId) || "unknown";
        projectIdSpan.textContent = currentProjectId;
        loadBackupsForCurrentProject();
      });
    });
  
    /**
     * 기존에 설정된 백업 주기를 스토리지에서 로드하여 표시
     */
    chrome.storage.local.get(["backupInterval"], (res) => {
      if (res.backupInterval) {
        intervalInput.value = res.backupInterval;
        console.log("[Entry Auto Backup] popup.js => Loaded backupInterval from storage:", res.backupInterval);
      } else {
        console.log("[Entry Auto Backup] popup.js => No stored backupInterval found, using default 60000");
      }
    });
  
    /**
     * [주기 설정] 버튼 클릭 시, interval값을 contentScript로 전달해 백업 주기 갱신
     */
    saveIntervalBtn.addEventListener("click", function () {
      console.log("[Entry Auto Backup] popup.js => [주기 설정] clicked");
      const val = parseInt(intervalInput.value, 10);
      if (isNaN(val) || val <= 0) {
        alert("올바른 밀리초(ms) 값을 입력하세요.");
        console.warn("[Entry Auto Backup] popup.js => Invalid interval input:", intervalInput.value);
        return;
      }
  
      console.log("[Entry Auto Backup] popup.js => Sending SET_BACKUP_INTERVAL =", val);
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { type: "SET_BACKUP_INTERVAL", interval: val },
          function (response) {
            if (chrome.runtime.lastError) {
              console.error("[Entry Auto Backup] popup.js => chrome.runtime.lastError:", chrome.runtime.lastError.message);
              return;
            }
            console.log("[Entry Auto Backup] popup.js => SET_BACKUP_INTERVAL response:", response);
            if (response && response.success) {
              alert("백업 주기가 저장되었습니다.");
            }
          }
        );
      });
    });
  
    /**
     * 이 프로젝트의 백업 목록을 불러와 리스트로 표시
     */
    function loadBackupsForCurrentProject() {
      console.log("[Entry Auto Backup] popup.js => loadBackupsForCurrentProject() => projectId:", currentProjectId);
      if (!currentProjectId) return;
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { type: "GET_BACKUPS_FOR_ID", projectId: currentProjectId },
          function (response) {
            if (chrome.runtime.lastError) {
              console.error("[Entry Auto Backup] popup.js => chrome.runtime.lastError:", chrome.runtime.lastError.message);
              return;
            }
            console.log("[Entry Auto Backup] popup.js => GET_BACKUPS_FOR_ID response:", response);
            const backups = (response && response.backups) || [];
            renderBackupList(backups, backupList, false);
          }
        );
      });
    }
  
    /**
     * 특정 백업 리스트를 컨테이너에 렌더링
     */
    function renderBackupList(backups, container, showProjectId) {
      console.log("[Entry Auto Backup] popup.js => renderBackupList(), showProjectId=", showProjectId, ", backups.length=", backups.length);
      container.innerHTML = "";
      backups.forEach((backup) => {
        const item = document.createElement("div");
        item.className = "backup-item";
  
        const dateString = new Date(backup.timestamp).toLocaleString();
        if (showProjectId && backup.projectId) {
          item.textContent = `[${backup.projectId}] ${dateString}`;
        } else {
          item.textContent = dateString;
        }
  
        item.addEventListener("click", () => {
          console.log("[Entry Auto Backup] popup.js => User clicked backup item => timestamp:", backup.timestamp);
          loadBackup(backup.data);
        });
  
        container.appendChild(item);
      });
    }
  
    /**
     * 백업 데이터(프로젝트) 로드
     */
    function loadBackup(data) {
      console.log("[Entry Auto Backup] popup.js => loadBackup() called");
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        console.log("[Entry Auto Backup] popup.js => Sending LOAD_BACKUP message to content script");
        chrome.tabs.sendMessage(
          tabs[0].id,
          { type: "LOAD_BACKUP", data },
          function (response) {
            if (chrome.runtime.lastError) {
              console.error("[Entry Auto Backup] popup.js => chrome.runtime.lastError:", chrome.runtime.lastError.message);
              return;
            }
            console.log("[Entry Auto Backup] popup.js => LOAD_BACKUP response:", response);
            if (!response || !response.success) {
              alert("백업 로드 실패: " + (response ? response.error : "알 수 없는 에러"));
            }
          }
        );
      });
    }
  
    /**
     * [전체 보기] 버튼 클릭 시
     */
    showAllBtn.addEventListener("click", () => {
      console.log("[Entry Auto Backup] popup.js => [전체 보기] clicked");
      if (allBackupsList.style.display === "none") {
        console.log("[Entry Auto Backup] popup.js => Requesting GET_ALL_BACKUPS from content script");
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { type: "GET_ALL_BACKUPS" },
            function (response) {
              if (chrome.runtime.lastError) {
                console.error("[Entry Auto Backup] popup.js => chrome.runtime.lastError:", chrome.runtime.lastError.message);
                return;
              }
              console.log("[Entry Auto Backup] popup.js => GET_ALL_BACKUPS response:", response);
              const backups = (response && response.backups) || [];
              renderBackupList(backups, allBackupsList, true);
              allBackupsList.style.display = "block";
            }
          );
        });
      } else {
        console.log("[Entry Auto Backup] popup.js => Hiding allBackupsList");
        allBackupsList.style.display = "none";
      }
    });
  });
  