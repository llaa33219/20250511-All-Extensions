
  // content.js
  // PlayEntry 마이너스 좋아요 기능 구현
  (function() {
    // URL에서 타겟 ID 추출하는 함수
    function extractTargetFromURL() {
      const url = window.location.href;
      const match = url.match(/https:\/\/playentry\.org\/community\/entrystory\/([a-zA-Z0-9]+)/);
      return match ? match[1] : null;
    }
    
    // 토큰을 저장할 변수
    let currentCsrfToken = "";
    let currentXToken = "";
    let lastTokenRefresh = 0;
    const TOKEN_REFRESH_INTERVAL = 60000; // 1분마다 토큰 갱신 시도
  
    // 토큰 갱신 함수
    async function refreshTokens() {
      console.log("[AUTH] 토큰 갱신 시도...");
      
      try {
        // 페이지 내용을 다시 로드하여 새 토큰 얻기
        const response = await fetch(location.href, {
          method: "GET",
          credentials: "include",
          cache: "no-store",
          redirect: "follow"
        });
        
        if (!response.ok) {
          throw new Error(`페이지 로드 실패: ${response.status}`);
        }
        
        const html = await response.text();
        
        // HTML에서 CSRF 토큰 추출
        let csrfToken = "";
        const csrfMatch = html.match(/<meta\s+name="csrf-token"\s+content="([^"]+)"/i);
        if (csrfMatch && csrfMatch[1]) {
          csrfToken = csrfMatch[1];
        }
        
        // HTML에서 xToken 추출 (NEXT_DATA에서)
        let xToken = "";
        const nextDataMatch = html.match(/<script\s+id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i);
        if (nextDataMatch && nextDataMatch[1]) {
          try {
            const nextData = JSON.parse(nextDataMatch[1]);
            xToken = nextData?.props?.initialState?.common?.user?.xToken || "";
          } catch (e) {
            console.warn("[AUTH] NEXT_DATA JSON 파싱 실패:", e);
          }
        }
        
        if (!csrfToken || !xToken) {
          throw new Error("토큰 추출 실패");
        }
        
        console.log("[AUTH] 토큰 갱신 성공");
        lastTokenRefresh = Date.now();
        
        // 토큰 저장
        currentCsrfToken = csrfToken;
        currentXToken = xToken;
        
        return { csrfToken, xToken };
      } catch (err) {
        console.error("[AUTH] 토큰 갱신 실패:", err);
        throw err;
      }
    }
    
    // CSRF 토큰 추출 함수
    function getCSRFToken() {
      // 캐시된 토큰이 있으면 사용
      if (currentCsrfToken) return currentCsrfToken;
      
      // HTML에서 토큰 추출 시도
      const metaToken = document.querySelector('meta[name="csrf-token"]');
      if (metaToken) {
        currentCsrfToken = metaToken.getAttribute('content');
        return currentCsrfToken;
      }
      
      // NEXT_DATA에서 추출 시도
      const nextDataScript = document.getElementById('__NEXT_DATA__');
      if (nextDataScript) {
        try {
          const nextData = JSON.parse(nextDataScript.textContent);
          if (nextData?.props?.initialProps?.csrfToken) {
            currentCsrfToken = nextData.props.initialProps.csrfToken;
            return currentCsrfToken;
          }
        } catch (e) {
          console.warn("NEXT_DATA 파싱 실패:", e);
        }
      }
      
      console.warn('CSRF 토큰을 찾을 수 없습니다. 페이지 토큰 갱신 필요');
      return '';
    }
    
    // x-token 추출 함수
    function getXToken() {
      // 캐시된 토큰이 있으면 사용
      if (currentXToken) return currentXToken;
      
      // NEXT_DATA에서 추출 시도
      const nextDataScript = document.getElementById('__NEXT_DATA__');
      if (nextDataScript) {
        try {
          const nextData = JSON.parse(nextDataScript.textContent);
          const xToken = nextData?.props?.initialState?.common?.user?.xToken;
          if (xToken) {
            currentXToken = xToken;
            return currentXToken;
          }
        } catch (e) {
          console.warn("NEXT_DATA 파싱 실패:", e);
        }
      }
      
      console.warn('x-token을 찾을 수 없습니다. 페이지 토큰 갱신 필요');
      return '';
    }
  
    // LIKE 요청 보내기
    async function sendLikeRequest(target) {
      try {
        // 토큰 가져오기
        const csrfToken = getCSRFToken();
        const xToken = getXToken();
        
        // 토큰이 없으면 갱신 시도
        if (!csrfToken || !xToken) {
          await refreshTokens();
        }
        
        // 요청 본문 - 객체로 구성
        const body = {
          query: `
            mutation LIKE($target: String, $targetSubject: String, $targetType: String, $groupId: ID) {
              like(target: $target, targetSubject: $targetSubject, targetType: $targetType, groupId: $groupId) {
                target
                targetSubject
                targetType
              }
            }
          `,
          variables: {
            target: target,
            targetSubject: "discuss"
          }
        };
        
        await fetch("https://playentry.org/graphql/LIKE", {
          "headers": {
            "accept": "*/*",
            "accept-language": "ja,en-US;q=0.9,en;q=0.8,ko;q=0.7",
            "content-type": "application/json",
            "csrf-token": csrfToken,
            "priority": "u=1, i",
            "sec-ch-ua": "\"Chromium\";v=\"136\", \"Google Chrome\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-client-type": "Client",
            "x-token": xToken
          },
          "referrer": window.location.href,
          "referrerPolicy": "strict-origin-when-cross-origin",
          "body": JSON.stringify(body),
          "method": "POST",
          "mode": "cors",
          "credentials": "include"
        });
        console.log('좋아요 요청 완료');
      } catch (error) {
        console.error('좋아요 요청 실패:', error);
      }
    }
  
    // UNLIKE 요청 보내기
    async function sendUnlikeRequest(target) {
      try {
        // 토큰 가져오기
        const csrfToken = getCSRFToken();
        const xToken = getXToken();
        
        // 토큰이 없으면 갱신 시도
        if (!csrfToken || !xToken) {
          await refreshTokens();
        }
        
        // 요청 본문 수정 - targetSubject 빠진 부분 추가
        const body = {
          query: `
            mutation UNLIKE($target: String, $targetSubject: String, $groupId: ID) {
              unlike(target: $target, targetSubject: $targetSubject, groupId: $groupId) {
                target
                targetSubject
                targetType
              }
            }
          `,
          variables: {
            target: target,
            targetSubject: "discuss"
          }
        };
        
        await fetch("https://playentry.org/graphql/UNLIKE", {
          "headers": {
            "accept": "*/*",
            "accept-language": "ja,en-US;q=0.9,en;q=0.8,ko;q=0.7",
            "content-type": "application/json",
            "csrf-token": csrfToken,
            "priority": "u=1, i",
            "sec-ch-ua": "\"Chromium\";v=\"136\", \"Google Chrome\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-client-type": "Client",
            "x-token": xToken
          },
          "referrer": window.location.href,
          "referrerPolicy": "strict-origin-when-cross-origin",
          "body": JSON.stringify(body),
          "method": "POST",
          "mode": "cors",
          "credentials": "include"
        });
      } catch (error) {
        console.error('좋아요 취소 요청 실패:', error);
      }
    }
  
    // 마이너스 좋아요 시퀀스 실행 (좋아요 1번 + 취소 20번 반복)
    async function performMinusLikeSequence(target, button) {
      // 버튼 상태를 활성화 상태로 변경
      button.textContent = "중지";
      button.style.backgroundColor = "#ff4444";
      button.dataset.active = "true";
  
      // 중지 플래그 초기화
      button.stopRequested = false;
  
      // 메인 루프
      while (!button.stopRequested) {
        // 좋아요 요청 1번 보내기
        await sendLikeRequest(target);
        
        // 좋아요 취소 요청 10번 즉시 보내기 (딜레이 없이)
        for (let i = 0; i < 10 && !button.stopRequested; i++) {
          await sendUnlikeRequest(target);
        }
        
        // 1초 대기 후 반복
        if (!button.stopRequested) {
          await new Promise(resolve => {
            button.timeoutId = setTimeout(() => {
              button.timeoutId = null;
              resolve();
            }, 1000);
          });
        }
      }
  
      // 중지되면 버튼 상태 초기화
      button.textContent = "마이너스 좋아요";
      button.style.backgroundColor = "#5555dd";
      button.dataset.active = "false";
    }
  
    // 마이너스 좋아요 버튼 추가
    function addMinusLikeButton() {
      // URL에서 타겟 ID 가져오기
      const target = extractTargetFromURL();
      if (!target) return;
  
      // 좋아요 버튼 찾기
      const likeButtons = document.querySelectorAll('em > a.like');
      
      likeButtons.forEach(likeButton => {
        // 이미 버튼이 추가되어 있는지 확인
        const nextElement = likeButton.nextElementSibling;
        if (nextElement && nextElement.classList.contains('minus-like-btn')) {
          return;
        }
        
        // 마이너스 좋아요 버튼 생성
        const minusLikeButton = document.createElement('a');
        minusLikeButton.className = 'minus-like-btn';
        minusLikeButton.role = 'button';
        minusLikeButton.textContent = '마이너스 좋아요';
        minusLikeButton.style.marginLeft = '10px';
        minusLikeButton.style.padding = '4px 10px';
        minusLikeButton.style.backgroundColor = '#5555dd';
        minusLikeButton.style.color = 'white';
        minusLikeButton.style.borderRadius = '4px';
        minusLikeButton.style.cursor = 'pointer';
        minusLikeButton.style.display = 'inline-block';
        minusLikeButton.dataset.active = 'false';
        
        // 클릭 이벤트 리스너 추가
        minusLikeButton.addEventListener('click', function() {
          if (this.dataset.active === 'true') {
            // 활성화 상태면 중지
            this.stopRequested = true;
            if (this.timeoutId) {
              clearTimeout(this.timeoutId);
              this.timeoutId = null;
            }
          } else {
            // 비활성화 상태면 시작
            performMinusLikeSequence(target, this);
          }
        });
        
        // 좋아요 버튼 다음에 삽입
        likeButton.parentNode.insertBefore(minusLikeButton, likeButton.nextSibling);
      });
    }
  
    // 페이지 로드 완료 시 실행
    function initialize() {
      // 초기 토큰 가져오기 (페이지 로드 시 즉시 갱신)
      refreshTokens().then(() => {
        console.log('토큰을 성공적으로 가져왔습니다.');
        
        // 초기 버튼 추가
        addMinusLikeButton();
      }).catch(err => {
        console.warn('초기 토큰 로드 실패, 로그인이 필요할 수 있습니다:', err);
        
        // 토큰 없이도 버튼 추가 시도
        addMinusLikeButton();
      });
      
      // 동적으로 추가되는 요소 감시
      const observer = new MutationObserver(() => {
        addMinusLikeButton();
      });
      
      observer.observe(document.body, { childList: true, subtree: true });
      
      // 정기적 토큰 갱신 (60초마다)
      setInterval(() => {
        refreshTokens().catch(err => {
          console.warn('정기 토큰 갱신 실패:', err);
        });
      }, TOKEN_REFRESH_INTERVAL);
      
      console.log('PlayEntry 마이너스 좋아요 확장 프로그램이 활성화되었습니다.');
    }
  
    // 페이지가 완전히 로드된 후 초기화
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initialize);
    } else {
      initialize();
    }
  })();