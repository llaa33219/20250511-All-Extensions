// 실행 버튼 생성 함수
function createRunButton() {
  const runButton = document.createElement('button');
  runButton.textContent = '▶ 실행';
  runButton.className = 'code-run-button';
  runButton.style.cssText = `
    position: absolute;
    right: 70px;
    top: 5px;
    padding: 2px 8px;
    background: #2196F3;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    z-index: 1000;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
  `;
  
  runButton.addEventListener('mouseover', () => {
    runButton.style.background = '#1976D2';
  });
  
  runButton.addEventListener('mouseout', () => {
    runButton.style.background = '#2196F3';
  });
  
  return runButton;
}

// 코드 블록 감지 및 버튼 추가
function injectRunButtons() {
  const codeContainers = document.querySelectorAll('div[class*="overflow-y-auto"]');
  
  codeContainers.forEach(container => {
    const codeBlock = container.querySelector('code');
    if (!codeBlock || container.querySelector('.code-run-button')) return;
    
    const runButton = createRunButton();
    container.parentElement.style.position = 'relative';
    container.parentElement.appendChild(runButton);
    
    runButton.addEventListener('click', (e) => {
      e.stopPropagation();
      const code = codeBlock.textContent;
      const language = [...codeBlock.classList]
        .find(c => c.startsWith('language-'))
        ?.replace('language-', '') || 'plaintext';
      
      chrome.runtime.sendMessage({
        action: 'executeCode',
        code: code,
        language: language.toLowerCase()
      });
    });
  });
}

// 초기 주입
injectRunButtons();

// 동적 콘텐츠 감지
new MutationObserver((mutations) => {
  mutations.forEach(() => injectRunButtons());
}).observe(document.body, {
  childList: true,
  subtree: true,
  attributes: false,
  characterData: false
});