document.addEventListener('DOMContentLoaded', async () => {
    const { lastExecution } = await chrome.storage.local.get('lastExecution');
    const outputDiv = document.getElementById('output');
    const previewFrame = document.getElementById('preview');
    const closeBtn = document.querySelector('.close-btn');
  
    // 닫기 버튼 이벤트
    closeBtn.addEventListener('click', () => {
      window.close();
    });
  
    // 출력 초기화
    function clearOutput() {
      outputDiv.innerHTML = '';
      previewFrame.srcdoc = '';
    }
  
    // 실행 핸들러
    const executors = {
      html: (code) => {
        previewFrame.srcdoc = code;
        outputDiv.innerHTML = '<div class="success">✅ HTML Preview Loaded</div>';
      },
  
      javascript: (code) => {
        try {
          const result = Function('"use strict";' + code)();
          outputDiv.innerHTML = `
            <div class="success">✔️ Execution Successful</div>
            <pre>${JSON.stringify(result, null, 2)}</pre>
          `;
        } catch (e) {
          outputDiv.innerHTML = `
            <div class="error">❌ JavaScript Error</div>
            <pre>${e.stack}</pre>
          `;
        }
      },
  
      python: (code) => {
        Sk.configure({
          output: (text) => outputDiv.innerHTML += text,
          read: (x) => {
            if (Sk.builtinFiles?.files?.[x]) return Sk.builtinFiles.files[x];
            throw `File not found: '${x}'`;
          },
          __future__: Sk.python3
        });
  
        outputDiv.innerHTML = '<div class="info">🐍 Executing Python...</div>';
        
        Sk.misceval.asyncToPromise(() => 
          Sk.importMainWithBody("<stdin>", false, code, true)
        ).then(() => {
          outputDiv.innerHTML += '<div class="success">✅ Python Execution Completed</div>';
        }).catch(e => {
          outputDiv.innerHTML += `
            <div class="error">❌ Python Error</div>
            <pre>${e.toString()}</pre>
          `;
        });
      }
    };
  
    // 초기 실행
    if (lastExecution) {
      clearOutput();
      const executor = executors[lastExecution.language] || executors.plaintext;
      executor(lastExecution.code);
    }
  });