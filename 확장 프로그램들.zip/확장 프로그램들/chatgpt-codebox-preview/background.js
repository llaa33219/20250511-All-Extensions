chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'executeCode') {
      chrome.storage.local.set({
        lastExecution: {
          code: request.code,
          language: request.language,
          timestamp: Date.now()
        }
      });
      chrome.action.setPopup({ popup: 'popup/popup.html' });
    }
    return true;
  });