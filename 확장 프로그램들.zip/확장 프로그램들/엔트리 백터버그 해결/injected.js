(function() {
  // XHR 오버라이드
  const originalXHROpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url) {
      if (url.includes('/ws/')) {
          this.addEventListener('load', function() {
              if ((this.responseType === '' || this.responseType === 'text') && this.responseText) {
                  const modified = this.responseText.replace(/ns1:href/gi, 'xlink:href');
                  Object.defineProperty(this, 'responseText', { value: modified });
              }
          });
      }
      originalXHROpen.apply(this, arguments);
  };

  // Fetch 오버라이드
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
      const response = await originalFetch.apply(this, args);
      if (response.url.includes('/ws/') && response.headers.get('content-type')?.includes('svg')) {
          const text = await response.text();
          const modified = text.replace(/ns1:href/gi, 'xlink:href');
          return new Response(modified, response);
      }
      return response;
  };
})();