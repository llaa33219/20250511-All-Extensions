/***********************************************************
 * 1) ns1 → xlink 변환 함수
 *    (DOM 내 모든 요소 및 자식 요소를 재귀적으로 검사)
 ***********************************************************/
function convertNs1Attributes(node) {
    if (node.nodeType === Node.ELEMENT_NODE) {
      // xmlns:ns1 → xmlns:xlink 변환
      if (node.hasAttribute("xmlns:ns1")) {
        const ns1Value = node.getAttribute("xmlns:ns1");
        node.removeAttribute("xmlns:ns1");
        node.setAttribute("xmlns:xlink", ns1Value);
      }
  
      // ns1: 접두어를 xlink:로 변환
      if (node.hasAttributes()) {
        const toRemove = [];
        const toAdd = [];
        for (let i = 0; i < node.attributes.length; i++) {
          const attr = node.attributes[i];
          if (attr.name.startsWith("ns1:")) {
            const newName = "xlink:" + attr.name.substring(4);
            toAdd.push({ name: newName, value: attr.value });
            toRemove.push(attr.name);
          }
        }
        toRemove.forEach(name => node.removeAttribute(name));
        toAdd.forEach(attr => node.setAttribute(attr.name, attr.value));
      }
    }
  
    // 자식 노드에 대해서도 재귀적으로 처리
    node.childNodes.forEach(child => convertNs1Attributes(child));
  }
  
  /***********************************************************
   * 2) 페이지 최초 로드 시 DOM 전체 변환
   ***********************************************************/
  convertNs1Attributes(document.documentElement);
  
  /***********************************************************
   * 3) MutationObserver 설정
   *    - 새로 추가되거나 속성이 변하는 노드도 변환 처리
   ***********************************************************/
  const observer = new MutationObserver(mutationsList => {
    for (const mutation of mutationsList) {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(node => {
          convertNs1Attributes(node);
          // 추가된 노드 중 <img> / <object> / <embed> 등 svg가 포함된 것 있으면 교정 시도
          checkAndReplaceSvgResource(node);
        });
      } else if (mutation.type === 'attributes') {
        convertNs1Attributes(mutation.target);
        // 속성이 변한 노드가 <img> / <object> / <embed> 등일 수도 있으므로 검사
        checkAndReplaceSvgResource(mutation.target);
      }
    }
  });
  
  observer.observe(document.documentElement, {
    attributes: true,
    childList: true,
    subtree: true
  });
  
  /***********************************************************
   * 4) SVG 로드 실패 횟수 계산
   ***********************************************************/
  let svgLoadFailureCount = 0;
  document.addEventListener('error', event => {
    const target = event.target;
    // IMG, OBJECT, EMBED 태그에서 발생한 에러를 대상으로 하며
    // src 또는 data에 ".svg"가 포함된 경우로 판단
    if (target && (target.tagName === 'IMG' || target.tagName === 'OBJECT' || target.tagName === 'EMBED')) {
      const src = target.src || target.data || "";
      if (src.includes(".svg")) {
        svgLoadFailureCount++;
        console.warn("SVG load failed for element:", target, "Total failures:", svgLoadFailureCount);
      }
    }
  }, true);
  
  /***********************************************************
   * 5) ns1 → xlink 치환 함수 (문자열 기반)
   *    - 실제 SVG 텍스트에서 ns1 / xmlns:ns1 등을 xlink로 교체
   ***********************************************************/
  function replaceNs1InSvgText(svgText) {
    // xmlns:ns1="http://www.w3.org/1999/xlink" → xmlns:xlink="http://www.w3.org/1999/xlink"
    let replaced = svgText.replace(
      /xmlns:ns1="http:\/\/www\.w3\.org\/1999\/xlink"/g,
      'xmlns:xlink="http://www.w3.org/1999/xlink"'
    );
    // ns1: → xlink:
    replaced = replaced.replace(/ns1:/g, 'xlink:');
    return replaced;
  }
  
  /***********************************************************
   * 6) <img> / <object> / <embed> 등에서 .svg가 깨진 경우
   *    - 직접 fetch 후 ns1 → xlink 치환, data URL로 대체
   *    - 로드가 성공하든 실패하든, 새로 교체 시도
   ***********************************************************/
  function replaceSvgResource(element) {
    let url = "";
    const tag = element.tagName.toUpperCase();
    if (tag === 'IMG') {
      url = element.src;
    } else if (tag === 'OBJECT' || tag === 'EMBED') {
      url = element.data;
    } else {
      return; // 처리 대상 아님
    }
  
    // .svg 문자열이 들어있지 않으면 패스
    if (!url || !url.includes(".svg")) return;
  
    // 이미 data:image/svg+xml;base64 형태로 교체한 경우 재실행 방지
    if (url.startsWith("data:image/svg+xml;base64,")) return;
  
    // fetch 시도
    fetch(url)
      .then(resp => {
        if (!resp.ok) {
          // 실패 시 카운트 증가
          svgLoadFailureCount++;
          console.warn("SVG load failed for element:", element, "Total failures:", svgLoadFailureCount);
          throw new Error("SVG fetch failed: " + resp.status);
        }
        return resp.text();
      })
      .then(svgText => {
        // ns1 → xlink 문자열 변환
        const replacedText = replaceNs1InSvgText(svgText);
        // base64 인코딩
        const base64Data = btoa(replacedText);
        const dataUrl = "data:image/svg+xml;base64," + base64Data;
  
        // <img>면 src로, <object>/<embed>면 data로 설정
        if (tag === 'IMG') {
          element.src = dataUrl;
        } else {
          element.data = dataUrl;
        }
      })
      .catch(err => {
        console.error("Failed to replace SVG resource:", err);
      });
  }
  
  /***********************************************************
   * 7) 특정 노드(및 자식 노드) 안에 포함된
   *    <img> / <object> / <embed> 엘리먼트를 찾아 replaceSvgResource 실행
   ***********************************************************/
  function checkAndReplaceSvgResource(node) {
    // 자기 자신이 대상 태그라면 먼저 처리
    if (node.tagName === 'IMG' || node.tagName === 'OBJECT' || node.tagName === 'EMBED') {
      replaceSvgResource(node);
    }
    // 자식 노드 중에서도 대상 태그를 찾음
    const imgs = node.querySelectorAll?.('img, object, embed') || [];
    imgs.forEach(el => replaceSvgResource(el));
  }
  
  /***********************************************************
   * 8) 페이지 로드 직후, 기존 DOM에 있는
   *    <img> / <object> / <embed> 요소들에 대해 교정 시도
   ***********************************************************/
  checkAndReplaceSvgResource(document.documentElement);
  