chrome.webRequest.onBeforeRequest.addListener(
    function(details) {
      return {cancel: true}; // 요청을 차단합니다.
    },
    {urls: ["*://*.example.com/*", "*://*.naver.me/*", "*://playentry.org/uploads/*"]}, // URL 패턴을 올바르게 수정
    ["blocking"]
  );
  