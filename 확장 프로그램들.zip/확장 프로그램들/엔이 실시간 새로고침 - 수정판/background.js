// 백그라운드 스크립트 (background.js)
// 사용자에게 보이지 않게 댓글을 작성하는 기능을 구현합니다.

// 오프스크린 문서 생성을 위한 전역 Promise
let creating;

// 오프스크린 문서 설정 함수
async function setupOffscreenDocument(path) {
  // 이미 존재하는 오프스크린 문서 확인
  const offscreenUrl = chrome.runtime.getURL(path);
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });

  if (existingContexts.length > 0) {
    return;
  }

  // 오프스크린 문서 생성
  if (creating) {
    await creating;
  } else {
    creating = chrome.offscreen.createDocument({
      url: path,
      reasons: ['DOM_PARSER'],
      justification: '사용자 상호작용 시뮬레이션을 위한 DOM 접근이 필요합니다.'
    });
    await creating;
    creating = null;
  }
}

// 오프스크린 문서 닫기 함수
async function closeOffscreenDocument() {
  try {
    await chrome.offscreen.closeDocument();
    console.log('오프스크린 문서가 닫혔습니다.');
  } catch (error) {
    console.error('오프스크린 문서 닫기 오류:', error);
  }
}

// 댓글 작성 요청 처리 함수
async function postComment(postId, commentText) {
  console.log(`게시글 ID: ${postId}, 댓글 내용: ${commentText} 작성 시작`);
  
  // 오프스크린 문서 설정
  await setupOffscreenDocument('offscreen.html');
  
  // 오프스크린 문서에 메시지 전송
  chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'post-comment',
    data: {
      postId: postId,
      commentText: commentText
    }
  });
}

// 메시지 리스너 설정
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'background') {
    // 오프스크린 문서로부터의 메시지 처리
    if (message.type === 'comment-result') {
      console.log('댓글 작성 결과:', message.data);
      
      // 작업 완료 후 오프스크린 문서 닫기
      if (message.data.status === 'success' || message.data.status === 'error') {
        closeOffscreenDocument();
      }
      
      // 결과를 콘텐츠 스크립트에 전달
      chrome.tabs.sendMessage(sender.tab.id, {
        type: 'comment-posted',
        data: message.data
      });
    }
    
    // 콘텐츠 스크립트로부터의 댓글 작성 요청 처리
    if (message.type === 'request-post-comment') {
      postComment(message.data.postId, message.data.commentText);
      sendResponse({ status: 'processing' });
      return true; // 비동기 응답을 위해 true 반환
    }
  }
});

// 확장 프로그램 아이콘 클릭 이벤트 처리 (테스트용)
chrome.action.onClicked.addListener(async (tab) => {
  console.log('확장 프로그램 아이콘이 클릭되었습니다.');
  // 현재 탭에 메시지 전송
  chrome.tabs.sendMessage(tab.id, {
    type: 'icon-clicked'
  });
});
