# Entry 스텔스 댓글 작성기 구현 문서

## 개요
이 확장 프로그램은 PlayEntry 사이트에서 사용자에게 보이지 않게 댓글을 작성하는 기능을 제공합니다. Chrome의 Offscreen API를 활용하여 백그라운드에서 페이지를 열고, 댓글 버튼 클릭, 텍스트 입력, 등록 버튼 클릭 등의 과정을 자동화합니다.

## 주요 기능
1. 백그라운드에서 게시글 페이지 열기
2. 댓글 버튼 자동 클릭
3. 사용자가 지정한 텍스트 자동 입력
4. 등록 버튼 자동 클릭
5. 모든 과정이 사용자에게 보이지 않게 처리

## 구현 방식
### 1. Chrome의 Offscreen API 활용
- 사용자 경험을 방해하지 않고 숨겨진 문서에서 DOM API 사용
- 새 탭이나 창을 열지 않고 백그라운드에서 작업 수행

### 2. iframe을 통한 페이지 로드
- 화면 밖에 위치시켜 사용자에게 보이지 않게 함
- 투명도, 포인터 이벤트, 접근성 속성 등을 조작하여 완전히 숨김

### 3. 프로그래밍 방식의 이벤트 발생
- 실제 사용자 상호작용 대신 프로그래밍 방식으로 이벤트 발생
- MouseEvent, Event 객체를 생성하여 클릭, 입력 등의 동작 시뮬레이션

### 4. 사용자 감지 회피 기술
- iframe을 화면 밖으로 위치시키고 투명하게 설정
- 마우스 이벤트 무시 및 키보드 탐색에서 제외
- 페이지 가시성 API 조작 및 포커스 이벤트 방지

## 파일 구조
1. **manifest.json**: 확장 프로그램 기본 설정
2. **background.js**: 백그라운드 스크립트, 오프스크린 문서 관리
3. **offscreen.html**: 오프스크린 문서 HTML
4. **offscreen.js**: 오프스크린 문서 스크립트, 댓글 작성 로직
5. **contentScript.js**: 콘텐츠 스크립트, 사용자 인터페이스 제공

## 사용 방법
1. 확장 프로그램 설치
2. PlayEntry 사이트의 게시글 페이지 방문
3. 페이지 우측 하단의 '빠른 댓글' 버튼 클릭
4. 댓글 내용 입력 후 '등록' 버튼 클릭
5. 백그라운드에서 자동으로 댓글 작성 진행

## 기술적 세부 사항
### Offscreen API 설정
```javascript
chrome.offscreen.createDocument({
  url: path,
  reasons: ['DOM_PARSER'],
  justification: '사용자 상호작용 시뮬레이션을 위한 DOM 접근이 필요합니다.'
});
```

### iframe 숨김 처리
```javascript
iframe.style.position = 'absolute';
iframe.style.left = '-9999px';
iframe.style.top = '-9999px';
iframe.style.opacity = '0';
iframe.style.pointerEvents = 'none';
iframe.setAttribute('aria-hidden', 'true');
iframe.setAttribute('tabindex', '-1');
```

### 이벤트 시뮬레이션
```javascript
const clickEvent = new MouseEvent('click', {
  bubbles: true,
  cancelable: true,
  view: iframe.contentWindow
});
element.dispatchEvent(clickEvent);
```

## 주의사항
- 이 확장 프로그램은 사용자가 직접 댓글을 작성한 것처럼 보이게 하기 위한 목적으로 개발되었습니다.
- 실제 사용 시 웹사이트의 이용약관 및 정책을 준수해야 합니다.
- 악의적인 목적으로 사용하지 않도록 주의해야 합니다.
