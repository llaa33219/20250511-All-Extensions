// 통합 문서: 기존 contentScript.js에 추가할 코드
// 이 코드는 기존 contentScript.js 파일의 맨 아래에 추가해야 합니다.

// 오프스크린 문서 생성을 위한 전역 Promise
let creating;

// 오프스크린 문서 설정 함수
async function setupOffscreenDocument(path) {
  // 이미 존재하는 오프스크린 문서 확인
  try {
    if ('getContexts' in chrome.runtime) {
      const offscreenUrl = chrome.runtime.getURL(path);
      const existingContexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [offscreenUrl]
      });

      if (existingContexts.length > 0) {
        console.log('[Entry Extension] 이미 오프스크린 문서가 존재합니다.');
        return;
      }
    } else {
      // Chrome 116 이전 버전 지원
      const matchedClients = await clients.matchAll();
      const hasOffscreen = matchedClients.some(client => {
        return client.url.includes(chrome.runtime.id) && client.url.includes(path);
      });
      
      if (hasOffscreen) {
        console.log('[Entry Extension] 이미 오프스크린 문서가 존재합니다.');
        return;
      }
    }
  } catch (error) {
    console.error('[Entry Extension] 오프스크린 문서 확인 중 오류:', error);
  }

  // 오프스크린 문서 생성
  try {
    if (creating) {
      await creating;
    } else {
      console.log('[Entry Extension] 오프스크린 문서 생성 시작');
      creating = chrome.offscreen.createDocument({
        url: path,
        reasons: ['DOM_PARSER'],
        justification: '사용자 상호작용 시뮬레이션을 위한 DOM 접근이 필요합니다.'
      });
      await creating;
      creating = null;
      console.log('[Entry Extension] 오프스크린 문서 생성 완료');
    }
  } catch (error) {
    console.error('[Entry Extension] 오프스크린 문서 생성 중 오류:', error);
    creating = null;
  }
}

// 오프스크린 문서 닫기 함수
async function closeOffscreenDocument() {
  try {
    await chrome.offscreen.closeDocument();
    console.log('[Entry Extension] 오프스크린 문서가 닫혔습니다.');
  } catch (error) {
    console.error('[Entry Extension] 오프스크린 문서 닫기 오류:', error);
  }
}

// 스텔스 댓글 작성 함수 (기존 createComment 함수를 대체하지 않고 새로 추가)
async function createStealthComment(discussId, content, stickerId = null) {
  console.log(`[Entry Extension] 스텔스 댓글 작성 시작: ${discussId}, ${content}`);
  
  try {
    // 오프스크린 문서 설정
    await setupOffscreenDocument('offscreen.html');
    
    // 오프스크린 문서에 메시지 전송
    chrome.runtime.sendMessage({
      target: 'offscreen',
      type: 'post-comment',
      data: {
        postId: discussId,
        commentText: content,
        stickerId: stickerId
      }
    });
    
    return true;
  } catch (error) {
    console.error('[Entry Extension] 스텔스 댓글 작성 중 오류:', error);
    return false;
  }
}

// 메시지 리스너 설정 (오프스크린 문서로부터의 메시지 처리)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'content') {
    if (message.type === 'comment-result') {
      handleCommentResult(message.data);
    }
  }
});

// 댓글 작성 결과 처리 함수
function handleCommentResult(data) {
  console.log('[Entry Extension] 댓글 작성 결과:', data);
  
  // 작업 완료 후 오프스크린 문서 닫기
  if (data.status === 'success' || data.status === 'error') {
    closeOffscreenDocument();
  }
  
  // 결과에 따른 알림 표시
  if (data.status === 'success') {
    showNotification('댓글이 성공적으로 작성되었습니다.', false);
  } else {
    showNotification(`댓글 작성 실패: ${data.message}`, true);
  }
}

// 알림 표시 함수
function showNotification(message, isError = false) {
  // 이미 존재하는 알림 제거
  const existingNotification = document.getElementById('entry-extension-notification');
  if (existingNotification) {
    document.body.removeChild(existingNotification);
  }
  
  // 새 알림 생성
  const notification = document.createElement('div');
  notification.id = 'entry-extension-notification';
  notification.style.position = 'fixed';
  notification.style.bottom = '20px';
  notification.style.right = '20px';
  notification.style.padding = '10px 20px';
  notification.style.backgroundColor = isError ? '#f44336' : '#4CAF50';
  notification.style.color = 'white';
  notification.style.borderRadius = '4px';
  notification.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
  notification.style.zIndex = '9999';
  notification.style.fontSize = '14px';
  notification.textContent = message;
  
  // 알림 닫기 버튼
  const closeButton = document.createElement('span');
  closeButton.textContent = '×';
  closeButton.style.marginLeft = '10px';
  closeButton.style.cursor = 'pointer';
  closeButton.style.fontWeight = 'bold';
  closeButton.onclick = function() {
    document.body.removeChild(notification);
  };
  
  notification.appendChild(closeButton);
  document.body.appendChild(notification);
  
  // 5초 후 자동으로 알림 제거
  setTimeout(() => {
    if (document.body.contains(notification)) {
      document.body.removeChild(notification);
    }
  }, 5000);
}

// 현재 페이지에서 게시글 ID 추출 함수
function extractPostIdFromUrl() {
  const url = window.location.href;
  const match = url.match(/\/entrystory\/([a-zA-Z0-9]+)/);
  return match ? match[1] : null;
}

// 스텔스 댓글 작성 UI 추가 함수
function addStealthCommentUI() {
  // 이미 존재하는 UI 확인
  if (document.getElementById('entry-extension-stealth-comment-ui')) {
    return;
  }
  
  // 댓글 작성 UI 컨테이너 생성
  const container = document.createElement('div');
  container.id = 'entry-extension-stealth-comment-ui';
  container.style.position = 'fixed';
  container.style.bottom = '80px';
  container.style.right = '20px';
  container.style.width = '300px';
  container.style.padding = '15px';
  container.style.backgroundColor = 'white';
  container.style.borderRadius = '8px';
  container.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
  container.style.zIndex = '9998';
  
  // 제목
  const title = document.createElement('h3');
  title.textContent = '스텔스 댓글 작성';
  title.style.margin = '0 0 10px 0';
  title.style.fontSize = '16px';
  title.style.color = '#333';
  
  // 텍스트 영역
  const textarea = document.createElement('textarea');
  textarea.placeholder = '댓글을 입력해주세요';
  textarea.style.width = '100%';
  textarea.style.height = '80px';
  textarea.style.padding = '8px';
  textarea.style.boxSizing = 'border-box';
  textarea.style.border = '1px solid #ddd';
  textarea.style.borderRadius = '4px';
  textarea.style.resize = 'none';
  textarea.style.marginBottom = '10px';
  textarea.style.fontSize = '14px';
  
  // 버튼 컨테이너
  const buttonContainer = document.createElement('div');
  buttonContainer.style.display = 'flex';
  buttonContainer.style.justifyContent = 'space-between';
  
  // 등록 버튼
  const submitButton = document.createElement('button');
  submitButton.textContent = '스텔스 등록';
  submitButton.style.padding = '8px 15px';
  submitButton.style.backgroundColor = '#4CAF50';
  submitButton.style.color = 'white';
  submitButton.style.border = 'none';
  submitButton.style.borderRadius = '4px';
  submitButton.style.cursor = 'pointer';
  submitButton.onclick = function() {
    const postId = extractPostIdFromUrl();
    if (!postId) {
      showNotification('게시글 ID를 찾을 수 없습니다.', true);
      return;
    }
    
    if (!textarea.value || textarea.value.trim() === '') {
      showNotification('댓글 내용을 입력해주세요.', true);
      return;
    }
    
    createStealthComment(postId, textarea.value.trim());
    textarea.value = '';
    document.body.removeChild(container);
  };
  
  // 닫기 버튼
  const closeButton = document.createElement('button');
  closeButton.textContent = '닫기';
  closeButton.style.padding = '8px 15px';
  closeButton.style.backgroundColor = '#f44336';
  closeButton.style.color = 'white';
  closeButton.style.border = 'none';
  closeButton.style.borderRadius = '4px';
  closeButton.style.cursor = 'pointer';
  closeButton.onclick = function() {
    document.body.removeChild(container);
  };
  
  // 요소들을 컨테이너에 추가
  buttonContainer.appendChild(submitButton);
  buttonContainer.appendChild(closeButton);
  
  container.appendChild(title);
  container.appendChild(textarea);
  container.appendChild(buttonContainer);
  
  // 컨테이너를 body에 추가
  document.body.appendChild(container);
}

// 페이지가 playentry.org/community/entrystory/ 경로에 있는지 확인
function isEntryStoryPage() {
  return window.location.href.includes('playentry.org/community/entrystory/');
}

// 스텔스 댓글 버튼 추가 함수
function addStealthCommentButton() {
  // 이미 존재하는 버튼 확인
  if (document.getElementById('entry-extension-stealth-comment-button')) {
    return;
  }
  
  // 스텔스 댓글 버튼 생성
  const stealthButton = document.createElement('button');
  stealthButton.id = 'entry-extension-stealth-comment-button';
  stealthButton.textContent = '스텔스 댓글';
  stealthButton.style.position = 'fixed';
  stealthButton.style.bottom = '20px';
  stealthButton.style.right = '20px';
  stealthButton.style.padding = '10px 15px';
  stealthButton.style.backgroundColor = '#16d8a3';
  stealthButton.style.color = 'white';
  stealthButton.style.border = 'none';
  stealthButton.style.borderRadius = '4px';
  stealthButton.style.cursor = 'pointer';
  stealthButton.style.zIndex = '9997';
  stealthButton.onclick = addStealthCommentUI;
  
  document.body.appendChild(stealthButton);
}

// 페이지 로드 시 실행
window.addEventListener('load', () => {
  if (isEntryStoryPage()) {
    console.log('[Entry Extension] Entry 스토리 페이지가 로드되었습니다.');
    
    // 스텔스 댓글 버튼 추가
    addStealthCommentButton();
  }
});
