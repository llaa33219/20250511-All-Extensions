// offscreen.js - 오프스크린 문서에서 실행되는 스크립트
// 사용자에게 보이지 않게 댓글을 작성하는 기능을 구현합니다.

// 메시지 리스너 설정
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'offscreen') {
    if (message.type === 'post-comment') {
      handlePostComment(message.data);
    }
  }
});

// 댓글 작성 처리 함수
async function handlePostComment(data) {
  const { postId, commentText } = data;
  console.log(`[Entry Extension] 오프스크린 문서에서 댓글 작성 시작: ${postId}, ${commentText}`);
  
  try {
    // 1. 게시글 페이지 열기
    const postUrl = `https://playentry.org/community/entrystory/${postId}`;
    await openPageInIframe(postUrl);
    
    // 2. 댓글 버튼 클릭
    await clickCommentButton();
    
    // 3. 댓글 입력
    await inputCommentText(commentText);
    
    // 4. 등록 버튼 클릭
    await clickSubmitButton();
    
    // 5. 결과 전송
    sendResultToContentScript('success', '댓글이 성공적으로 작성되었습니다.');
  } catch (error) {
    console.error('[Entry Extension] 댓글 작성 중 오류 발생:', error);
    sendResultToContentScript('error', `댓글 작성 실패: ${error.message}`);
  }
}

// 페이지를 iframe으로 열기
function openPageInIframe(url) {
  return new Promise((resolve, reject) => {
    // 기존 iframe 제거
    const existingFrame = document.getElementById('stealth-frame');
    if (existingFrame) {
      document.body.removeChild(existingFrame);
    }
    
    // 새 iframe 생성
    const iframe = document.createElement('iframe');
    iframe.id = 'stealth-frame';
    
    // 사용자 감지 회피를 위한 설정
    iframe.style.width = '1000px';
    iframe.style.height = '800px';
    iframe.style.position = 'absolute';
    iframe.style.left = '-9999px'; // 화면 밖으로 위치시켜 보이지 않게 함
    iframe.style.top = '-9999px';
    iframe.style.opacity = '0'; // 완전히 투명하게 설정
    iframe.style.pointerEvents = 'none'; // 마우스 이벤트 무시
    iframe.setAttribute('aria-hidden', 'true'); // 스크린 리더에서 숨김
    iframe.setAttribute('tabindex', '-1'); // 키보드 탐색에서 제외
    
    // 사용자 에이전트 스푸핑 방지를 위한 샌드박스 설정
    iframe.sandbox = 'allow-same-origin allow-scripts allow-forms'; // 필요한 권한만 부여
    
    iframe.src = url;
    
    // iframe 로드 이벤트
    iframe.onload = () => {
      console.log('[Entry Extension] iframe이 로드되었습니다:', url);
      
      // 사용자 감지 회피를 위한 추가 조치
      try {
        // iframe 내부의 window 객체 접근
        const iframeWindow = iframe.contentWindow;
        
        // 사용자 상호작용 감지 이벤트 무력화
        if (iframeWindow) {
          // 마우스 이벤트 가로채기
          const preventEvent = (e) => {
            e.stopPropagation();
            e.preventDefault();
          };
          
          // 이벤트 리스너 제거 함수
          const removeEventListeners = () => {
            try {
              const iframeDoc = iframe.contentDocument || iframeWindow.document;
              if (iframeDoc) {
                iframeDoc.removeEventListener('mousemove', preventEvent, true);
                iframeDoc.removeEventListener('mousedown', preventEvent, true);
                iframeDoc.removeEventListener('mouseup', preventEvent, true);
                iframeDoc.removeEventListener('click', preventEvent, true);
              }
            } catch (e) {
              console.error('[Entry Extension] 이벤트 리스너 제거 오류:', e);
            }
          };
          
          // 클린업 함수 등록
          window.addEventListener('beforeunload', removeEventListeners);
        }
      } catch (e) {
        console.warn('[Entry Extension] iframe 내부 조작 중 오류 발생:', e);
        // 오류가 발생해도 계속 진행
      }
      
      resolve(iframe);
    };
    
    iframe.onerror = (error) => {
      reject(new Error(`iframe 로드 실패: ${error}`));
    };
    
    // body에 iframe 추가
    document.body.appendChild(iframe);
  });
}

// 댓글 버튼 클릭
async function clickCommentButton() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        const iframe = document.getElementById('stealth-frame');
        if (!iframe) {
          throw new Error('iframe을 찾을 수 없습니다.');
        }
        
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        
        // 댓글 버튼 찾기 (사용자가 제공한 선택자 사용)
        const commentButton = iframeDoc.querySelector('a.reply');
        
        if (!commentButton) {
          throw new Error('댓글 버튼을 찾을 수 없습니다.');
        }
        
        // 사용자 감지 회피를 위한 직접 이벤트 발생 대신 프로그래밍 방식으로 클릭
        // 1. 클릭 이벤트 생성
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: iframe.contentWindow
        });
        
        // 2. 이벤트 발생
        commentButton.dispatchEvent(clickEvent);
        
        console.log('[Entry Extension] 댓글 버튼이 클릭되었습니다.');
        
        // 댓글 입력창이 나타날 시간을 주기 위해 지연
        setTimeout(resolve, 1000);
      } catch (error) {
        reject(error);
      }
    }, 2000); // 페이지가 완전히 로드될 시간을 주기 위해 지연
  });
}

// 댓글 텍스트 입력
async function inputCommentText(text) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        const iframe = document.getElementById('stealth-frame');
        if (!iframe) {
          throw new Error('iframe을 찾을 수 없습니다.');
        }
        
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        
        // 댓글 입력창 찾기 (사용자가 제공한 선택자 사용)
        const textarea = iframeDoc.querySelector('textarea#Write');
        
        if (!textarea) {
          throw new Error('댓글 입력창을 찾을 수 없습니다.');
        }
        
        // 사용자 감지 회피를 위한 프로그래밍 방식 입력
        // 1. 값 직접 설정
        textarea.value = text;
        
        // 2. 입력 이벤트 발생
        const inputEvent = new Event('input', { bubbles: true });
        textarea.dispatchEvent(inputEvent);
        
        // 3. 변경 이벤트 발생
        const changeEvent = new Event('change', { bubbles: true });
        textarea.dispatchEvent(changeEvent);
        
        console.log('[Entry Extension] 댓글이 입력되었습니다:', text);
        resolve();
      } catch (error) {
        reject(error);
      }
    }, 1000);
  });
}

// 등록 버튼 클릭
async function clickSubmitButton() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      try {
        const iframe = document.getElementById('stealth-frame');
        if (!iframe) {
          throw new Error('iframe을 찾을 수 없습니다.');
        }
        
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        
        // 등록 버튼 찾기 (사용자가 제공한 선택자 사용)
        const submitButton = iframeDoc.querySelector('a[href="/"][data-btn-type="login"][data-testid="button"]');
        
        if (!submitButton) {
          throw new Error('등록 버튼을 찾을 수 없습니다.');
        }
        
        // 사용자 감지 회피를 위한 프로그래밍 방식 클릭
        // 1. 클릭 이벤트 생성
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: iframe.contentWindow
        });
        
        // 2. 이벤트 발생
        submitButton.dispatchEvent(clickEvent);
        
        console.log('[Entry Extension] 등록 버튼이 클릭되었습니다.');
        
        // 댓글 등록 처리 시간을 주기 위해 지연
        setTimeout(() => {
          // iframe 제거 (작업 완료 후 즉시 정리)
          try {
            if (iframe && iframe.parentNode) {
              iframe.parentNode.removeChild(iframe);
            }
          } catch (e) {
            console.warn('[Entry Extension] iframe 제거 중 오류:', e);
          }
          
          resolve();
        }, 2000);
      } catch (error) {
        reject(error);
      }
    }, 1000);
  });
}

// 결과를 콘텐츠 스크립트에 전송
function sendResultToContentScript(status, message) {
  chrome.runtime.sendMessage({
    target: 'content',
    type: 'comment-result',
    data: {
      status: status,
      message: message,
      timestamp: new Date().toISOString()
    }
  });
}

// 페이지 로드 시 로그
console.log('[Entry Extension] 오프스크린 문서가 로드되었습니다.');

// 사용자 감지 회피를 위한 추가 설정
document.addEventListener('DOMContentLoaded', () => {
  // 페이지 가시성 API 조작
  Object.defineProperty(document, 'hidden', { value: true });
  Object.defineProperty(document, 'visibilityState', { value: 'hidden' });
  
  // 포커스 이벤트 방지
  window.addEventListener('focus', (e) => e.stopPropagation(), true);
  window.addEventListener('blur', (e) => e.stopPropagation(), true);
});
