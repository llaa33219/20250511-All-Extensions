// 콘텐츠 스크립트 (contentScript.js)
// 웹 페이지에 삽입되어 실행되는 스크립트입니다.

// 백그라운드 스크립트와 통신하기 위한 메시지 리스너 설정
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 확장 프로그램 아이콘 클릭 이벤트 처리
  if (message.type === 'icon-clicked') {
    console.log('확장 프로그램 아이콘 클릭 이벤트를 수신했습니다.');
  }
  
  // 댓글 작성 완료 이벤트 처리
  if (message.type === 'comment-posted') {
    console.log('댓글 작성 결과:', message.data);
    // 성공 또는 실패 메시지를 사용자에게 알릴 수 있습니다.
    if (message.data.status === 'success') {
      showNotification('댓글이 성공적으로 작성되었습니다.');
    } else {
      showNotification('댓글 작성에 실패했습니다: ' + message.data.message, true);
    }
  }
});

// 현재 페이지에서 게시글 ID 추출 함수
function extractPostIdFromUrl() {
  const url = window.location.href;
  const match = url.match(/\/entrystory\/([a-zA-Z0-9]+)/);
  return match ? match[1] : null;
}

// 댓글 작성 요청 함수
function requestPostComment(commentText) {
  const postId = extractPostIdFromUrl();
  
  if (!postId) {
    showNotification('게시글 ID를 찾을 수 없습니다.', true);
    return;
  }
  
  if (!commentText || commentText.trim() === '') {
    showNotification('댓글 내용을 입력해주세요.', true);
    return;
  }
  
  // 백그라운드 스크립트에 댓글 작성 요청 전송
  chrome.runtime.sendMessage({
    target: 'background',
    type: 'request-post-comment',
    data: {
      postId: postId,
      commentText: commentText
    }
  }, (response) => {
    if (response && response.status === 'processing') {
      showNotification('댓글 작성 요청이 처리 중입니다...');
    }
  });
}

// 알림 표시 함수
function showNotification(message, isError = false) {
  // 이미 존재하는 알림 제거
  const existingNotification = document.getElementById('entry-extension-notification');
  if (existingNotification) {
    document.body.removeChild(existingNotification);
  }
  
  // 새 알림 생성
  const notification = document.createElement('div');
  notification.id = 'entry-extension-notification';
  notification.style.position = 'fixed';
  notification.style.bottom = '20px';
  notification.style.right = '20px';
  notification.style.padding = '10px 20px';
  notification.style.backgroundColor = isError ? '#f44336' : '#4CAF50';
  notification.style.color = 'white';
  notification.style.borderRadius = '4px';
  notification.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
  notification.style.zIndex = '9999';
  notification.style.fontSize = '14px';
  notification.textContent = message;
  
  // 알림 닫기 버튼
  const closeButton = document.createElement('span');
  closeButton.textContent = '×';
  closeButton.style.marginLeft = '10px';
  closeButton.style.cursor = 'pointer';
  closeButton.style.fontWeight = 'bold';
  closeButton.onclick = function() {
    document.body.removeChild(notification);
  };
  
  notification.appendChild(closeButton);
  document.body.appendChild(notification);
  
  // 5초 후 자동으로 알림 제거
  setTimeout(() => {
    if (document.body.contains(notification)) {
      document.body.removeChild(notification);
    }
  }, 5000);
}

// 댓글 작성 UI 추가 함수
function addCommentUI() {
  // 이미 존재하는 UI 확인
  if (document.getElementById('entry-extension-comment-ui')) {
    return;
  }
  
  // 댓글 작성 UI 컨테이너 생성
  const container = document.createElement('div');
  container.id = 'entry-extension-comment-ui';
  container.style.position = 'fixed';
  container.style.bottom = '80px';
  container.style.right = '20px';
  container.style.width = '300px';
  container.style.padding = '15px';
  container.style.backgroundColor = 'white';
  container.style.borderRadius = '8px';
  container.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
  container.style.zIndex = '9998';
  
  // 제목
  const title = document.createElement('h3');
  title.textContent = '빠른 댓글 작성';
  title.style.margin = '0 0 10px 0';
  title.style.fontSize = '16px';
  title.style.color = '#333';
  
  // 텍스트 영역
  const textarea = document.createElement('textarea');
  textarea.placeholder = '댓글을 입력해주세요';
  textarea.style.width = '100%';
  textarea.style.height = '80px';
  textarea.style.padding = '8px';
  textarea.style.boxSizing = 'border-box';
  textarea.style.border = '1px solid #ddd';
  textarea.style.borderRadius = '4px';
  textarea.style.resize = 'none';
  textarea.style.marginBottom = '10px';
  textarea.style.fontSize = '14px';
  
  // 버튼 컨테이너
  const buttonContainer = document.createElement('div');
  buttonContainer.style.display = 'flex';
  buttonContainer.style.justifyContent = 'space-between';
  
  // 등록 버튼
  const submitButton = document.createElement('button');
  submitButton.textContent = '등록';
  submitButton.style.padding = '8px 15px';
  submitButton.style.backgroundColor = '#4CAF50';
  submitButton.style.color = 'white';
  submitButton.style.border = 'none';
  submitButton.style.borderRadius = '4px';
  submitButton.style.cursor = 'pointer';
  submitButton.onclick = function() {
    requestPostComment(textarea.value);
    textarea.value = '';
  };
  
  // 닫기 버튼
  const closeButton = document.createElement('button');
  closeButton.textContent = '닫기';
  closeButton.style.padding = '8px 15px';
  closeButton.style.backgroundColor = '#f44336';
  closeButton.style.color = 'white';
  closeButton.style.border = 'none';
  closeButton.style.borderRadius = '4px';
  closeButton.style.cursor = 'pointer';
  closeButton.onclick = function() {
    document.body.removeChild(container);
  };
  
  // 요소들을 컨테이너에 추가
  buttonContainer.appendChild(submitButton);
  buttonContainer.appendChild(closeButton);
  
  container.appendChild(title);
  container.appendChild(textarea);
  container.appendChild(buttonContainer);
  
  // 컨테이너를 body에 추가
  document.body.appendChild(container);
}

// 페이지가 playentry.org/community/entrystory/ 경로에 있는지 확인
function isEntryStoryPage() {
  return window.location.href.includes('playentry.org/community/entrystory/');
}

// 페이지 로드 시 실행
window.addEventListener('load', () => {
  if (isEntryStoryPage()) {
    console.log('Entry 스토리 페이지가 로드되었습니다.');
    
    // 빠른 댓글 작성 버튼 추가
    const quickCommentButton = document.createElement('button');
    quickCommentButton.textContent = '빠른 댓글';
    quickCommentButton.style.position = 'fixed';
    quickCommentButton.style.bottom = '20px';
    quickCommentButton.style.right = '20px';
    quickCommentButton.style.padding = '10px 15px';
    quickCommentButton.style.backgroundColor = '#4CAF50';
    quickCommentButton.style.color = 'white';
    quickCommentButton.style.border = 'none';
    quickCommentButton.style.borderRadius = '4px';
    quickCommentButton.style.cursor = 'pointer';
    quickCommentButton.style.zIndex = '9997';
    quickCommentButton.onclick = addCommentUI;
    
    document.body.appendChild(quickCommentButton);
  }
});
