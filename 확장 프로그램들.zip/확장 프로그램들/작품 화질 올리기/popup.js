document.getElementById("applyBtn").addEventListener("click", () => {
    const select = document.getElementById("resolutionSelect");
    const [widthStr, heightStr] = select.value.split("x");
    const width = parseInt(widthStr, 10);
    const height = parseInt(heightStr, 10);
  
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "changeResolution", width: width, height: height });
      }
    });
  });
  