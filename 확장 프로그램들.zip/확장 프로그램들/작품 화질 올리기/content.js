chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "changeResolution") {
      injectScriptForResolution(request.width, request.height);
      sendResponse({ status: "success" });
    }
  });
  
  // iframe과 Entry.stage가 준비될 때까지 주기적으로 체크 후, 페이지 컨텍스트에 스크립트를 주입하는 함수
  function injectScriptForResolution(width, height) {
    const interval = setInterval(() => {
      const iframe = document.querySelector("iframe");
      if (iframe && iframe.contentWindow && iframe.contentWindow.Entry && iframe.contentWindow.Entry.stage) {
        clearInterval(interval);
        const script = document.createElement('script');
        script.textContent = `
          let gcd = (a, c) => c ? gcd(c, a % c) : a;
          gcd = gcd(${width}, ${height});
          const frac = [${width} / gcd, ${height} / gcd],
                stage = document.querySelector("iframe").contentWindow.Entry.stage;
          stage.canvas.canvas.width = ${width},
          stage.canvas.canvas.height = ${height},
          stage.canvas.x = ${width} / 2,
          stage.canvas.y = ${height} / 2,
          stage.canvas.scaleX = stage.canvas.scaleY = 8,
          stage._app.stage.update();
        `;
        (document.head || document.documentElement).appendChild(script);
        script.remove();
      }
    }, 500);
  }
  