document.addEventListener('DOMContentLoaded', function() {
    // DOM 요소
    const shortcutsContainer = document.getElementById('shortcuts-container');
    const addShortcutBtn = document.getElementById('add-shortcut');
    const customizeBtn = document.getElementById('customize-button');
    const searchInput = document.getElementById('search-input');
  
    // 모달 요소
    const customizeModal = document.getElementById('customize-modal');
    const addShortcutModal = document.getElementById('add-shortcut-modal');
    const closeBtns = document.getElementsByClassName('close');
    const saveSettingsBtn = document.getElementById('save-settings');
    const saveShortcutBtn = document.getElementById('save-shortcut');
    const shortcutNameInput = document.getElementById('shortcut-name');
    const shortcutUrlInput = document.getElementById('shortcut-url');
    const backgroundSetting = document.getElementById('background-setting');
    const shortcutsSetting = document.getElementById('shortcuts-setting');
  
    // 초기 설정 로드
    loadSettings();
    loadShortcuts();
  
    // 검색 입력란 이벤트
    searchInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') {
        const query = this.value.trim();
        if (query !== '') {
          if (isValidURL(query)) {
            let url = query;
            if (!url.startsWith('http://') && !url.startsWith('https://')) {
              url = 'https://' + url;
            }
            window.location.href = url;
          } else {
            window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
          }
        }
      }
    });
  
    // 바로가기 추가 버튼 클릭
    addShortcutBtn.addEventListener('click', function() {
      showModal(addShortcutModal);
      shortcutNameInput.value = '';
      shortcutUrlInput.value = '';
    });
  
    // 맞춤설정 버튼 클릭
    customizeBtn.addEventListener('click', function() {
      showModal(customizeModal);
    });
  
    // 모달 닫기 버튼
    for (let i = 0; i < closeBtns.length; i++) {
      closeBtns[i].addEventListener('click', function() {
        hideModal(this.closest('.modal'));
      });
    }
  
    // 모달 바깥쪽 클릭시 닫기
    window.addEventListener('click', function(event) {
      if (event.target === customizeModal) {
        hideModal(customizeModal);
      }
      if (event.target === addShortcutModal) {
        hideModal(addShortcutModal);
      }
    });
  
    // 설정 저장
    saveSettingsBtn.addEventListener('click', function() {
      const settings = {
        background: backgroundSetting.checked,
        shortcuts: shortcutsSetting.checked
      };
      
      chrome.storage.sync.set({ 'newTabSettings': settings }, function() {
        hideModal(customizeModal);
        applySettings(settings);
      });
    });
  
    // 새 바로가기 저장
    saveShortcutBtn.addEventListener('click', function() {
      const name = shortcutNameInput.value.trim();
      let url = shortcutUrlInput.value.trim();
      
      if (name && url) {
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
          url = 'https://' + url;
        }
        
        chrome.storage.sync.get('shortcuts', function(data) {
          const shortcuts = data.shortcuts || [];
          shortcuts.push({ name, url });
          
          chrome.storage.sync.set({ 'shortcuts': shortcuts }, function() {
            hideModal(addShortcutModal);
            loadShortcuts();
          });
        });
      }
    });
  
    // 함수들
    function loadSettings() {
      chrome.storage.sync.get('newTabSettings', function(data) {
        const settings = data.newTabSettings || { background: true, shortcuts: true };
        backgroundSetting.checked = settings.background;
        shortcutsSetting.checked = settings.shortcuts;
        applySettings(settings);
      });
    }
  
    function applySettings(settings) {
      if (settings.background) {
        document.body.style.backgroundImage = '';
      } else {
        document.body.style.backgroundImage = 'none';
      }
      
      if (settings.shortcuts) {
        document.querySelector('.most-visited').style.display = 'flex';
      } else {
        document.querySelector('.most-visited').style.display = 'none';
      }
    }
  
    function loadShortcuts() {
      chrome.storage.sync.get('shortcuts', function(data) {
        const shortcuts = data.shortcuts || getDefaultShortcuts();
        renderShortcuts(shortcuts);
      });
    }
  
    function renderShortcuts(shortcuts) {
      shortcutsContainer.innerHTML = '';
      
      shortcuts.forEach(function(shortcut, index) {
        const shortcutElem = createShortcutElement(shortcut, index);
        shortcutsContainer.appendChild(shortcutElem);
      });
    }
  
    function createShortcutElement(shortcut, index) {
      const shortcutElem = document.createElement('div');
      shortcutElem.className = 'shortcut';
      shortcutElem.setAttribute('data-index', index);
      
      const iconElem = document.createElement('div');
      iconElem.className = 'shortcut-icon';
      
      // 파비콘 가져오기
      const favicon = document.createElement('img');
      try {
        const url = new URL(shortcut.url);
        favicon.src = `https://www.google.com/s2/favicons?domain=${url.hostname}&sz=64`;
      } catch (e) {
        favicon.src = `https://www.google.com/s2/favicons?domain=example.com&sz=64`;
      }
      
      iconElem.appendChild(favicon);
      
      const nameElem = document.createElement('div');
      nameElem.className = 'shortcut-name';
      nameElem.textContent = shortcut.name;
      
      const removeBtn = document.createElement('div');
      removeBtn.className = 'remove-button';
      removeBtn.innerHTML = '×';
      removeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        removeShortcut(index);
      });
      
      shortcutElem.appendChild(iconElem);
      shortcutElem.appendChild(nameElem);
      shortcutElem.appendChild(removeBtn);
      
      shortcutElem.addEventListener('click', function() {
        window.location.href = shortcut.url;
      });
      
      return shortcutElem;
    }
  
    function removeShortcut(index) {
      chrome.storage.sync.get('shortcuts', function(data) {
        const shortcuts = data.shortcuts || [];
        shortcuts.splice(index, 1);
        
        chrome.storage.sync.set({ 'shortcuts': shortcuts }, function() {
          loadShortcuts();
        });
      });
    }
  
    function getDefaultShortcuts() {
      return [
        { name: '구글', url: 'https://www.google.com' },
        { name: '네이버', url: 'https://www.naver.com' },
        { name: '다음', url: 'https://www.daum.net' },
        { name: '유튜브', url: 'https://www.youtube.com' },
        { name: '페이스북', url: 'https://www.facebook.com' }
      ];
    }
  
    function isValidURL(string) {
      try {
        new URL(string);
        return true;
      } catch (e) {
        if (!string.includes(' ') && string.includes('.')) {
          try {
            new URL('https://' + string);
            return true;
          } catch (e) {
            return false;
          }
        }
        return false;
      }
    }
  
    function showModal(modal) {
      modal.style.display = 'block';
    }
  
    function hideModal(modal) {
      modal.style.display = 'none';
    }
  });