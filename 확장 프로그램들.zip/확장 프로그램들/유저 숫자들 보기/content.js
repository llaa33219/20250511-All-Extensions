(function() {
  console.log('content.js가 로드되었습니다.');

  // 사용자 상태 데이터를 저장할 변수
  let userStatusData = null;

  // 함수: 데이터를 저장소에 저장
  function storeData(data) {
    chrome.storage.local.set({ userStatus: data }, () => {
      console.log('userStatus 데이터가 chrome.storage에 저장되었습니다.');
    });
  }

  // fetch를 오버라이드하여 모든 API 응답을 가로채기
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = args[0];
    console.log('[Fetch] 요청 URL:', url); // 모든 fetch 요청 URL 로깅

    try {
      const response = await originalFetch.apply(this, args);
      const clonedResponse = response.clone();
      const data = await clonedResponse.json();
      console.log('[Fetch] 응답 데이터:', data);

      // 데이터 구조 확인
      if (data && data.data && data.data.userstatus) {
        userStatusData = data.data.userstatus;
        console.log('[Fetch] 캡처된 userStatus:', userStatusData);
        storeData(userStatusData);
      } else {
        console.warn('[Fetch] userstatus 데이터가 응답에 포함되어 있지 않습니다.');
      }

      return response;
    } catch (error) {
      console.error('[Fetch] 오류 발생:', error);
      return Promise.reject(error);
    }
  };

  // XMLHttpRequest를 오버라이드하여 모든 API 응답을 가로채기
  const originalXHROpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url) {
    this.addEventListener('load', function() {
      console.log('[XHR] 응답 URL:', url); // 모든 XHR 요청 URL 로깅
      try {
        const data = JSON.parse(this.responseText);
        console.log('[XHR] 응답 데이터:', data);

        // 데이터 구조 확인
        if (data && data.data && data.data.userstatus) {
          userStatusData = data.data.userstatus;
          console.log('[XHR] 캡처된 userStatus:', userStatusData);
          storeData(userStatusData);
        } else {
          console.warn('[XHR] userstatus 데이터가 응답에 포함되어 있지 않습니다.');
        }
      } catch (e) {
        console.error('[XHR] 응답 파싱 오류:', e);
      }
    });
    originalXHROpen.apply(this, arguments);
  };

  // 10초 지연 후 데이터 캡처 확인 (타임아웃 시간 연장)
  setTimeout(() => {
    if (!userStatusData) {
      console.warn('10초 지연 후에도 userStatusData를 찾지 못했습니다.');
      // 추가적인 조치를 취할 수 있습니다.
    }
  }, 10000); // 10000 밀리초 = 10초

})();
