document.addEventListener('DOMContentLoaded', function() {
    const statusDiv = document.getElementById('status');
  
    // chrome.storage에서 데이터 가져오기
    chrome.storage.local.get(['userStatus'], (result) => {
      console.log('팝업에서 가져온 userStatus:', result.userStatus);
      if (result.userStatus) {
        displayUserStatus(result.userStatus);
      } else {
        statusDiv.innerHTML = '<p style="color:red;">사용자 상태 정보를 찾을 수 없습니다.</p>';
      }
    });
  
    // 사용자 상태 데이터를 표시하는 함수
    function displayUserStatus(status) {
      const html = `
        <div class="section">
          <h3>기본 정보</h3>
          <p><strong>닉네임:</strong> ${status.nickname || '없음'}</p>
          <p><strong>유저네임:</strong> ${status.username || '없음'}</p>
          <p><strong>설명:</strong> ${status.description || '없음'}</p>
          <p><strong>생성일:</strong> ${status.created ? new Date(status.created).toLocaleString() : '없음'}</p>
          <p><strong>프로필 이미지:</strong> ${status.profileImage ? `<a href="https://playentry.org${status.profileImage.path}" target="_blank">보기</a>` : '없음'}</p>
          <p><strong>커버 이미지:</strong> ${status.coverImage ? `<a href="https://playentry.org${status.coverImage.path}" target="_blank">보기</a>` : '없음'}</p>
        </div>
        <div class="section">
          <h3>상태</h3>
          <p><strong>프로젝트:</strong> ${status.status.project} (전체: ${status.status.projectAll})</p>
          <p><strong>스터디:</strong> ${status.status.study} (전체: ${status.status.studyAll})</p>
          <p><strong>커뮤니티:</strong></p>
          <ul>
            <li>Q&A: ${status.status.community.qna}</li>
            <li>팁: ${status.status.community.tips}</li>
            <li>자유: ${status.status.community.free}</li>
          </ul>
          <p><strong>팔로잉:</strong> ${status.status.following}</p>
          <p><strong>팔로워:</strong> ${status.status.follower}</p>
          <p><strong>북마크:</strong></p>
          <ul>
            <li>프로젝트: ${status.status.bookmark.project}</li>
            <li>스터디: ${status.status.bookmark.study}</li>
            <li>토론: ${status.status.bookmark.discuss}</li>
          </ul>
          <p><strong>사용자 상태:</strong> ${status.status.userStatus}</p>
        </div>
        <div class="section">
          <h3>대표 컨테스트 상</h3>
          ${status.representativeContestPrizes && status.representativeContestPrizes.length > 0 ? status.representativeContestPrizes.map(prize => `
            <div class="badge">
              <img src="https://playentry.org${prize.prizeImageData.path}" alt="${prize.prizeName}" />
              <span>${prize.prizeName} - ${prize.badgeText || 'N/A'}</span>
            </div>
          `).join('') : '<p>대표 컨테스트 상이 없습니다.</p>'}
        </div>
      `;
      statusDiv.innerHTML = html;
    }
  });
  