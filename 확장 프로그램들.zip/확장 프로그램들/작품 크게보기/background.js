self.addEventListener('install', (event) => {
    console.log('Service Worker installing.');
  });
  
  self.addEventListener('activate', (event) => {
    console.log('Service Worker activated.');
  });
  
  // 이 외에도 필요에 따라 다른 이벤트 리스너를 추가할 수 있습니다.
  