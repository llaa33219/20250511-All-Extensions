window.addEventListener('load', function() {
  var urlParams = new URLSearchParams(window.location.search);
  var link = urlParams.get('link');
  var iframe = document.getElementById('entryIframe');
  iframe.src = link;
});

// 창 크기가 변경될 때마다 iframe 크기를 조정합니다.
window.addEventListener('resize', resizeIframe);

function resizeIframe() {
  var iframe = document.getElementById('entryIframe');
  // 여기서는 이미 CSS에서 100%로 설정했으므로 추가 작업이 필요하지 않습니다.
  // 이 함수는 추후 추가적인 크기 조정 로직이 필요할 경우를 대비해 둔 것입니다.
}
