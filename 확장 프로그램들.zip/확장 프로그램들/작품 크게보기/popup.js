document.getElementById('openBtn').addEventListener('click', function() {
    var inputUrl = document.getElementById('urlInput').value;
    if (inputUrl.startsWith('https://playentry.org/project/')) {
      var newUrl = inputUrl.replace('project', 'iframe');
      chrome.windows.create({
        url: 'window.html?link=' + encodeURIComponent(newUrl),
        type: 'popup',
        width: 640,
        height: 480
      });
    } else {
      alert('The URL must start with "https://playentry.org/project/"');
    }
  });
  