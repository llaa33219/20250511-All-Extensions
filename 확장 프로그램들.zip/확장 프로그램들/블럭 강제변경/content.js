(function() {
    console.log("PlayEntry Code Modifier extension is running!");
    
    // Function to inject our external script into the page
    function injectExternalScript() {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('injected.js');
      script.onload = function() {
        this.remove(); // Optional: removes the script element after loading
      };
      (document.head || document.documentElement).appendChild(script);
      console.log("External script injected");
    }
    
    // Run our injection function
    setTimeout(injectExternalScript, 1000); // Delay to ensure page has loaded
  })();