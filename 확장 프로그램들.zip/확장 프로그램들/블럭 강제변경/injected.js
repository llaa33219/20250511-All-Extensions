(function() {
    console.log("PlayEntry Code Modifier - injected script running!");
    
    // Wait for the Entry object to be defined
    function waitForEntry() {
      if (typeof Entry !== 'undefined' && Entry.block) {
        modifyEntryBlocks();
      } else {
        console.log("Waiting for Entry object...");
        setTimeout(waitForEntry, 500);
      }
    }
    
    // Function to modify the blocks
    function modifyEntryBlocks() {
      console.log("Entry object found, preparing to modify blocks");
      
      // Store the original defineBlocks method
      const originalDefineMethod = Entry.block.defineBlocks;
      
      if (originalDefineMethod) {
        // Override the method
        Entry.block.defineBlocks = function(blocks) {
          // Check if our target block exists in the blocks object
          if (blocks.locate_xy_time) {
            console.log("Modifying locate_xy_time block!");
            
            // Modify the default parameters
            blocks.locate_xy_time.def.params[0].params = ['5'];  // Changed from '2' to '5'
            blocks.locate_xy_time.def.params[1].params = ['20']; // Changed from '10' to '20'
            blocks.locate_xy_time.def.params[2].params = ['30']; // Changed from '10' to '30'
            
            // You can also modify other parts of the block if needed
            // For example, add a comment to the function:
            const originalFunc = blocks.locate_xy_time.func;
            blocks.locate_xy_time.func = function(sprite, script) {
              console.log("Modified locate_xy_time block executed");
              return originalFunc.call(this, sprite, script);
            };
          }
          
          // Call the original method with our modified blocks
          return originalDefineMethod.call(this, blocks);
        };
        
        console.log("Successfully overrode Entry.block.defineBlocks!");
        
        // If the blocks are already defined, we might need to force a reload
        if (Entry.getMainWS && Entry.getMainWS().blockMenu) {
          console.log("Attempting to refresh block menu...");
          try {
            Entry.getMainWS().blockMenu.reDraw();
          } catch (e) {
            console.error("Error refreshing block menu:", e);
          }
        }
      }
    }
    
    // Start waiting for the Entry object
    waitForEntry();
  })();