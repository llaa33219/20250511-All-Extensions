// 메인 초기화 함수
function init() {
    addTempSaveButton();
    checkForSavedContent();
  }
  
  // 임시저장 버튼 추가 함수
  function addTempSaveButton() {
    // 버튼 컨테이너 찾기
    const buttonContainer = document.querySelector('div.css-19bjs0v.e6uk0pg1');
    
    if (buttonContainer && !document.querySelector('.temp-save-btn')) {
      // 임시저장 버튼 생성
      const tempSaveBtn = document.createElement('span');
      tempSaveBtn.className = 'temp-save-btn';
      tempSaveBtn.innerHTML = '<a role="button" data-testid="button" class="css-fdi34k e13821ld2">임시저장</a>';
      
      // 취소 버튼 스팬 가져오기
      const cancelBtnSpan = buttonContainer.querySelector('span');
      
      if (cancelBtnSpan && cancelBtnSpan.nextSibling) {
        // 취소 버튼 다음, 등록 버튼 전에 우리 버튼 삽입
        buttonContainer.insertBefore(tempSaveBtn, cancelBtnSpan.nextSibling);
        
        // 클릭 이벤트 추가
        tempSaveBtn.querySelector('a').addEventListener('click', saveEditorContent);
      }
    }
  }
  
  // 에디터 내용 저장 함수
  function saveEditorContent() {
    // 현재 URL 확인
    const currentUrl = window.location.href;
    
    // 에디터 요소를 직접 가져오기
    const editorElement = document.querySelector('.se-canvas');
    
    if (!editorElement) {
      alert('에디터를 찾을 수 없습니다.');
      return;
    }
    
    // 에디터 HTML 저장
    const editorHTML = editorElement.outerHTML;
    
    // 저장할 데이터 구성
    const saveData = {
      html: editorHTML,
      url: currentUrl,
      timestamp: new Date().toISOString()
    };
    
    // 로컬 스토리지에 저장
    chrome.storage.local.set({ 'playEntryEditorContent': saveData }, function() {
      console.log('에디터 콘텐츠 저장 완료');
      alert('콘텐츠가 임시저장되었습니다.');
    });
  }
  
  // 저장된 콘텐츠 확인 함수
  function checkForSavedContent() {
    chrome.storage.local.get(['playEntryEditorContent'], function(result) {
      if (result.playEntryEditorContent) {
        // 저장된 콘텐츠를 불러올지 물어보기
        if (confirm('임시저장된 콘텐츠가 있습니다. 불러오시겠습니까?')) {
          // 콘텐츠 불러오기 전 페이지가 완전히 로드될 때까지 기다림
          waitForEditorReady(function() {
            loadSavedContent(result.playEntryEditorContent);
          });
        }
      }
    });
  }
  
  // 에디터가 준비될 때까지 대기하는 함수
  function waitForEditorReady(callback) {
    const checkInterval = setInterval(function() {
      const editor = document.querySelector('.se-canvas');
      const editable = document.querySelector('.se-contenteditable');
      
      if (editor && editable) {
        clearInterval(checkInterval);
        setTimeout(callback, 500); // 추가 딜레이를 두어 에디터 초기화 완료를 보장
      }
    }, 100);
    
    // 최대 15초까지만 대기
    setTimeout(function() {
      clearInterval(checkInterval);
    }, 15000);
  }
  
  // 저장된 콘텐츠 불러오기 함수 (textarea 우회 기법 사용)
  function loadSavedContent(savedData) {
    try {
      // 1. 임시 textarea 생성
      const textarea = document.createElement('textarea');
      textarea.style.position = 'fixed';
      textarea.style.top = '0';
      textarea.style.left = '0';
      textarea.style.width = '1px';
      textarea.style.height = '1px';
      textarea.style.opacity = '0';
      textarea.style.pointerEvents = 'none';
      document.body.appendChild(textarea);
      
      // 2. 저장된 HTML 파싱하여 내용 추출
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = savedData.html;
      
      // 3. 실제 에디터 컨텐츠 영역 찾기
      const editorContentArea = document.querySelector('.se-contenteditable');
      if (!editorContentArea) {
        alert('에디터를 찾을 수 없습니다.');
        document.body.removeChild(textarea);
        return;
      }
      
      // 4. 에디터에 포커스 맞추기
      editorContentArea.focus();
      
      // 5. 콘텐츠 불러오기 메시지 표시
      alert('임시저장된 콘텐츠를 불러오는 중입니다...\n\n잠시 후 에디터를 클릭하세요.');
      
      // 6. 에디터 초기화 - 기존 요소 유지하며 빈 상태로 만들기
      // (이렇게 하면 에디터의 내부 상태를 유지하면서 콘텐츠만 지울 수 있음)
      const firstComponentTemplate = document.querySelector('.se-component-content');
      if (firstComponentTemplate) {
        const templateHtml = firstComponentTemplate.innerHTML;
        const componentsWrap = document.querySelector('.se-components-wrap');
        if (componentsWrap) {
          // 기존 컴포넌트를 모두 제거하고 빈 템플릿으로 초기화
          componentsWrap.innerHTML = '';
        }
      }
      
      // 7. 저장된 콘텐츠 정보 가이드 요소 추가
      const timestamp = new Date(savedData.timestamp).toLocaleString();
      const infoMsg = document.createElement('div');
      infoMsg.style.padding = '10px';
      infoMsg.style.margin = '10px 0';
      infoMsg.style.backgroundColor = '#f5f5f5';
      infoMsg.style.border = '1px solid #ddd';
      infoMsg.style.borderRadius = '4px';
      infoMsg.innerHTML = `
        <p style="margin: 0; font-size: 14px; color: #333;">
          <strong>임시저장 내용이 복원되었습니다</strong><br>
          저장 시간: ${timestamp}
        </p>
      `;
      
      // 가이드 요소를 에디터에 추가하려 했으나, 에디터 초기화 문제로 보류
      // 대신 콘솔에 로그로 표시
      console.log('임시저장 내용 복원 완료 - ' + timestamp);
      
      // 8. 저장된 콘텐츠에서 추출한 HTML 내용으로 에디터 업데이트
      const savedComponents = tempDiv.querySelectorAll('.se-component');
      if (savedComponents.length > 0) {
        // 각 컴포넌트를 개별적으로 추가하는 대신,
        // 전체 HTML 구조를 직접 삽입
        const componentsWrap = document.querySelector('.se-components-wrap');
        if (componentsWrap) {
          const savedComponentsWrap = tempDiv.querySelector('.se-components-wrap');
          if (savedComponentsWrap) {
            componentsWrap.innerHTML = savedComponentsWrap.innerHTML;
          }
        }
      }
      
      // 9. 임시 요소 제거
      document.body.removeChild(textarea);
      
      // 10. 페이지 클릭 유도 안내 메시지
      setTimeout(() => {
        alert('콘텐츠가 복원되었습니다. 에디터를 클릭하여 작업을 계속하세요.');
      }, 500);
      
    } catch (error) {
      console.error('콘텐츠 복원 중 오류 발생:', error);
      alert('콘텐츠 복원 중 오류가 발생했습니다: ' + error.message);
    }
  }
  
  // DOM 변경 감시하여 버튼이 없으면 추가
  const observer = new MutationObserver(function() {
    if (document.querySelector('div.css-19bjs0v.e6uk0pg1') && !document.querySelector('.temp-save-btn')) {
      addTempSaveButton();
    }
  });
  
  // 문서 관찰 시작
  observer.observe(document.body, { childList: true, subtree: true });
  
  // 페이지 로드 시 초기화
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    // DOM이 이미 준비됨
    setTimeout(init, 1000);
  }