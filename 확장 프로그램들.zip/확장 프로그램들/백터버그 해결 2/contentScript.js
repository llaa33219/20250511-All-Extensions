// contentScript.js
// 페이지가 로드되기 전에 가능한 한 먼저, SVG 관련 네임스페이스 문제를 수정하도록 처리합니다.

(function() {
    /**
     * 주어진 URL의 SVG 파일을 fetch하여, 텍스트 내의
     * - "x:" 또는 "ns1:" 접두어를 "xlink:"로 치환하고,
     * - <svg> 태그에 xmlns:xlink 속성이 누락되었으면 추가한 후,
     * 데이터 URI 형식으로 반환합니다.
     */
    async function fetchAndFixSvg(url) {
      try {
        const response = await fetch(url);
        let svgText = await response.text();
  
        // x: 또는 ns1:로 시작하는 속성명을 xlink:로 치환
        svgText = svgText.replace(/(x:|ns1:)(\w+)/g, function(match, prefix, local) {
          return 'xlink:' + local;
        });
  
        // <svg> 태그에 xmlns:xlink가 없으면 추가
        if (!/xmlns:xlink=/.test(svgText)) {
          svgText = svgText.replace(/<svg(\s|>)/, '<svg xmlns:xlink="http://www.w3.org/1999/xlink"$1');
        }
  
        return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgText);
      } catch (error) {
        console.error('Error fetching SVG:', error);
        return url; // 오류 발생 시 원래 URL로 대체
      }
    }
  
    /**
     * HTMLImageElement의 src 프로퍼티를 재정의하여,
     * src가 .svg로 끝나면 fetchAndFixSvg()를 통해 수정한 후 할당합니다.
     */
    const originalSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    Object.defineProperty(HTMLImageElement.prototype, 'src', {
      set: function(value) {
        if (typeof value === 'string' && value.trim().toLowerCase().endsWith('.svg')) {
          fetchAndFixSvg(value).then(fixedUrl => {
            originalSrcDescriptor.set.call(this, fixedUrl);
          });
        } else {
          originalSrcDescriptor.set.call(this, value);
        }
      },
      get: originalSrcDescriptor.get,
      configurable: true,
      enumerable: true
    });
  
    /**
     * DOM에 이미 존재하는 <img> 태그 중 src가 .svg인 경우 수정
     */
    function fixExistingSvgImages() {
      const imgs = document.querySelectorAll('img');
      imgs.forEach(img => {
        if (img.src && img.src.trim().toLowerCase().endsWith('.svg')) {
          fetchAndFixSvg(img.src).then(fixedUrl => {
            img.src = fixedUrl;
          });
        }
      });
    }
  
    /**
     * inline SVG(문서 내에 직접 작성된 <svg> 태그)의 잘못된 네임스페이스 속성을 수정
     */
    function fixInlineSvgElements() {
      const svgs = document.querySelectorAll('svg');
      svgs.forEach(svg => {
        if (!svg.hasAttribute('xmlns:xlink')) {
          svg.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
        }
        const allChildren = svg.querySelectorAll('*');
        allChildren.forEach(el => {
          Array.from(el.attributes).forEach(attr => {
            if (attr.name.startsWith('x:') || attr.name.startsWith('ns1:')) {
              const originalValue = el.getAttribute(attr.name);
              el.setAttribute('xlink:href', originalValue);
              el.removeAttribute(attr.name);
            }
          });
        });
      });
    }
  
    /**
     * MutationObserver로 동적으로 추가되는 <img>나 <svg> 요소를 감시하여 수정
     */
    function observeMutations() {
      const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
          mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) {
              const tagName = node.tagName.toLowerCase();
              if (tagName === 'img' && node.src && node.src.trim().toLowerCase().endsWith('.svg')) {
                fetchAndFixSvg(node.src).then(fixedUrl => {
                  node.src = fixedUrl;
                });
              }
              if (tagName === 'svg') {
                fixInlineSvgElements();
              }
              // 하위 요소에 대해 재귀적으로 검사
              if (node.querySelectorAll) {
                const imgs = node.querySelectorAll('img');
                imgs.forEach(img => {
                  if (img.src && img.src.trim().toLowerCase().endsWith('.svg')) {
                    fetchAndFixSvg(img.src).then(fixedUrl => {
                      img.src = fixedUrl;
                    });
                  }
                });
                const svgs = node.querySelectorAll('svg');
                svgs.forEach(svg => fixInlineSvgElements());
              }
            }
          });
        });
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
  
    // 가능한 한 빨리 실행
    fixExistingSvgImages();
    fixInlineSvgElements();
    observeMutations();
  })();
  