// background.js
// 확장 프로그램의 백그라운드(서비스 워커) 스크립트.
// 여기서는 큰 기능 없이 로드 여부만 확인합니다.

console.log("Auto Fix SVG Namespace Extension - background script loaded.");
