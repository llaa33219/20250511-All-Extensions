const listEl = document.getElementById('list');
const backBtn = document.getElementById('back');

function renderIds(ids) {
  backBtn.style.display = 'none';
  listEl.innerHTML = '';
  ids.forEach(id => {
    const li = document.createElement('li');
    li.textContent = id;
    li.onclick = () => openId(id);
    listEl.appendChild(li);
  });
}

function openId(id) {
  backBtn.style.display = 'block';
  chrome.runtime.sendMessage({ type: 'getSnapshots', id }, snaps => {
    listEl.innerHTML = '';
    [...snaps].reverse().forEach(snap => {
      const li = document.createElement('li');
      li.textContent = new Date(snap.time).toLocaleString();
      li.onclick = () => loadSnapshot(snap.data);
      listEl.appendChild(li);
    });
  });
}

function loadSnapshot(dataStr) {
  if (!confirm('로드하시겠습니까?')) return;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tabId = tabs[0].id;
    chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      world: 'MAIN',
      func: snapshotJson => {
        if (!window.Entry) {
          alert('Entry 객체를 찾을 수 없습니다.');
          return;
        }
        Entry.clearProject();
        Entry.loadProject(JSON.parse(snapshotJson));
      },
      args: [dataStr]
    });
  });
}

backBtn.onclick = init;
function init() {
  chrome.runtime.sendMessage({ type: 'getIds' }, renderIds);
}
init();
