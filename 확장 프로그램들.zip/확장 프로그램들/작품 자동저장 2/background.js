// 스냅샷 저장
function saveSnapshot(id, snapshot) {
    chrome.storage.local.get(['snapshots'], data => {
      const all = data.snapshots || {};
      (all[id] ??= []).push(snapshot);
      chrome.storage.local.set({ snapshots: all });
    });
  }
  
  // 메시지 라우팅
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case 'saveSnapshot':
        saveSnapshot(msg.id, { time: msg.time, data: msg.data });
        break;
  
      case 'getIds':
        chrome.storage.local.get(['snapshots'], d => {
          const ids = Object.keys(d.snapshots || {});
          ids.sort((a, b) =>
            a === 'new' ? -1 : b === 'new' ? 1 : a.localeCompare(b)
          );
          sendResponse(ids);
        });
        return true; // 비동기 응답
  
      case 'getSnapshots':
        chrome.storage.local.get(['snapshots'], d => {
          sendResponse((d.snapshots?.[msg.id]) ?? []);
        });
        return true;
  
      default:
        break;
    }
  });
  