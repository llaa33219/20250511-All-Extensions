(() => {
    const match = location.pathname.match(/^\/ws\/([^/]+)/);
    if (!match) return;
    const projectId = match[1] || 'new';
  
    /** Entry 객체 준비 대기 */
    const waitForEntry = () =>
      new Promise(res => {
        const tick = () => {
          if (window.Entry?.exportProject) return res();
          setTimeout(tick, 500);
        };
        tick();
      });
  
    /** 페이지 컨텍스트에서 exportProject 실행해서 결과 획득 */
    function exportProjectOnce() {
      return new Promise(resolve => {
        const handler = e => {
          window.removeEventListener('PE_EXPORT', handler);
          resolve(e.detail);
        };
        window.addEventListener('PE_EXPORT', handler, { once: true });
  
        const script = document.createElement('script');
        script.textContent = `
          (() => {
            const data = Entry.exportProject();
            window.dispatchEvent(new CustomEvent('PE_EXPORT', { detail: data }));
          })();
        `;
        document.documentElement.append(script);
        script.remove();
      });
    }
  
    /** 주기적으로 백업 → background로 전달 */
    async function startAutoBackup() {
      const snapshot = await exportProjectOnce();
      chrome.runtime.sendMessage({
        type: 'saveSnapshot',
        id: projectId,
        time: new Date().toISOString(),
        data: JSON.stringify(snapshot) // 문자열로 저장
      });
    }
  
    (async () => {
      await waitForEntry();
      startAutoBackup();                // 최초 1회
      setInterval(startAutoBackup, 60_000);  // 이후 60초마다
    })();
  })();
  